"""
E.V. NEXUS Graph Server — http://localhost:5000

The NEXUS is JARVIS's orbital command grid: every website, AI service, local
dashboard and forged build the user is connected to, drawn as a node orbiting
the NEXUS core. Clicking a node scans it live and reports connection stats
(HTTP code, latency, IP, redirects, page title, word count, headings, links,
images, scripts, forms…) in the side panel. Double-click opens the site.

Registry: state/nexus_links.json (seeded on first boot, user-editable both
from the UI's ＋ ADD LINK form and the voice tools add_website / remove_website).

Forged builds (actions/web_forge.py) live in ~/Documents/JARVISForge and are
registered automatically as kind="forge" nodes.

Endpoints:
  GET  /                  the frontend (dashboard/templates/index.html)
  GET  /api/graph         the NEXUS payload: hub, nodes, edges, counts
  GET  /api/node?id=…     live deep stats for one node
  GET  /api/status        system telemetry (cpu / memory / uptime)
  GET  /api/handshake     roots_pulse payload (REST fallback for WS)
  POST /api/link/add      {name,url,kind} → registers a node
  POST /api/link/remove   {name} → unregisters a node
  GET  /api/forge/list    forged builds on disk
  WS   /ws                {"type":"ready"} → roots_pulse, then status pushes

Transport: FastAPI + uvicorn when installed, otherwise a zero-dependency
stdlib HTTP server with identical routes. Bound to 127.0.0.1 only.

Run:  python dashboard/graph_server.py
"""
from __future__ import annotations

import html as _html
import json
import os
import re
import socket
import sys
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

BASE_DIR   = Path(__file__).resolve().parent.parent
TEMPLATE   = Path(__file__).resolve().parent / "templates" / "index.html"
STATIC_DIR = Path(__file__).resolve().parent / "static"
VENDOR_JS  = STATIC_DIR / "vendor" / "vis-network.min.js"

PORT, HOST = 5000, "127.0.0.1"
NEXUS_VERSION = 2

LINKS_PATH = BASE_DIR / "state" / "nexus_links.json"
FORGE_DIR  = Path.home() / "Documents" / "JARVISForge"

_KINDS = ("web", "ai", "dashboard", "forge", "service")
_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) JARVIS-Nexus/2.0")

# First boot seeds — user's own edits in nexus_links.json always win after this.
_SEEDS = [
    ("Local HUD",         "http://localhost:8000",       "dashboard"),
    ("Groq Cloud",        "https://console.groq.com",    "ai"),
    ("OpenRouter",        "https://openrouter.ai",       "ai"),
    ("Google AI Studio",  "https://aistudio.google.com", "ai"),
    ("YouTube",           "https://www.youtube.com",     "web"),
    ("GitHub",            "https://github.com",          "web"),
    ("Google",            "https://www.google.com",      "web"),
]


# ══════════════════════════════════════════════════════════════════════════════
# Link registry — state/nexus_links.json
# ══════════════════════════════════════════════════════════════════════════════
_links_lock = threading.Lock()


def _slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", str(name).strip().lower()).strip("-")
    return s or "node"


def _load_links() -> list[dict]:
    with _links_lock:
        raw = ""
        try:
            raw = LINKS_PATH.read_text(encoding="utf-8") if LINKS_PATH.exists() else ""
        except OSError:
            raw = ""
        # Missing, empty, or wiped-to-[] (a lost race between server restarts
        # once truncated it) → reseed the default connections. The registry is
        # JARVIS's memory of what he is connected to; an empty brain is a bug,
        # never a state worth preserving.
        if not raw.strip() or raw.strip() == "[]":
            seeds = [{"id": _slug(n), "name": n, "url": u, "kind": k,
                      "added_at": time.time()} for n, u, k in _SEEDS]
            try:
                LINKS_PATH.parent.mkdir(parents=True, exist_ok=True)
                LINKS_PATH.write_text(json.dumps(seeds, indent=2), encoding="utf-8")
            except OSError:
                pass
            return seeds
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, list) and parsed else seeds_or_empty()
        except Exception:
            return seeds_or_empty()


def seeds_or_empty() -> list[dict]:
    return []


def _save_links(links: list[dict]) -> None:
    with _links_lock:
        try:
            LINKS_PATH.parent.mkdir(parents=True, exist_ok=True)
            tmp = LINKS_PATH.with_suffix(".json.tmp")     # atomic-ish swap:
            tmp.write_text(json.dumps(links, indent=2), encoding="utf-8")
            tmp.replace(LINKS_PATH)                        # no reader ever sees ""
        except OSError:
            pass


def add_link(body: dict) -> dict:
    name = str(body.get("name") or "").strip()
    url  = str(body.get("url") or "").strip()
    kind = str(body.get("kind") or "web").strip().lower()
    if not name or not url:
        return {"ok": False, "error": "name and url are required"}
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "https://" + url
    if kind not in _KINDS:
        kind = "web"
    links = _load_links()
    lid = _slug(name)
    entry = {"id": lid, "name": name, "url": url, "kind": kind,
             "added_at": time.time()}
    links = [l for l in links if l.get("id") != lid] + [entry]
    _save_links(links)
    return {"ok": True, "link": entry}


def remove_link(body: dict) -> dict:
    name = str(body.get("name") or "").strip()
    if not name:
        return {"ok": False, "error": "name is required"}
    lid = _slug(name)
    links = _load_links()
    kept = [l for l in links if l.get("id") != lid]
    if len(kept) == len(links):
        return {"ok": False, "error": f"no node named '{name}'"}
    _save_links(kept)
    return {"ok": True, "removed": lid}


def _find_link(link_id: str) -> dict | None:
    for l in _load_links():
        if l.get("id") == link_id:
            return l
    return None


# ══════════════════════════════════════════════════════════════════════════════
# Forged builds (web_forge output) — recognised as nodes with kind="forge"
# ══════════════════════════════════════════════════════════════════════════════
def _forge_builds() -> list[dict]:
    out: list[dict] = []
    try:
        if not FORGE_DIR.is_dir():
            return out
        for f in sorted(FORGE_DIR.glob("*.html"), key=lambda p: p.stat().st_mtime,
                        reverse=True):
            st = f.stat()
            out.append({"file": f.name, "title": f.stem.replace("_", " ").title(),
                        "size": st.st_size, "modified": st.st_mtime,
                        "url": f.as_uri()})
    except Exception:
        pass
    return out


def _sync_forge_links() -> None:
    """Every build on disk that is not yet a node gets registered."""
    builds = {b["title"].lower(): b for b in _forge_builds()}
    if not builds:
        return
    links = _load_links()
    known = {l.get("id") for l in links}
    changed = False
    for title, b in builds.items():
        lid = "forge-" + _slug(title)
        if lid in known:
            continue
        links.append({"id": lid, "name": b["title"], "url": b["url"],
                      "kind": "forge", "added_at": time.time()})
        changed = True
    if changed:
        _save_links(links)


# ══════════════════════════════════════════════════════════════════════════════
# Live node stats — connection probe + deep page scan (stdlib urllib only)
# ══════════════════════════════════════════════════════════════════════════════
_stats_cache: dict[str, tuple[float, dict]] = {}
_stats_lock = threading.Lock()
_STAT_TTL = 25.0          # seconds a scan result is reused
_DEEP_TTL = 60.0          # deep page-parse results live longer

_MAX_READ = 420_000       # bytes actually read for the deep scan


def _title_of(chunk: str, url: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", chunk, re.I | re.S)
    if m and m.group(1).strip():
        return " ".join(_html.unescape(m.group(1)).split())[:120]
    m = re.search(r"<meta[^>]+property=[\"']og:site_name[\"'][^>]+content=[\"']([^\"']+)",
                  chunk, re.I)
    if m:
        return _html.unescape(m.group(1))[:120]
    host = urllib.parse.urlparse(url).hostname or url
    return host.replace("www.", "")[:120]


def scan_node(link: dict) -> dict:
    """Probe a link and deep-scan the page it serves. Never raises."""
    url = link.get("url") or ""
    lid = link.get("id") or ""
    now = time.time()
    with _stats_lock:
        cached = _stats_cache.get(lid)
    if cached and (now - cached[0]) < _DEEP_TTL:
        out = dict(cached[1])
        out["cached"] = True
        return out

    s: dict = {"ok": False, "url": url, "kind": link.get("kind", "web"),
               "name": link.get("name", lid), "checked_at": now}

    if url.startswith("file://"):
        # A forged build on disk: stats come from the file itself.
        try:
            p = Path(urllib.request.url2pathname(urllib.parse.urlparse(url).path))
            raw = p.read_bytes()[:_MAX_READ]
            chunk = raw.decode("utf-8", errors="replace")
            s.update({"ok": True, "status": 200, "http": "local file",
                      "ms": 0, "ip": "localhost", "final_url": url,
                      "redirects": 0, "bytes": p.stat().st_size,
                      "server": "local disk", "content_type": "text/html",
                      "title": _title_of(chunk, url)})
            _deep_from_html(s, chunk)
        except Exception as exc:
            s["error"] = str(exc).splitlines()[-1][:100] if str(exc) else "unreadable"
        with _stats_lock:
            _stats_cache[lid] = (now, s)
        return s

    redirects = 0
    final_url = url
    t0 = time.perf_counter()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _UA,
                                                   "Accept": "text/html,*/*"})
        with urllib.request.urlopen(req, timeout=6.5) as r:
            final_url = r.geturl()
            # urllib gives no redirect count; a changed final URL is the tell.
            redirects = (1 if final_url.rstrip("/") != url.rstrip("/") else 0)
            code = getattr(r, "status", None) or r.getcode() or 0
            server = (r.headers.get("Server") or "—")[:60]
            ctype  = (r.headers.get("Content-Type") or "—")[:60]
            clen   = r.headers.get("Content-Length")
            chunk  = r.read(_MAX_READ).decode("utf-8", errors="replace")
        ms = int((time.perf_counter() - t0) * 1000)
        host = urllib.parse.urlparse(final_url).hostname or ""
        try:
            ip = socket.gethostbyname(host) if host else "—"
        except Exception:
            ip = "—"
        s.update({"ok": 200 <= code < 400, "status": code,
                  "http": f"{code} {'OK' if code == 200 else ''}".strip(),
                  "ms": ms, "ip": ip, "final_url": final_url,
                  "redirects": redirects, "bytes": clen or len(chunk),
                  "server": server, "content_type": ctype,
                  "title": _title_of(chunk, final_url)})
        _deep_from_html(s, chunk)
    except urllib.error.HTTPError as e:
        s.update({"status": e.code, "http": f"{e.code} {e.reason}".strip(),
                  "ms": int((time.perf_counter() - t0) * 1000), "error": e.reason})
    except Exception as exc:
        s.update({"ms": int((time.perf_counter() - t0) * 1000),
                  "error": str(exc).splitlines()[-1][:100] if str(exc) else "unreachable"})

    with _stats_lock:
        _stats_cache[lid] = (now, s)
    return s


def _deep_from_html(s: dict, chunk: str) -> None:
    """Parse the fetched HTML into structure/content stats. Best-effort."""
    try:
        low = chunk.lower()
        m = re.search(r"<meta[^>]+name=[\"']description[\"'][^>]+content=[\"']([^\"']+)",
                      chunk, re.I)
        if m:
            s["desc"] = " ".join(_html.unescape(m.group(1)).split())[:200]
        words = len(re.sub(r"<[^>]+>", " ", re.sub(r"<(script|style)[^>]*>.*?</\1>",
                                                   " ", chunk, flags=re.I | re.S)).split())
        headings = re.findall(r"<h([1-3])[^>]*>(.*?)</h\1>", chunk, re.I | re.S)
        clean = [re.sub(r"<[^>]+>", "", h[1]).strip() for h in headings]
        links = sorted({m.group(1).strip("/")[:100]
                        for m in re.finditer(r"<a[^>]+href=[\"'](https?://[^\"']+)",
                                             chunk, re.I)})[:16]
        imgs = len(re.findall(r"<img\b", low))
        scripts = len(re.findall(r"<script\b", low))
        forms = len(re.findall(r"<form\b", low))
        login = bool(re.search(r"type=[\"']password[\"']", low))
        emails = sorted(set(re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
                                       chunk)))[:6]
        phones = sorted(set(re.findall(r"(?:\+\d{1,3}[ .-]?)?(?:\(?\d{3}\)?[ .-]?)\d{3}[ .-]?\d{4}",
                                       chunk)))[:4]
        gen = re.search(r"<meta[^>]+name=[\"']generator[\"'][^>]+content=[\"']([^\"']+)",
                        chunk, re.I)
        s.update({"words": words, "headings": [h for h in clean if h][:12],
                  "n_headings": len(headings), "n_links": len(re.findall(r"<a\b", low)),
                  "ext_links": links, "images": imgs, "scripts": scripts,
                  "forms": forms, "login": login, "emails": emails,
                  "phones": phones,
                  "generator": _html.unescape(gen.group(1))[:60] if gen else ""})
    except Exception:
        pass


def agi_stats() -> dict:
    """The A.G.I. itself — identity, mode, load and the links it holds."""
    links = _load_links()
    counts = {k: 0 for k in _KINDS}
    for l in links:
        counts[l.get("kind", "web")] = counts.get(l.get("kind", "web"), 0) + 1
    cfg = {}
    try:
        cfg = json.loads((BASE_DIR / "config" / "api_keys.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    cpu = mem = None
    up = "—"
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory().percent
        secs = int(time.time() - psutil.boot_time())
        up = f"{secs // 86400}d {secs % 86400 // 3600}h" if secs >= 86400 else f"{secs // 3600}h {secs % 3600 // 60}m"
    except Exception:
        pass
    return {"ok": True, "agi": True,
            "name": (cfg.get("assistant_name") or "JARVIS").strip(),
            "user": (cfg.get("user_name") or "").strip(),
            "mode": cfg.get("focus_mode", "standard"),
            "cpu": cpu, "mem": mem, "uptime": up,
            "links": {"total": len(links), "web": counts.get("web", 0),
                      "ai": counts.get("ai", 0), "dashboard": counts.get("dashboard", 0),
                      "forge": counts.get("forge", 0), "service": counts.get("service", 0)}}


# ── talk bridge: The Inside's TALK box → the assistant's mind ─────────────
_talk_lock = threading.Lock()
_talk_queue: list[dict] = []


def talk_enqueue(text: str) -> dict:
    text = str(text or "").strip()[:500]
    if not text:
        return {"ok": False, "error": "nothing to transmit"}
    with _talk_lock:
        _talk_queue.append({"text": text, "ts": time.time()})
    return {"ok": True, "queued": len(_talk_queue)}


def talk_poll() -> dict:
    with _talk_lock:
        items, _talk_queue[:] = _talk_queue[:], []
    return {"items": items}


def node_stats(link_id: str) -> dict:
    if link_id == "NEXUS":                      # the A.G.I. core itself
        return agi_stats()
    link = _find_link(link_id)
    if not link:
        return {"ok": False, "error": f"unknown node '{link_id}'"}
    if link.get("kind") == "forge":
        # fresh file info beats the cache
        with _stats_lock:
            _stats_cache.pop(link_id, None)
        s = scan_node(link)
        builds = [b for b in _forge_builds()
                  if b["title"].lower() == str(link.get("name", "")).lower()]
        if builds:
            b = builds[0]
            s["forge"] = {"file": b["file"], "size": b["size"],
                          "modified": b["modified"], "builds": len(_forge_builds()),
                          "dir": str(FORGE_DIR)}
        return s
    return scan_node(link)


# ══════════════════════════════════════════════════════════════════════════════
# NEXUS payload
# ══════════════════════════════════════════════════════════════════════════════
def _quick_ping(url: str, timeout: float = 1.6) -> int | None:
    """Best-effort HEAD just to light the node alive/dead — never blocks long."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _UA}, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return getattr(r, "status", None) or r.getcode()
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return None


def build_nexus() -> dict:
    _sync_forge_links()
    links = _load_links()
    hub = {"id": "NEXUS", "label": "J.A.R.V.I.S.", "url": f"http://localhost:{PORT}"}
    nodes, edges, counts = [], [], {k: 0 for k in _KINDS}

    def thread_ping(link):
        code = _quick_ping(link["url"])
        link["_alive"] = code is not None and code < 500

    threads = [(l, threading.Thread(target=thread_ping, args=(l,), daemon=True))
               for l in links]
    for _, t in threads:
        t.start()
    for l, t in threads:
        t.join(timeout=2.0)

    for l in links:
        kind = l.get("kind", "web")
        if kind not in counts:
            kind = "web"
        counts[kind] += 1
        nodes.append({"id": l["id"], "label": l.get("name", l["id"]),
                      "kind": kind, "url": l.get("url", ""),
                      "alive": bool(l.get("_alive", False))})
        edges.append({"from": hub["id"], "to": l["id"]})
    return {"version": NEXUS_VERSION, "hub": hub, "nodes": nodes, "edges": edges,
            "counts": counts, "built_at": time.time()}


def probe_status() -> dict:
    """System telemetry for the HUD dial + side panel."""
    out: dict = {"ts": time.time()}
    try:
        import psutil
        vm = psutil.virtual_memory()
        out.update({"cpu": psutil.cpu_percent(interval=None),
                    "mem_percent": vm.percent,
                    "mem_used": vm.used, "mem_total": vm.total,
                    "uptime": time.time() - psutil.boot_time(),
                    "py": sys.version.split()[0]})
    except Exception:
        out.update({"cpu": None, "mem_percent": None})
    try:
        out["forge_builds"] = len(_forge_builds())
    except Exception:
        out["forge_builds"] = 0
    return out


# ══════════════════════════════════════════════════════════════════════════════
# Shared payloads (framework-agnostic — both adapters serve these)
# ══════════════════════════════════════════════════════════════════════════════
def graph_payload() -> dict:
    return build_nexus()


def handshake_payload() -> dict:
    g = build_nexus()
    depth = {n["id"]: 1 for n in g["nodes"]}
    return {"type": "roots_pulse", "roots": [g["hub"]["id"]],
            "depth": depth, "total_depth": 1, "ts": time.time()}


def index_html() -> str:
    try:
        return TEMPLATE.read_text(encoding="utf-8")
    except OSError:
        return "<h1 style='color:#0ff'>E.V. template missing: " + str(TEMPLATE) + "</h1>"


# ── phone remote transcript (two-way feed for the QR remote) ─────────────────
PHONE_TEMPLATE = Path(__file__).resolve().parent / "templates" / "phone.html"
_transcript_lock = threading.Lock()
_transcript: list[dict] = []       # [{seq, role, text, ts}]
_transcript_seq = 0


_brain_mod = None
_brain_tried = False


def _brain():
    """Lazily import core.agi_brain once — None when unavailable."""
    global _brain_mod, _brain_tried
    if not _brain_tried:
        _brain_tried = True
        try:
            import sys as _sys
            root = str(Path(__file__).resolve().parent.parent)
            if root not in _sys.path:
                _sys.path.insert(0, root)
            from core import agi_brain as b
            _brain_mod = b
        except Exception:
            _brain_mod = None
    return _brain_mod


def transcript_ingest(role: str, text: str) -> dict:
    global _transcript_seq
    text = str(text or "").strip()
    if not text:
        return {"ok": False}
    with _transcript_lock:
        _transcript_seq += 1
        _transcript.append({"seq": _transcript_seq, "role": str(role or "user"),
                            "text": text[:2000], "ts": time.time()})
        if len(_transcript) > 200:
            del _transcript[:-200]
    return {"ok": True, "seq": _transcript_seq}


def transcript_poll(since: int) -> dict:
    since = max(0, int(since or 0))
    with _transcript_lock:
        items = [m for m in _transcript if m["seq"] > since]
    return {"items": items, "seq": _transcript_seq}


def phone_html() -> str:
    try:
        return PHONE_TEMPLATE.read_text(encoding="utf-8")
    except OSError:
        return ("<h1 style='color:#0ff;font-family:monospace'>J.A.R.V.I.S. phone "
                "template missing: " + str(PHONE_TEMPLATE) + "</h1>")


# ── THE BRAIN: live state + ingest (what The Inside renders as his mind) ─────
_activity_lock = threading.Lock()
_activity: list[dict] = []      # [{seq, kind, text, ts}]
_activity_seq = 0


def brain_activity_ingest(kind: str, text: str) -> dict:
    """Called by main.py whenever JARVIS thinks / remembers / recalls / speaks
    that touched the brain — The Inside's brain visual fires off this feed."""
    global _activity_seq
    text = str(text or "").strip()
    if not text:
        return {"ok": False}
    with _activity_lock:
        _activity_seq += 1
        _activity.append({"seq": _activity_seq, "kind": str(kind or "think"),
                          "text": text[:400], "ts": time.time()})
        if len(_activity) > 100:
            del _activity[:-100]
    return {"ok": True, "seq": _activity_seq}


def brain_payload(since: int = 0) -> dict:
    """The brain's live picture: stats, memories, latest private thoughts,
    and any activity after `since` (cursor poll — the pulses ride this)."""
    b = _brain()
    stats = {"memories": 0, "thoughts": 0}
    memories: list = []
    thoughts: list = []
    if b is not None:
        try:
            stats = b.status()
            memories = b.recall("", limit=12)
            thoughts = b.recent_thoughts(6)
        except Exception:
            pass
    since = max(0, int(since or 0))
    with _activity_lock:
        items = [a for a in _activity if a["seq"] > since]
    with _transcript_lock:
        tseq = _transcript_seq
    return {"stats": stats, "memories": memories, "thoughts": thoughts,
            "items": items, "seq": _activity_seq, "talkseq": tseq}


def ensure_vendor_js() -> bool:
    """Vendor vis-network locally once (project convention: no runtime CDN)."""
    if VENDOR_JS.exists() and VENDOR_JS.stat().st_size > 100_000:
        return True
    VENDOR_JS.parent.mkdir(parents=True, exist_ok=True)
    urls = ("https://cdn.jsdelivr.net/npm/vis-network@9.1.13/dist/vis-network.min.js",
            "https://unpkg.com/vis-network@9.1.13/dist/vis-network.min.js")
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=12) as r:
                data = r.read()
            VENDOR_JS.write_bytes(data)
            print(f"[E.D.I.T.H. GRAPH]: vendored vis-network ({len(data) // 1024} KB) locally.", flush=True)
            return True
        except Exception:
            continue
    print("[E.D.I.T.H. GRAPH]: vis vendoring failed — page falls back to CDN <script>.", flush=True)
    return False


# ══════════════════════════════════════════════════════════════════════════════
# Adapter A — FastAPI + WebSocket (primary)
# ══════════════════════════════════════════════════════════════════════════════
def run_fastapi() -> None:
    import asyncio

    import uvicorn
    from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
    from fastapi.responses import HTMLResponse, JSONResponse
    from fastapi.staticfiles import StaticFiles

    app = FastAPI(title="E.V. NEXUS", docs_url=None, redoc_url=None)
    if STATIC_DIR.is_dir():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/")
    async def _index():
        return HTMLResponse(index_html())

    @app.get("/api/graph")
    async def _graph():
        return JSONResponse(graph_payload())

    @app.get("/api/node")
    async def _node(id: str = ""):
        return JSONResponse(node_stats(id))

    @app.get("/api/status")
    async def _status():
        return JSONResponse(probe_status())

    @app.get("/api/handshake")
    async def _handshake():
        return JSONResponse(handshake_payload())

    @app.get("/api/forge/list")
    async def _forge_list():
        return JSONResponse({"builds": _forge_builds(), "dir": str(FORGE_DIR)})

    async def _body(request: Request) -> dict:
        try:
            raw = await request.body()
            return json.loads(raw.decode("utf-8", errors="replace")) if raw else {}
        except Exception:
            return {}

    @app.post("/api/link/add")
    async def _link_add(request: Request):
        return JSONResponse(add_link(await _body(request)))

    @app.post("/api/talk")
    async def _talk(request: Request):
        return JSONResponse(talk_enqueue((await _body(request)).get("text", "")))

    @app.get("/api/talk/poll")
    async def _talk_poll():
        return JSONResponse(talk_poll())

    @app.post("/api/link/remove")
    async def _link_remove(request: Request):
        return JSONResponse(remove_link(await _body(request)))

    class _Hub:
        def __init__(self):
            self.clients: set = set()
            self.lock = threading.Lock()

        async def broadcast(self, payload: dict):
            dead = []
            with self.lock:
                clients = list(self.clients)
            for ws in clients:
                try:
                    await ws.send_json(payload)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                with self.lock:
                    self.clients.discard(ws)

    hub = _Hub()

    @app.websocket("/ws")
    async def _ws(ws: WebSocket):
        await ws.accept()
        with hub.lock:
            hub.clients.add(ws)
        try:
            while True:
                msg = await ws.receive_json()
                if msg.get("type") == "ready":
                    await ws.send_json(handshake_payload())
        except WebSocketDisconnect:
            pass
        except Exception:
            pass
        finally:
            with hub.lock:
                hub.clients.discard(ws)

    @app.on_event("startup")
    async def _status_loop():
        async def _loop():
            while True:
                try:
                    await hub.broadcast({"type": "status", **probe_status()})
                except Exception:
                    pass
                await asyncio.sleep(4)
        asyncio.create_task(_loop())

    print(f"[E.D.I.T.H. GRAPH]: NEXUS transport online (fastapi) — http://localhost:{PORT}", flush=True)
    uvicorn.run(app, host=HOST, port=PORT, log_level="warning")


# ══════════════════════════════════════════════════════════════════════════════
# Adapter B — zero-dependency stdlib fallback (identical routes, no WS)
# ══════════════════════════════════════════════════════════════════════════════
def run_stdlib() -> None:
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):        # quiet — the terminal stays readable
            pass

        def _json(self, payload: dict, code: int = 200):
            body = json.dumps(payload).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _file(self, path: Path, mime: str):
            try:
                body = path.read_bytes()
            except OSError:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _post_body(self) -> dict:
            try:
                n = int(self.headers.get("Content-Length") or 0)
                return json.loads(self.rfile.read(n).decode("utf-8", errors="replace")) if n else {}
            except Exception:
                return {}

        def do_POST(self):
            route = self.path.split("?", 1)[0]
            if route == "/api/link/add":
                self._json(add_link(self._post_body()))
            elif route == "/api/link/remove":
                self._json(remove_link(self._post_body()))
            elif route == "/api/talk":
                self._json(talk_enqueue(self._post_body().get("text", "")))
            elif route == "/api/transcript":
                b = self._post_body()
                self._json(transcript_ingest(b.get("role", "user"), b.get("text", "")))
            elif route == "/api/brain/activity":
                b = self._post_body()
                self._json(brain_activity_ingest(b.get("kind", "think"), b.get("text", "")))
            else:
                self.send_error(404)

        def do_GET(self):
            route = self.path.split("?", 1)[0]
            qs = urllib.parse.parse_qs(self.path.split("?", 1)[1]) if "?" in self.path else {}
            if route == "/api/graph":
                self._json(graph_payload())
            elif route == "/api/node":
                self._json(node_stats((qs.get("id") or [""])[0]))
            elif route == "/api/status":
                self._json(probe_status())
            elif route == "/api/handshake":
                self._json(handshake_payload())
            elif route == "/api/forge/list":
                self._json({"builds": _forge_builds(), "dir": str(FORGE_DIR)})
            elif route == "/api/talk/poll":
                self._json(talk_poll())
            elif route == "/api/transcript/poll":
                self._json(transcript_poll((qs.get("since") or ["0"])[0]))
            elif route == "/api/brain":
                self._json(brain_payload((qs.get("since") or ["0"])[0]))
            elif route == "/phone" or route == "/remote":
                self.send_response(200)
                body = phone_html().encode()
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif route == "/" or route == "/index.html":
                self.send_response(200)
                body = index_html().encode()
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif route.startswith("/static/"):
                target = (STATIC_DIR / route.removeprefix("/static/")).resolve()
                if STATIC_DIR.resolve() not in target.parents:
                    self.send_error(403)
                    return
                mime = "application/javascript" if target.suffix == ".js" else "text/plain"
                self._file(target, mime)
            else:
                self.send_error(404)

    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.daemon_threads = True
    print(f"[E.D.I.T.H. GRAPH]: NEXUS transport online (stdlib) — http://localhost:{PORT}", flush=True)
    server.serve_forever()


def main() -> None:
    # vendor in the background — the port binds immediately, so the spread-roots
    # bootstrap never stalls waiting on a CDN download
    threading.Thread(target=ensure_vendor_js, daemon=True, name="ev-vendor").start()
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
        run_fastapi()
    except ImportError:
        run_stdlib()


if __name__ == "__main__":
    main()
