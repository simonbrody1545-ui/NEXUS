"""YouTube Studio — live channel analytics dashboard.

JARVIS opens a Stark-styled dashboard that pulls real numbers straight from
the YouTube Data API v3 **in the browser**, then re-fetches every 60 seconds,
so subscriber and view counters tick along while you watch — the same headline
figures Studio's overview shows, without the OAuth dance the Analytics API
demands for watch-time/impressions data.

Setup (one time): put in config/api_keys.json —
    "youtube_api_key": "<an API key from console.cloud.google.com>"
    "youtube_channel_id": "UC..."          (optional — or give @handle)

Any key restriction should allow the YouTube Data API. The page itself does
the fetching (googleapis permits keyed GETs cross-origin), which is what makes
it live without a backend: every 60 s it re-queries the channel and the latest
uploads, updates the stat cards, per-video rows and the views chart, and
tracks deltas in localStorage so it can show "+N subs since you last looked".

If no key is configured the tool replies with exact setup steps instead of a
half-broken page — it never opens a dashboard it cannot feed.
"""

from __future__ import annotations

import json
import sys
import time
import urllib.parse
import webbrowser
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR   = _base_dir()
CONFIG_DIR = BASE_DIR / "config"
STATE_DIR  = BASE_DIR / "state" / "youtube"
DASH_PATH  = STATE_DIR / "studio_dashboard.html"

PLUGIN = {
    "name": "youtube_studio",
    "description": (
        "Opens a live YouTube Studio analytics dashboard for the user's channel: "
        "subscribers, total views, video count, average views per video and the "
        "latest uploads with views/likes/comments, auto-refreshing every 60 "
        "seconds from the YouTube Data API. Use when the user asks for their "
        "'YouTube stats', 'channel analytics', 'Studio dashboard', 'how is my "
        "channel doing' or similar. Requires youtube_api_key (and optionally "
        "youtube_channel_id or youtube_handle) in config/api_keys.json — without "
        "them the tool replies with exact setup steps instead of opening a "
        "half-fed page."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "channel": {
                "type": "STRING",
                "description": (
                    "Optional channel to open: a channel ID (UC…) or @handle. "
                    "Defaults to youtube_channel_id / youtube_handle from config."
                ),
            },
        },
        "required": [],
    },
}


def _config() -> dict:
    try:
        return json.loads((BASE_DIR / "config" / "api_keys.json")
                          .read_text(encoding="utf-8"))
    except Exception:
        return {}


def _setup_message() -> str:
    return (
        "Sir, I need a YouTube Data API key before I can pull your Studio "
        "numbers. One-time setup:\n"
        "  1. console.cloud.google.com → create/select a project\n"
        "  2. APIs & Services → enable 'YouTube Data API v3'\n"
        "  3. Credentials → Create API key\n"
        "  4. Put it in config/api_keys.json as "
        "\"youtube_api_key\": \"AIza...\" (and optionally "
        "\"youtube_channel_id\": \"UC...\" or \"youtube_handle\": \"@you\")\n"
        "Then just ask me again — I'll have the dashboard up in seconds."
    )


def _resolve_channel_id(key: str, ident: str) -> str:
    """Resolve a @handle to a UC… channel id (so the page can hit the uploads
    playlist in one hop). Best-effort: on any failure the raw identifier is
    returned and the page resolves it client-side."""
    if not ident or ident.startswith("UC"):
        return ident
    import urllib.request
    handle = ident if ident.startswith("@") else f"@{ident.lstrip('@')}"
    url = (f"https://www.googleapis.com/youtube/v3/channels"
           f"?part=id&forHandle={urllib.parse.quote(handle)}&key={key}")
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read().decode("utf-8"))
            items = data.get("items") or []
            if items:
                return items[0]["id"]
    except Exception:
        pass
    return handle


def _generate_dashboard(key: str, ident: str) -> str:
    """The dashboard HTML. Placeholders (not an f-string) so the JavaScript
    braces survive without doubling every one."""
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    html = _PAGE
    html = html.replace("__KEY__", key)
    html = html.replace("__IDENT__", ident.replace('"', ""))
    DASH_PATH.write_text(html, encoding="utf-8")
    return str(DASH_PATH)


def run(parameters: dict, player=None, session_memory=None) -> str:
    parameters = parameters or {}
    cfg = _config()
    key = str(parameters.get("api_key") or cfg.get("youtube_api_key") or "").strip()
    if not key:
        return _setup_message()

    ident = str(parameters.get("channel") or cfg.get("youtube_channel_id")
                or cfg.get("youtube_handle") or "").strip()
    if not ident:
        # No identifier anywhere: try the key itself for a channel owned by
        # it? Not possible — an API key carries no identity. Ask for one line.
        return ("Which channel, sir? Give me the channel ID (UC…) or your "
                "@handle — or save it in config/api_keys.json as "
                "\"youtube_channel_id\" so I never ask twice.")
    ident = _resolve_channel_id(key, ident)

    path = _generate_dashboard(key, ident)
    try:
        try:
            from core.opera import open_path
            open_path(path)
        except Exception:
            webbrowser.open(Path(path).as_uri())
    except Exception:
        pass

    who = ident if ident.startswith("UC") else f"channel {ident}"
    return (f"Your Studio dashboard is live, sir — {who}. Subscribers, total "
            f"views and the latest uploads, refreshing every 60 seconds. "
            f"Opened in your browser: {Path(path).name}")


_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>STARK STUDIO — LIVE CHANNEL ANALYTICS</title>
<style>
  :root { --bg:#00080a; --panel:#00101a; --b:#00a8cc; --bb:#00d4ff;
          --pri:#00d8ff; --txt:#00e8ff; --dim:#0088aa; --acc:#ff6600;
          --grn:#00ffaa; --red:#ff2a4a; }
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:var(--bg); color:var(--txt);
         font-family:'Segoe UI',Consolas,monospace; min-height:100vh;
         padding:26px 30px; }
  .grid-dots { position:fixed; inset:0; pointer-events:none; opacity:.5;
    background-image:radial-gradient(#004455 1px, transparent 1px);
    background-size:48px 48px; }
  h1 { font-family:Orbitron,'Segoe UI',monospace; font-size:26px;
       letter-spacing:5px; color:var(--bb);
       text-shadow:0 0 18px rgba(0,212,255,.45); }
  .sub { color:var(--dim); font-size:12px; letter-spacing:3px; margin-top:4px; }
  .live { display:inline-block; width:9px; height:9px; border-radius:50%;
          background:var(--grn); box-shadow:0 0 10px var(--grn);
          margin-right:7px; animation:pulse 1.6s infinite; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.25} }
  .head { display:flex; align-items:center; gap:18px; margin-bottom:22px;
          border-bottom:1px solid var(--b); padding-bottom:16px; }
  .avatar { width:64px; height:64px; border-radius:50%;
            border:2px solid var(--bb); object-fit:cover;
            box-shadow:0 0 22px rgba(0,212,255,.35); }
  .delta { color:var(--grn); font-size:12px; letter-spacing:1px; }
  .cards { display:grid; grid-template-columns:repeat(auto-fit,minmax(190px,1fr));
           gap:14px; margin-bottom:24px; }
  .card { background:linear-gradient(180deg,rgba(0,16,26,.9),rgba(0,8,10,.9));
          border:1px solid var(--b); border-radius:6px; padding:16px 18px;
          position:relative; overflow:hidden; }
  .card::before { content:''; position:absolute; inset:0;
    background:linear-gradient(120deg,transparent 30%,rgba(0,212,255,.07) 50%,
               transparent 70%); }
  .card .k { color:var(--dim); font-size:10px; letter-spacing:3px; }
  .card .v { font-family:Orbitron,monospace; font-size:30px; color:var(--pri);
             text-shadow:0 0 14px rgba(0,216,255,.4); margin-top:6px; }
  .card .d { font-size:11px; margin-top:5px; color:var(--grn); min-height:14px; }
  .card.acc .v { color:var(--acc); text-shadow:0 0 14px rgba(255,102,0,.4); }
  h2 { font-family:Orbitron,monospace; font-size:13px; letter-spacing:4px;
       color:var(--bb); margin:26px 0 12px; }
  table { width:100%; border-collapse:collapse; }
  th { color:var(--dim); font-size:10px; letter-spacing:2px; text-align:left;
       border-bottom:1px solid var(--b); padding:7px 10px; }
  td { padding:9px 10px; border-bottom:1px solid rgba(0,168,204,.15);
       font-size:13px; }
  tr:hover td { background:rgba(0,212,255,.05); }
  td.num { font-family:Orbitron,monospace; color:var(--pri); }
  .bar { height:8px; background:rgba(0,168,204,.15); border-radius:4px;
         overflow:hidden; min-width:90px; }
  .bar i { display:block; height:100%;
           background:linear-gradient(90deg,var(--b),var(--bb));
           box-shadow:0 0 8px rgba(0,212,255,.5); }
  .err { border:1px solid var(--red); color:var(--red); padding:14px;
         border-radius:6px; margin:18px 0; display:none; letter-spacing:1px; }
  .foot { color:var(--dim); font-size:11px; letter-spacing:2px; margin-top:26px; }
  a { color:var(--pri); text-decoration:none; }
  .spark-card { margin-bottom:24px; }
  .spark-card canvas { width:100%; height:90px; margin-top:8px; }
  .livechip { display:inline-flex; align-items:center; gap:6px;
    border:1px solid var(--grn); color:var(--grn); border-radius:10px;
    padding:1px 8px; font-size:10px; letter-spacing:1px; margin-left:10px; }
</style>
</head>
<body>
<div class="grid-dots"></div>
<h1>&#9672; STARK STUDIO</h1>
<div class="sub"><span class="live"></span>LIVE CHANNEL ANALYTICS · REFRESH 60s ·
<span id="stamp">—</span><span class="livechip" id="livechip" style="display:none">● LIVE NOW</span></div>

<div class="err" id="err"></div>

<div class="head" id="head" style="display:none">
  <img class="avatar" id="avatar" alt="">
  <div>
    <div style="font-family:Orbitron;font-size:19px;letter-spacing:2px" id="title">—</div>
    <div class="sub" id="handle"></div>
    <div class="delta" id="subs-delta"></div>
  </div>
</div>

<div class="cards">
  <div class="card acc"><div class="k">SUBSCRIBERS</div><div class="v" id="subs">—</div><div class="d" id="subs-d"></div></div>
  <div class="card"><div class="k">TOTAL VIEWS</div><div class="v" id="views">—</div><div class="d" id="views-d"></div></div>
  <div class="card"><div class="k">WATCH HOURS (28d)</div><div class="v" id="hours">—</div><div class="d" id="hours-d"></div></div>
  <div class="card"><div class="k">VIEWS TODAY</div><div class="v" id="today">—</div><div class="d" id="today-d"></div></div>
  <div class="card"><div class="k">VIDEOS</div><div class="v" id="vids">—</div><div class="d" id="vids-d"></div></div>
  <div class="card"><div class="k">AVG VIEWS / VIDEO</div><div class="v" id="avg">—</div><div class="d" id="avg-d"></div></div>
</div>

<div class="card spark-card"><div class="k">VIEWS TODAY — LIVE TICKER (each poll adds a point)</div>
  <canvas id="ticker" width="980" height="90"></canvas></div>

<h2>&#9654; LATEST UPLOADS</h2>
<table id="tbl">
  <thead><tr><th>VIDEO</th><th>PUBLISHED</th><th>VIEWS</th><th>DISTRIBUTION</th><th>LIKES</th><th>COMMENTS</th></tr></thead>
  <tbody id="rows"></tbody>
</table>

<div class="foot">SOURCE: YOUTUBE DATA API V3 · REAL-TIME POLLING ·
<a href="https://studio.youtube.com" target="_blank">OPEN FULL STUDIO &#8599;</a></div>

<script>
const KEY = "__KEY__";
const IDENT = "__IDENT__";
const $ = id => document.getElementById(id);
const fmt = n => { n = Number(n)||0;
  if (n >= 1e9) return (n/1e9).toFixed(2)+'B';
  if (n >= 1e6) return (n/1e6).toFixed(2)+'M';
  if (n >= 1e3) return (n/1e3).toFixed(1)+'K';
  return String(n); };
const ago = iso => { const s = (Date.now()-new Date(iso))/1000;
  if (s < 86400) return Math.max(1,Math.floor(s/3600))+'h ago';
  if (s < 2592000) return Math.floor(s/86400)+'d ago';
  return Math.floor(s/2592000)+'mo ago'; };

function store(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} }
function load(k) { try { return JSON.parse(localStorage.getItem(k)); } catch(e){ return null; } }

function delta(cardId, dId, cur) {
  const prev = load('yt_'+cardId);
  if (prev && prev < cur) $(dId).textContent = '+' + fmt(cur - prev) + ' since last open';
  else if (prev && prev > cur) $(dId).textContent = '−' + fmt(prev - cur);
  store('yt_'+cardId, cur);
}

/* ── WATCH HOURS + VIEWS TODAY TRACKER ──────────────────────────────────
   The public Data API has no analytics endpoint (that needs OAuth into
   Studio proper). This tracker computes honest estimates from data the
   public API DOES give, and accumulates them across sessions:
   • views today    = total views now − total views at local midnight
   • watch hours    = Σ(views per recent video × typical duration)
                      — duration comes from contentDetails, so the estimate
                      improves as more videos are seen; 28-day window
   • live ticker    = every poll appends today's view count → a real-time
                      slope chart of the channel's day                       */
const POLL_MS = 60000;

function midnightKey() {
  const d = new Date(); return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();
}
function trackViewTotals(totalViews) {
  const k = midnightKey();
  const rec = load('yt_day') || {};
  if (rec.k !== k) { rec.k = k; rec.base = totalViews; rec.samples = []; }
  rec.samples = rec.samples || [];
  rec.samples.push({t: Date.now(), v: totalViews});
  if (rec.samples.length > 300) rec.samples.shift();
  rec.last = totalViews;
  store('yt_day', rec);
  return { today: Math.max(0, totalViews - (rec.base ?? totalViews)), rec };
}

let tickerCanvas, tickerCtx;
function drawTicker(rec) {
  if (!tickerCanvas) { tickerCanvas = $('ticker'); tickerCtx = tickerCanvas.getContext('2d'); }
  const c = tickerCtx, W = tickerCanvas.width, H = tickerCanvas.height;
  c.clearRect(0, 0, W, H);
  const pts = (rec.samples || []);
  if (pts.length < 2) { c.fillStyle = '#0088aa'; c.font='10px Orbitron';
    c.fillText('collecting samples — one point per refresh…', 10, 20); return; }
  const vs = pts.map(p => p.v);
  const lo = Math.min(...vs), hi = Math.max(...vs), span = Math.max(1, hi-lo);
  c.strokeStyle = 'rgba(0,168,204,.25)';
  for (let y=0; y<H; y+=22) { c.beginPath(); c.moveTo(0,y); c.lineTo(W,y); c.stroke(); }
  c.strokeStyle = '#00d4ff'; c.lineWidth = 2; c.beginPath();
  pts.forEach((p,i) => { const X = i/(pts.length-1)*(W-8)+4;
    const Y = H-8 - ((p.v-lo)/span)*(H-18);
    i ? c.lineTo(X,Y) : c.moveTo(X,Y); });
  c.stroke();
  const last = pts[pts.length-1], prev = pts[pts.length-2];
  const rate = (last.v - prev.v) / (POLL_MS/1000);          // views per second
  c.fillStyle = (last.v >= prev.v) ? '#00ffaa' : '#ff2a4a';
  c.font = '10px Orbitron'; c.textAlign = 'right';
  c.fillText((rate>=0?'+':'') + rate.toFixed(2) + ' views/s', W-8, 14);
  c.textAlign = 'left';
  c.fillText('day total ' + fmt(last.v - (rec.base ?? last.v)), 8, 14);
}

async function estimateWatchHours(uploads) {
  // Fetch durations for the most recent videos (the 28d window's heavy
  // contributors) and multiply their views by duration. Monetised watch-time
  // differs — this is the honest public-API estimate.
  if (!uploads || !uploads.length) return null;
  const vs = await api('videos', { part:'statistics,contentDetails', id: uploads.join(',') });
  let secs = 0, counted = 0;
  const cutoff = Date.now() - 28*86400*1000;
  (vs.items||[]).forEach(v => {
    if (new Date(v.snippet.publishedAt) < cutoff) return;    // outside 28d
    const m = (v.contentDetails.duration||'').match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
    if (!m) return;
    const dur = (+(m[1]||0))*3600 + (+(m[2]||0))*60 + (+(m[3]||0));
    if (dur <= 0) return;
    // Partial-view reality: a view rarely means a full watch. 0.6 average
    // retention is a fair public-data assumption for normal-length videos.
    secs += (Number((v.statistics||{}).viewCount)||0) * dur * 0.6;
    counted++;
  });
  return counted ? Math.round(secs/3600) : null;
}

async function checkLive(key, ident) {
  // Any current broadcast → LIVE NOW chip on the header.
  try {
    const u = new URL('https://www.googleapis.com/youtube/v3/search');
    u.searchParams.set('part','snippet');
    u.searchParams.set('channelId', ident.startsWith('UC') ? ident : '');
    if (!ident.startsWith('UC')) return false;
    u.searchParams.set('type','video'); u.searchParams.set('eventType','live');
    u.searchParams.set('maxResults','1'); u.searchParams.set('key', key);
    const r = await fetch(u);
    if (!r.ok) return false;
    const j = await r.json();
    return (j.items||[]).length > 0;
  } catch(e) { return false; }
}

function showErr(msg) {
  const e = $('err'); e.style.display = 'block';
  e.textContent = '⚠ ' + msg;
}

async function api(path, params) {
  const u = new URL('https://www.googleapis.com/youtube/v3/' + path);
  Object.entries(params).forEach(([k,v]) => u.searchParams.set(k, v));
  u.searchParams.set('key', KEY);
  const r = await fetch(u);
  if (!r.ok) {
    let why = r.status;
    try { const j = await r.json(); why = j.error.message || why; } catch(e){}
    throw new Error('API ' + why);
  }
  return r.json();
}

async function refresh() {
  try {
    const ch = await api('channels',
      { part:'snippet,statistics,contentDetails',
        [IDENT.startsWith('UC') ? 'id' : 'forHandle']: IDENT });
    const c = (ch.items || [])[0];
    if (!c) throw new Error('channel not found — check the ID/handle');
    const st = c.statistics, sn = c.snippet;

    $('head').style.display = 'flex';
    $('avatar').src = (sn.thumbnails || {}).medium ? sn.thumbnails.medium.url : '';
    $('title').textContent = sn.title || '—';
    $('handle').textContent = sn.customUrl || sn.description.slice(0,90) || '';
    $('subs').textContent  = st.hiddenSubscriberCount ? 'hidden' : fmt(st.subscriberCount);
    $('views').textContent = fmt(st.viewCount);
    $('vids').textContent  = fmt(st.videoCount);
    $('avg').textContent   = st.videoCount ? fmt(Math.round(st.viewCount/st.videoCount)) : '—';
    delta('subs','subs-d', Number(st.subscriberCount)||0);
    delta('views','views-d', Number(st.viewCount)||0);

    // ── REAL-TIME TRACKERS ──
    const { today, rec } = trackViewTotals(Number(st.viewCount)||0);
    $('today').textContent = fmt(today);
    const subRec = load('yt_day');
    if (subRec && subRec.samples && subRec.samples.length > 2) {
      const a = subRec.samples[0], b = subRec.samples[subRec.samples.length-1];
      const hrs = Math.max(0.05, (b.t - a.t)/3600000);
      $('today-d').textContent = '+' + fmt(Math.max(0,(b.v-a.v))/hrs*1).replace('.0','')
        + '/hr current pace';
    }
    drawTicker(rec);

    const up = (c.contentDetails.relatedPlaylists || {}).uploads;
    if (up) {
      const pl = await api('playlistItems',
        { part:'contentDetails', playlistId:up, maxResults:12 });
      const ids = (pl.items||[]).map(i => i.contentDetails.videoId).filter(Boolean);
      if (ids.length) {
        const hours = await estimateWatchHours(ids);
        if (hours !== null) {
          $('hours').textContent = fmt(hours);
          $('hours-d').textContent = '28-day estimate · ' + ids.length + ' recent videos';
        }
        const vs = await api('videos',
          { part:'snippet,statistics', id: ids.join(',') });
        const rows = (vs.items||[]).map(v => {
          const s = v.statistics||{};
          return { id: v.id, title: v.snippet.title, pub: v.snippet.publishedAt,
                   views: Number(s.viewCount)||0, likes: Number(s.likeCount)||0,
                   comments: Number(s.commentCount)||0 };
        }).sort((a,b) => b.pub.localeCompare(a.pub));
        const maxV = Math.max(1, ...rows.map(r => r.views));
        $('rows').innerHTML = rows.map(r =>
          `<tr><td><a href="https://youtu.be/${r.id}" target="_blank">${r.title.slice(0,58)}</a></td>` +
          `<td>${ago(r.pub)}</td><td class="num">${fmt(r.views)}</td>` +
          `<td><div class="bar"><i style="width:${Math.round(r.views/maxV*100)}%"></i></div></td>` +
          `<td class="num">${fmt(r.likes)}</td><td class="num">${fmt(r.comments)}</td></tr>`).join('');
      }
    }
    $('err').style.display = 'none';
    $('stamp').textContent = 'UPDATED ' + new Date().toLocaleTimeString();
    // live-stream chip
    checkLive(KEY, IDENT).then(live => {
      $('livechip').style.display = live ? 'inline-flex' : 'none';
    });
  } catch (e) {
    showErr(e.message || String(e));
  }
}

refresh();
setInterval(refresh, POLL_MS);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) refresh();   // catch up after a hidden tab
});
</script>
</body>
</html>
"""
