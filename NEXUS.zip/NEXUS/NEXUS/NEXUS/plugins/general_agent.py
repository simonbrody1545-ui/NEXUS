"""
General-purpose autonomous task agent — a "plan, act, observe, repeat" loop
that chains together JARVIS's own built-in tools to get open-ended, multi-step
jobs done, instead of handling only one fixed thing the way every other
plugin/action does.

Drop this file into plugins/. Nothing else in the project needs to change —
JARVIS discovers it automatically at startup (see core/plugin_loader.py).

WHAT THIS ACTUALLY IS
    Not "AGI" — there's no such thing running on a laptop. This is Gemini
    called once per step to decide "given the goal and what's happened so
    far, which one tool should I call next, with what arguments — or am I
    done?" It then runs that tool for real, feeds the result back in, and
    asks again. That's the whole trick: no tool in this project can chain
    itself into others or recover from "step 1 failed, try something else" —
    this one can, up to MAX_STEPS times, because the planning step re-reads
    the outcome of every previous step before choosing the next one.

WHY IT'S SAFE TO DROP IN
    - Only reads AVAILABLE_ACTIONS via the same discover_actions() every
      other tool is found with — it never imports or calls anything that
      isn't already a validated, self-describing action in actions/.
    - dev_agent is deliberately excluded from its toolbox (see below) so this
      can never spawn a multi-minute build loop inside its own step budget.
    - Every failure mode (bad JSON from the planner, an unknown tool name, a
      tool that raises) is caught and logged as a step outcome, never as a
      crash — the loop always ends with a spoken sentence, not a traceback.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from core import gemini


def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = get_base_dir()

MAX_STEPS = 8
STEP_TIMEOUT_MS = 30000

# dev_agent plans/writes/runs/fixes whole multi-file projects on its own — a
# multi-minute job in its own right. Letting the planner call it mid-loop
# would burn the entire step budget on one sub-task and leave nothing for the
# rest of the goal. If the user's ask IS "build me a project", Gemini should
# route to dev_agent directly instead of through this agent.
_EXCLUDED_TOOLS = {"dev_agent", "general_agent"}


PLUGIN = {
    "name": "general_agent",
    "description": (
        "Handles open-ended, multi-step, or ambiguous requests that no single "
        "other tool covers by itself — it works out its own plan and calls "
        "whichever of JARVIS's other tools it needs, one at a time, checking "
        "each result before deciding the next step, until the goal is done or "
        "it runs out of attempts. Use this ONLY when the request clearly needs "
        "several different tools chained together, or genuine problem-solving "
        "to work out how to do it (e.g. 'check the weather and, if it's "
        "raining, cancel my reminder for the run and tell me why'). Do NOT use "
        "this for anything a single existing tool already does directly "
        "(opening an app, one weather check, a plain web search, sending a "
        "message, building a whole project with dev_agent) — call that tool "
        "instead, it is faster and more reliable."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "goal": {
                "type": "STRING",
                "description": "The full task, in as much detail as the user gave — this is all the agent has to go on.",
            },
        },
        "required": ["goal"],
    },
    "behavior": "NON_BLOCKING",
    "scheduling": "WHEN_IDLE",
}


def _load_toolbox():
    """Fresh discovery every call (plugins/actions can be toggled between
    runs, and action_loader reuses already-imported modules, so this is
    cheap). Returns (ActionRegistry, catalog) with dev_agent/self excluded."""
    from core.action_loader import discover_actions

    registry = discover_actions(actions_dir=BASE_DIR / "actions", logger=lambda *_a: None)
    catalog = [
        {"name": rec.name, "description": rec.description}
        for rec in registry._all_records
        if rec.valid and rec.name not in _EXCLUDED_TOOLS
    ]
    return registry, catalog


def _decide_next_step(goal: str, catalog: list[dict], history: list[str]) -> dict | None:
    """One planning call. Returns a dict shaped either
    {"done": false, "tool": ..., "parameters": {...}} or
    {"done": true, "answer": "..."} — or None if the model didn't answer."""
    tools_desc = "\n".join(f"- {c['name']}: {c['description']}" for c in catalog)
    hist_desc = "\n".join(history) if history else "(nothing done yet)"

    prompt = f"""You are the planning step of an autonomous task agent. You never talk to the user directly — you choose exactly ONE next action.

GOAL: {goal}

AVAILABLE TOOLS:
{tools_desc}

WHAT HAS HAPPENED SO FAR:
{hist_desc}

Decide the single next action. Reply with ONLY valid JSON, one of these two shapes:

To call a tool:
{{"done": false, "tool": "<tool name from the list above, spelled exactly>", "parameters": {{...}}}}

To finish (the goal is achieved, or nothing here can make further progress):
{{"done": true, "answer": "<one or two short natural spoken sentences telling the user what was done or found>"}}

Rules:
- "tool" must be one of the exact names listed above — never invent one.
- "parameters" must match what that tool expects; infer sensible values from the goal and the history.
- If the history already shows the goal is accomplished, finish immediately rather than repeating work.
- If a tool keeps failing or no tool here fits, finish with "done": true and say so honestly in "answer".
- JSON only. No markdown fences, no commentary before or after it."""

    result = gemini.as_json(prompt, tier=gemini.SMART, timeout_ms=STEP_TIMEOUT_MS, default=None)
    return result if isinstance(result, dict) else None


def _summarize(goal: str, history: list[str]) -> str:
    """Used only when the step budget runs out without the planner finishing
    cleanly — turns the raw step log into one honest spoken sentence instead
    of just going silent."""
    if not history:
        return ""
    prompt = (
        f"Goal was: {goal}\n\nSteps taken:\n" + "\n".join(history) +
        "\n\nIn one or two short spoken sentences, tell the user what was "
        "accomplished and what, if anything, is still unresolved. Plain "
        "text, no markdown."
    )
    return gemini.text(prompt, tier=gemini.SMART, timeout_ms=STEP_TIMEOUT_MS, default="")


def run(parameters: dict, player=None, session_memory=None) -> str:
    goal = str((parameters or {}).get("goal", "")).strip()
    if not goal:
        return "Sir, I need a goal to work on before I can start."

    def log(msg: str):
        print(f"[Agent] {msg}")
        if player:
            try:
                player.write_log(f"JARVIS: {msg}")
            except Exception:
                pass

    try:
        registry, catalog = _load_toolbox()
    except Exception as e:
        return f"Sir, the agent couldn't start: {e}"

    if not catalog:
        return "Sir, no tools are available for me to work with right now."

    history: list[str] = []
    log(f"Working on: {goal}")

    for step in range(1, MAX_STEPS + 1):
        try:
            plan = _decide_next_step(goal, catalog, history)
        except Exception as e:
            log(f"Planning step failed: {e}")
            break

        if plan is None:
            log("Planner didn't respond — stopping.")
            break

        if plan.get("done"):
            answer = str(plan.get("answer") or "Done.").strip()
            log(f"Finished after {step - 1} step(s).")
            return answer

        tool_name = str(plan.get("tool") or "").strip()
        tool_args = plan.get("parameters")
        tool_args = tool_args if isinstance(tool_args, dict) else {}

        valid_names = {c["name"] for c in catalog}
        if tool_name not in valid_names:
            history.append(f"Step {step}: chose unknown tool '{tool_name}' — skipped.")
            log(f"Step {step}: planner picked an unavailable tool ('{tool_name}') — skipping.")
            continue

        log(f"Step {step}: {tool_name}({tool_args})")
        try:
            result = registry.run(tool_name, tool_args, ctx={"player": player})
        except Exception as e:
            result = f"error: {e}"
        result = str(result)[:1500]
        log(f"-> {result[:200]}")
        history.append(f"Step {step}: called {tool_name}({json.dumps(tool_args)}) -> {result}")

    try:
        summary = _summarize(goal, history)
    except Exception:
        summary = ""
    return summary or (
        f"Sir, I made {len(history)} attempt(s) on that but couldn't finish "
        f"within my step limit — you may want to break it into smaller requests."
    )
