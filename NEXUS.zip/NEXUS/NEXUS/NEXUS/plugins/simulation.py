"""Simulacrum — the fictional JARVIS's "run a simulation" ability.

One tool, any scenario. Known scenarios run real models (epidemic SIR,
orbital mechanics, ballistics, logistic growth, Lotka-Volterra, double
pendulum chaos, rocket ascent); anything else falls to a universal
Monte-Carlo simulacrum so "run a simulation of X" always produces an honest,
quantified answer rather than a shrug.

Each run generates a Stark-styled interactive dashboard (sliders re-run the
model live, canvas animation capped ~40 fps, paused when the tab is hidden —
the house rule for every animation here) and opens it in the browser. The
headline numbers are computed in Python too, so JARVIS can speak the result
without reading the screen.
"""

from __future__ import annotations

import json
import math
import random
import re
import sys
import webbrowser
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR   = _base_dir()
STATE_DIR  = BASE_DIR / "state" / "simulations"
PAGE_PATH  = STATE_DIR / "simulacrum.html"

PLUGIN = {
    "name": "simulation",
    "description": (
        "Runs interactive simulations and opens a live Stark dashboard with the "
        "results. Supported models: epidemic/disease spread (SIR), orbital "
        "mechanics (satellites, moons, gravity), projectile/ballistics, "
        "population growth (logistic), predator-prey ecosystems, double pendulum "
        "chaos, rocket ascent — and ANY other scenario falls back to a universal "
        "Monte-Carlo simulacrum (optimistic/expected/pessimistic outcomes with "
        "probabilities). Use when the user says 'run a simulation', 'simulate "
        "...', 'model what happens if...', 'what are the odds...'. Returns the "
        "headline numbers so you can report them aloud."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "scenario": {
                "type": "STRING",
                "description": (
                    "What to simulate, e.g. 'a pandemic spreading through a city "
                    "of 10 million', 'a satellite in low orbit', 'projectile "
                    "fired at 45 degrees', 'rabbit and fox populations', 'a "
                    "double pendulum', 'rocket launch', 'chances my project "
                    "takes over 3 months'."
                ),
            },
            "set": {
                "type": "OBJECT",
                "description": (
                    "Optional parameter overrides by key, e.g. {\"beta\": 0.45, "
                    "\"angle\": 30}. Keys match the dashboard's sliders."
                ),
            },
        },
        "required": ["scenario"],
    },
}


# ── scenario registry ────────────────────────────────────────────────────────
# keys: keywords | title | params {key: (label, min, max, default, unit)}

SCENARIOS: dict[str, dict] = {
    "epidemic": {
        "keywords": ("pandemic", "epidemic", "virus", "infection", "plague",
                     "outbreak", "covid", "disease", "contagion", "sir"),
        "title": "EPIDEMIC SPREAD — SIR MODEL",
        "params": {
            "beta":  ("infectivity β", 0.05, 0.60, 0.30, ""),
            "gamma": ("recovery γ",   0.02, 0.50, 0.10, ""),
            "pop_m": ("population (M)", 0.1, 100.0, 10.0, "M"),
        },
    },
    "orbit": {
        "keywords": ("orbit", "satellite", "gravity", "spacecraft",
                     "two body", "kepler"),
        "title": "ORBITAL MECHANICS — TWO-BODY",
        "params": {
            "alt_km": ("altitude", 200, 40000, 400, "km"),
            "vel_kms": ("velocity", 3.0, 12.0, 7.7, "km/s"),
        },
    },
    "projectile": {
        "keywords": ("projectile", "cannon", "ballistics", "catapult",
                     "trebuchet", "fired", "bullet drop"),
        "title": "BALLISTICS — PROJECTILE MOTION",
        "params": {
            "v0":   ("muzzle velocity", 5, 300, 50, "m/s"),
            "angle": ("angle", 5, 85, 45, "°"),
            "g":    ("gravity", 1.6, 24.8, 9.81, "m/s²"),
        },
    },
    "population": {
        "keywords": ("population", "logistic", "bacteria",
                     "breeding", "exponential", "insects", "colony"),
        "title": "POPULATION GROWTH — LOGISTIC",
        "params": {
            "p0": ("initial pop", 1, 1000, 10, ""),
            "r":  ("growth rate", 0.01, 0.50, 0.10, "/day"),
            "k":  ("carrying cap", 100, 100000, 5000, ""),
        },
    },
    "predprey": {
        "keywords": ("predator", "prey", "ecosystem", "wolves", "foxes",
                     "lotka", "volterra", "food chain", "rabbits and",
                     "fox population", "wolf", "hunting"),
        "title": "ECOSYSTEM — PREDATOR vs PREY",
        "params": {
            "prey0": ("prey start", 10, 200, 40, ""),
            "pred0": ("predator start", 2, 80, 9, ""),
            "alpha": ("prey growth α", 0.5, 1.5, 1.0, ""),
            "gamma": ("predator loss γ", 0.5, 1.5, 1.0, ""),
        },
    },
    "pendulum": {
        "keywords": ("pendulum", "chaos", "swing", "double pendulum"),
        "title": "DOUBLE PENDULUM — CHAOS WATCH",
        "params": {
            "theta1": ("start angle", 10, 170, 120, "°"),
            "l1": ("length 1", 0.5, 2.0, 1.0, "m"),
            "l2": ("length 2", 0.5, 2.0, 1.0, "m"),
        },
    },
    "rocket": {
        "keywords": ("rocket", "launch", "thrust", "delta-v", "apogee",
                     "booster", "missile", "missile"),
        "title": "ROCKET ASCENT — VERTICAL",
        "params": {
            "thrust":  ("thrust", 100, 8000, 1500, "kN"),
            "fuel_t":  ("fuel", 10, 500, 100, "t"),
            "burn":    ("burn rate", 50, 2000, 300, "kg/s"),
            "dry_t":   ("dry mass", 5, 60, 25, "t"),
        },
    },
    "montecarlo": {
        "keywords": (),
        "title": "UNIVERSAL SIMULACRUM — MONTE CARLO",
        "params": {
            "best":  ("optimistic outcome", 1, 1000000, 60, ""),
            "likely": ("expected outcome", 1, 1000000, 90, ""),
            "worst": ("pessimistic outcome", 1, 1000000, 180, ""),
            "thresh": ("success threshold", 1, 1000000, 120, ""),
            "trials": ("trials", 10000, 200000, 50000, ""),
        },
    },
}

_ORDER = ["epidemic", "orbit", "projectile", "population",
          "predprey", "pendulum", "rocket", "montecarlo"]

# ── the 100+ scenario library ────────────────────────────────────────────────
# Named, pre-parameterised runs across every model class, so "run a simulation
# of X" hits a REAL scenario with tuned numbers instead of a generic fallback.
# Each entry: (scenario id, overrides, what-can-happen list). JARVIS can also
# compose his own from these ingredients.
SCENARIO_LIBRARY: list[tuple[str, dict, list[str]]] = [
    # — EPIDEMIC (12) —
    ("epidemic", {"beta": 0.12, "gamma": 0.10, "pop_m": 1.0},
     ["burns out in weeks with barely a peak", "hospitals never exceed baseline", "herd immunity stalls spread by month 3"]),
    ("epidemic", {"beta": 0.30, "gamma": 0.10, "pop_m": 10.0},
     ["one sharp wave, ~30% peak, ICUs overrun at week 6", "second wave if immunity wanes", "recovery majority by day 120"]),
    ("epidemic", {"beta": 0.50, "gamma": 0.08, "pop_m": 50.0},
     ["explosive first wave, >60% peak", "near-total infection inside 90 days", "healthcare collapse window days 30–70"]),
    ("epidemic", {"beta": 0.30, "gamma": 0.20, "pop_m": 10.0},
     ["fast recovery halves the peak", "two-wave echo if behaviour relaxes", "endemic low simmer after day 200"]),
    ("epidemic", {"beta": 0.22, "gamma": 0.15, "pop_m": 0.5},
     ["small city: wave passes in 60 days", "spike-and-crash shape, not a plateau"]),
    ("epidemic", {"beta": 0.45, "gamma": 0.05, "pop_m": 5.0},
     ["long infectious period → months-long plateau", "slow burn, near-universal infection"]),
    ("epidemic", {"beta": 0.10, "gamma": 0.30, "pop_m": 3.0},
     ["fizzles: R0 well under 1", "zero outbreak from a single introduction"]),
    ("epidemic", {"beta": 0.35, "gamma": 0.12, "pop_m": 100.0},
     ["nation-scale wave, peak around day 45", "rural wave lags cities by weeks"]),
    ("epidemic", {"beta": 0.25, "gamma": 0.10, "pop_m": 10.0},
     ["moderate wave, flattenable by distancing", "rebound on relaxation day 90"]),
    ("epidemic", {"beta": 0.40, "gamma": 0.18, "pop_m": 20.0},
     ["high infectivity + high recovery → sharp narrow peak", "overwhelm window under 3 weeks"]),
    ("epidemic", {"beta": 0.28, "gamma": 0.14, "pop_m": 7.0},
     ["classic 2-month outbreak", "post-peak tail lingers 100+ days"]),
    ("epidemic", {"beta": 0.60, "gamma": 0.25, "pop_m": 15.0},
     ["ultra-fast strain: whole wave in 30 days", "chaotic contact-tracing collapse"]),
    # — ORBIT (14) —
    ("orbit", {"alt_km": 400, "vel_kms": 7.7},
     ["circular LEO, 90-minute laps", "decay in ~5 years without boosts"]),
    ("orbit", {"alt_km": 400, "vel_kms": 8.2},
     ["elliptical rise toward GTO territory", "perigee stays clear, apogee climbs"]),
    ("orbit", {"alt_km": 400, "vel_kms": 11.0},
     ["trans-lunar energy — escapes the well", "goodbye Earth, hello deep space"]),
    ("orbit", {"alt_km": 35786, "vel_kms": 3.07},
     ["geostationary lock: hangs over one spot", "24-hour period, zero drift"]),
    ("orbit", {"alt_km": 20000, "vel_kms": 3.9},
     ["MEO navigation-satellite regime (GPS class)", "12-hour period, semi-synchronous"]),
    ("orbit", {"alt_km": 550, "vel_kms": 7.6},
     ["Starlink-shell orbit", "atmospheric drag measurable, reboost cadence ~months"]),
    ("orbit", {"alt_km": 800, "vel_kms": 7.5},
     ["sun-synchronous territory", "ground track repeats every ~100 minutes"]),
    ("orbit", {"alt_km": 200, "vel_kms": 7.9},
     ["skimming orbit — drag is brutal", "days to live without thrust"]),
    ("orbit", {"alt_km": 1000, "vel_kms": 7.35},
     ["stable for decades", "debris zone concerns"]),
    ("orbit", {"alt_km": 363, "vel_kms": 10.5},
     ["highly elliptical transfer", "coast phase long enough for corrections"]),
    ("orbit", {"alt_km": 500, "vel_kms": 10.9},
     ["escape trajectory with margin", "Mars-transfer class energy"]),
    ("orbit", {"alt_km": 500, "vel_kms": 6.5},
     ["sub-orbital: reentry ellipse", "impact footprint 1000+ km downrange"]),
    ("orbit", {"alt_km": 400, "vel_kms": 6.0},
     ["ballistic arc, not an orbit", "brink of orbit — more speed or more altitude"]),
    ("orbit", {"alt_km": 12000, "vel_kms": 4.5},
     ["eccentric MEO, Molniya-adjacent", "dwell time over high latitudes"]),
    # — PROJECTILE (12) —
    ("projectile", {"v0": 50, "angle": 45, "g": 9.81},
     ["textbook 45°: max range for the speed", "clean parabola, apex a quarter of range"]),
    ("projectile", {"v0": 100, "angle": 30, "g": 9.81},
     ["flat trajectory, short hang time", "wind matters less than drop"]),
    ("projectile", {"v0": 100, "angle": 75, "g": 9.81},
     ["near-vertical: height over distance", "hang time long enough to wave at it"]),
    ("projectile", {"v0": 240, "angle": 40, "g": 9.81},
     ["artillery regime — kilometres downrange", "air resistance would halve this in reality"]),
    ("projectile", {"v0": 30, "angle": 45, "g": 1.62},
     ["lunar gravity: 4× the range", "the golf-shot theorem, demonstrated"]),
    ("projectile", {"v0": 50, "angle": 45, "g": 3.71},
     ["Mars gravity: 2.6× Earth range", "same arm, red-planet distance"]),
    ("projectile", {"v0": 800, "angle": 35, "g": 9.81},
     ["ballistic-missile class arc", "apex above the stratosphere"]),
    ("projectile", {"v0": 15, "angle": 60, "g": 9.81},
     ["kid-throws-a-ball territory", "gravity does what gravity does"]),
    ("projectile", {"v0": 340, "angle": 45, "g": 9.81},
     ["supersonic launch — Mach 1 muzzle", "range beyond 10 km vacuum-class"]),
    ("projectile", {"v0": 60, "angle": 20, "g": 9.81},
     ["skimming shot, 20°: fast and flat", "bounces on hard ground, literally"]),
    ("projectile", {"v0": 90, "angle": 55, "g": 9.81},
     ["mortar-like lob, steep and short", "apex over 100 m"]),
    ("projectile", {"v0": 45, "angle": 50, "g": 9.81},
     ["water-balloon candidacy: strong", "apex and range both modest, dignity intact"]),
    # — POPULATION (10) —
    ("population", {"p0": 10, "r": 0.10, "k": 5000},
     ["smooth S-curve to capacity in ~3 months", "no overshoot at this growth rate"]),
    ("population", {"p0": 10, "r": 0.35, "k": 5000},
     ["fast growth with overshoot-and-crash cycles", "oscillates before settling"]),
    ("population", {"p0": 10, "r": 0.50, "k": 5000},
     ["chaotic boom-bust — deterministic chaos, no crash needed", "population swings wildly forever"]),
    ("population", {"p0": 100, "r": 0.05, "k": 100000},
     ["slow burn: years to reach capacity", "resource limit barely felt at first"]),
    ("population", {"p0": 500, "r": 0.20, "k": 2000},
     ["crowded petri dish: cap hit early", "density pressure immediate"]),
    ("population", {"p0": 2, "r": 0.15, "k": 10000},
     ["from two to ten thousand — the ark problem", "long lag, then explosive climb"]),
    ("population", {"p0": 50, "r": 0.25, "k": 50000},
     ["bacterial bloom curve", "log phase visible day by day"]),
    ("population", {"p0": 10, "r": 0.08, "k": 5000},
     ["gentle growth, conservation-biologist's dream", "approaches equilibrium asymptotically"]),
    ("population", {"p0": 20, "r": 0.45, "k": 10000},
     ["boom, bust, boom — predator-prey in one species", "never settles, never dies"]),
    ("population", {"p0": 1000, "r": 0.12, "k": 1200},
     ["already at the cliff edge", "instant saturation, fragile equilibrium"]),
    # — PREDATOR-PREY (10) —
    ("predprey", {"prey0": 40, "pred0": 9, "alpha": 1.0, "gamma": 1.0},
     ["classic Lotka-Volterra cycles", "predators lag prey by a quarter-cycle"]),
    ("predprey", {"prey0": 80, "pred0": 4, "alpha": 1.2, "gamma": 0.9},
     ["prey boom fuels predator boom", "overshoot crash on both sides"]),
    ("predprey", {"prey0": 20, "pred0": 30, "alpha": 1.0, "gamma": 1.1},
     ["predator-heavy start: prey crushed early", "predator starvation spiral risk"]),
    ("predprey", {"prey0": 100, "pred0": 10, "alpha": 0.8, "gamma": 0.8},
     ["gentle cycles, long coexistence", "the balance nature documentaries promise"]),
    ("predprey", {"prey0": 60, "pred0": 20, "alpha": 1.4, "gamma": 0.6},
     ["volatile ecosystem, boom-bust amplitude grows", "one bad winter from collapse"]),
    ("predprey", {"prey0": 30, "pred0": 6, "alpha": 0.9, "gamma": 1.2},
     ["predators on the edge: prey escapes control", "prey irruption, habitat degradation"]),
    ("predprey", {"prey0": 50, "pred0": 15, "alpha": 1.1, "gamma": 1.0},
     ["stable limit cycle emerging", "period ~6 time units"]),
    ("predprey", {"prey0": 150, "pred0": 5, "alpha": 1.0, "gamma": 1.0},
     ["prey explosion followed by predator explosion", "the classic four-phase drama"]),
    ("predprey", {"prey0": 45, "pred0": 25, "alpha": 1.0, "gamma": 1.0},
     ["tight coupling, fast oscillations", "delicate: perturbation shifts everything"]),
    ("predprey", {"prey0": 25, "pred0": 12, "alpha": 0.7, "gamma": 0.7},
     ["low-energy equilibrium, slow dance", "extinction risk from any shock"]),
    # — PENDULUM (8) —
    ("pendulum", {"theta1": 30, "l1": 1.0, "l2": 1.0},
     ["regular quasiperiodic swing at small angle", "ghost and twin stay friends for ages"]),
    ("pendulum", {"theta1": 120, "l1": 1.0, "l2": 1.0},
     ["full chaos: divergence inside seconds", "butterfly effect, demonstrated live"]),
    ("pendulum", {"theta1": 170, "l1": 1.2, "l2": 0.8},
     ["extreme release: violent tumbling", "energy exchange flips unpredictably"]),
    ("pendulum", {"theta1": 90, "l1": 1.5, "l2": 1.5},
     ["long arms slow the chaos down", "divergence time stretches past 10 s"]),
    ("pendulum", {"theta1": 60, "l1": 0.6, "l2": 0.6},
     ["short arms, quick wit, quick chaos", "dense trail art"]),
    ("pendulum", {"theta1": 150, "l1": 0.8, "l2": 1.6},
     ["asymmetric arms: organic, alien motion", "never repeats a configuration"]),
    ("pendulum", {"theta1": 10, "l1": 1.0, "l2": 1.0},
     ["near-linear: the textbook pendulum", "predictable for minutes"]),
    ("pendulum", {"theta1": 135, "l1": 1.1, "l2": 0.9},
     ["chaos with style — the screen-saver setting", "flips through vertical"]),
    # — ROCKET (12) —
    ("rocket", {"thrust": 1500, "fuel_t": 100, "burn": 300, "dry_t": 25},
     ["SSTO-ish profile: apogee in the hundreds of km", "gravity losses dominate after burnout"]),
    ("rocket", {"thrust": 4000, "fuel_t": 300, "burn": 800, "dry_t": 60},
     ["heavy-lift class: orbital velocity is close", "max-Q stress around 45 s"]),
    ("rocket", {"thrust": 700, "fuel_t": 40, "burn": 200, "dry_t": 8},
     ["sounding rocket: suborbital hop, 100+ km", "minutes of weightlessness"]),
    ("rocket", {"thrust": 2500, "fuel_t": 150, "burn": 1500, "dry_t": 30},
     ["sprint profile: burns out fast, coasts forever", "velocity peak then ballistic arc"]),
    ("rocket", {"thrust": 1200, "fuel_t": 200, "burn": 150, "dry_t": 20},
     ["slow burn: long thrust, gentle climb", "efficient but gravity-leaky"]),
    ("rocket", {"thrust": 900, "fuel_t": 500, "burn": 100, "dry_t": 40},
     ["cruise-climb: thrust-to-weight near 1", "grinds upward, enormous delta-v reserve"]),
    ("rocket", {"thrust": 600, "fuel_t": 30, "burn": 400, "dry_t": 12},
     ["firework: spectacular, brief, mostly vertical", "apogee embarrassingly low"]),
    ("rocket", {"thrust": 3000, "fuel_t": 100, "burn": 250, "dry_t": 15},
     ["acceleration sled: Mach 3+ by burnout", "structural margins tested"]),
    ("rocket", {"thrust": 5000, "fuel_t": 450, "burn": 900, "dry_t": 55},
     ["moon-shot class stack", "escape-energy regime"]),
    ("rocket", {"thrust": 2000, "fuel_t": 80, "burn": 350, "dry_t": 22},
     ["missile-class interceptor profile", "terminal velocity far past Mach 5"]),
    ("rocket", {"thrust": 1100, "fuel_t": 120, "burn": 220, "dry_t": 18},
     ["balanced testbed: clean telemetry", "the one you show investors"]),
    ("rocket", {"thrust": 450, "fuel_t": 90, "burn": 120, "dry_t": 30},
     ["underpowered: it rises, thinks, and sits back down", "thrust-to-weight under 1 at burnout — physics wins"]),
    # — MONTE-CARLO / LIFE (24) —
    ("montecarlo", {"best": 30, "likely": 60, "worst": 120, "thresh": 90, "trials": 50000},
     ["project lands in ~2 months if nothing bites", "the 90-day mark is a coin flip", "worst case: double the estimate — add buffer now"]),
    ("montecarlo", {"best": 500, "likely": 2000, "worst": 8000, "thresh": 3000, "trials": 50000},
     ["channel growth: 2k expected, 3k within reach", "viral tail exists but don't bet the rent"]),
    ("montecarlo", {"best": 2, "likely": 5, "worst": 14, "thresh": 7, "trials": 50000},
     ["days to launch: 5 expected, 7 is the risk line", "scope creep is the whole tail"]),
    ("montecarlo", {"best": 10, "likely": 40, "worst": 200, "thresh": 100, "trials": 50000},
     ["users after launch: fat tail on the upside", "100-user mark ~20% odds"]),
    ("montecarlo", {"best": 1000, "likely": 5000, "worst": 20000, "thresh": 10000, "trials": 50000},
     ["revenue scenario: 5k expected monthly", "the 10k month arrives ~15% of the time"]),
    ("montecarlo", {"best": 1, "likely": 3, "worst": 9, "thresh": 5, "trials": 50000},
     ["days until motivation returns: 3 expected", "the 5-day slump is real but temporary"]),
    ("montecarlo", {"best": 20, "likely": 45, "worst": 90, "thresh": 60, "trials": 50000},
     ["exam score: 45 expected with a solid tail", "60+ needs the good half of the distribution"]),
    ("montecarlo", {"best": 5, "likely": 12, "worst": 40, "thresh": 20, "trials": 50000},
     ["bug-fix hours: 12 expected, 20 is a bad day", "the 40-hour nightmare is rare but real"]),
    ("montecarlo", {"best": 200, "likely": 900, "worst": 4000, "thresh": 1500, "trials": 50000},
     ["new video views: 900 expected", "1.5k+ means the algorithm noticed"]),
    ("montecarlo", {"best": 3, "likely": 7, "worst": 21, "thresh": 10, "trials": 50000},
     ["days of coffee left: 7 expected", "the 21-day scenario assumes you find a second jar"]),
    ("montecarlo", {"best": 50, "likely": 150, "worst": 500, "thresh": 250, "trials": 50000},
     ["peak concurrent players: 150 expected", "250+ needs a streamer pickup"]),
    ("montecarlo", {"best": 1, "likely": 4, "worst": 12, "thresh": 6, "trials": 50000},
     ["weeks until the side project ships: 4 expected", "6+ weeks means scope won"]),
    ("montecarlo", {"best": 15, "likely": 60, "worst": 300, "thresh": 120, "trials": 50000},
     ["downloads in week one: 60 expected", "300 is the front-page scenario"]),
    ("montecarlo", {"best": 2, "likely": 6, "worst": 18, "thresh": 8, "trials": 50000},
     ["days until the reply arrives: about a week", "the 18-day case means following up"]),
    ("montecarlo", {"best": 100, "likely": 400, "worst": 1500, "thresh": 800, "trials": 50000},
     ["new followers this month: 400 expected", "800+ requires consistent posting"]),
    ("montecarlo", {"best": 10, "likely": 25, "worst": 70, "thresh": 40, "trials": 50000},
     ["hours of battery per charge cycle: 25 expected", "below 15 means battery degradation"]),
    ("montecarlo", {"best": 300, "likely": 1200, "worst": 5000, "thresh": 2000, "trials": 50000},
     ["steps this month (thousands): 1.2M expected", "2M is an active month"]),
    ("montecarlo", {"best": 4, "likely": 9, "worst": 25, "thresh": 14, "trials": 50000},
     ["days until the build compiles first time: 9", "the 25-day scenario involves a dependency"]),
    ("montecarlo", {"best": 40, "likely": 110, "worst": 350, "thresh": 200, "trials": 50000},
     ["commute minutes next week: 110 total", "200+ means construction season"]),
    ("montecarlo", {"best": 1, "likely": 2, "worst": 6, "thresh": 3, "trials": 50000},
     ["attempts until the deploy goes green: 2", "the 6-attempt universe involves DNS"]),
    ("montecarlo", {"best": 25, "likely": 80, "worst": 260, "thresh": 150, "trials": 50000},
     ["newsletter signups: 80 expected", "150+ needs a cross-post"]),
    ("montecarlo", {"best": 6, "likely": 18, "worst": 55, "thresh": 30, "trials": 50000},
     ["hours until the render finishes: 18", "the 55-hour case is the 4K one"]),
    ("montecarlo", {"best": 500, "likely": 1800, "worst": 7000, "thresh": 3500, "trials": 50000},
     ["launch-day visitors: 1.8k expected", "3.5k+ means it escaped containment"]),
    ("montecarlo", {"best": 8, "likely": 20, "worst": 60, "thresh": 35, "trials": 50000},
     ["days of good weather left: 20", "35+ would break the regional record"]),
]


def _match_library(prompt: str) -> tuple[str, dict, list[str]] | None:
    """Best library match for a prompt: word-overlap scoring against the
    scenario keys and the what-can-happen text."""
    p = set(re.findall(r"[a-z0-9]+", (prompt or "").lower()))
    stop = {"a", "an", "the", "of", "for", "my", "in", "on", "to", "and",
            "what", "how", "if", "with", "simulation", "simulate", "model",
            "run", "scenario", "happens", "chances", "odds", "this", "is",
            "it", "be", "will", "can", "over", "under", "time", "days",
            "years", "month", "months", "day", "week", "weeks", "year"}
    p -= stop
    if not p:
        return None
    best, best_score = None, 0
    for sid, over, outcomes in SCENARIO_LIBRARY:
        words = set(re.findall(r"[a-z0-9]+", " ".join(outcomes).lower()))
        words |= {k for k in over} | set(SCENARIOS[sid]["keywords"])
        score = len(p & words)
        # the overrides' numeric keys rarely match a prompt; title-less runs
        # need the outcome text to carry the match
        if score > best_score:
            best, best_score = (sid, over, outcomes), score
    return best if best_score >= 2 else None


def _pick(prompt: str) -> str:
    p = (prompt or "").lower()
    # predator/prey before population: "rabbit and fox populations" names two
    # species — "population" alone must not claim it.
    if any(k in p for k in SCENARIOS["predprey"]["keywords"]):
        return "predprey"
    for sid in _ORDER[:-1]:
        if any(k in p for k in SCENARIOS[sid]["keywords"]):
            return sid
    return "montecarlo"


def _defaults(sid: str) -> dict:
    return {k: v[3] for k, v in SCENARIOS[sid]["params"].items()}


# ── python-side headline maths (mirrors the dashboard) ───────────────────────

def _summary(sid: str, v: dict) -> str:
    """A one-breath JARVIS line with the run's headline numbers."""
    if sid == "epidemic":
        s, i, r, beta, gam = 1.0, 0.001, 0.0, v["beta"], v["gamma"]
        peak, day, total = i, 0, 0.0
        t = 0.0
        for _ in range(40000):
            ns = s - beta * s * i * 0.05
            ni = i + (beta * s * i - gam * i) * 0.05
            nr = r + gam * i * 0.05
            s, i, r, t = max(0, ns), max(0, ni), min(1, nr), t + 0.05
            if i > peak:
                peak, day = i, t
            if i < 1e-5 and t > 10:
                break
        total = 1 - s
        return (f"Peak infection: {peak*100:.1f}% of the population on day "
                f"{day:.0f}; {total*100:.0f}% infected overall before it "
                f"burns out. Each sick person infects about {beta/gam:.1f} others.")
    if sid == "orbit":
        mu, re = 398600.0, 6371.0
        r = re + v["alt_km"]
        vel = v["vel_kms"]
        esc = math.sqrt(2 * mu / r)
        if vel >= esc:
            return (f"At {vel:.1f} km/s that is above escape velocity "
                    f"({esc:.2f} km/s) — the craft leaves Earth for good, sir.")
        en = vel * vel / 2 - mu / r
        a = -mu / (2 * en)
        h = r * vel
        e = math.sqrt(max(0.0, 1 + 2 * en * h * h / (mu * mu)))
        per = 2 * math.pi * math.sqrt(a ** 3 / mu)
        return (f"Orbit locked: {a - re:.0f} km mean altitude, period "
                f"{per/3600:.2f} hours, eccentricity {e:.3f} "
                f"({'circular' if e < 0.05 else 'elliptical'}).")
    if sid == "projectile":
        rad = math.radians(v["angle"])
        t_f = 2 * v["v0"] * math.sin(rad) / v["g"]
        rng = v["v0"] ** 2 * math.sin(2 * rad) / v["g"]
        h = (v["v0"] * math.sin(rad)) ** 2 / (2 * v["g"])
        return (f"Range {rng:.0f} m, apex {h:.0f} m, flight time {t_f:.1f} s "
                f"— forty-five degrees remains optimal for distance, sir.")
    if sid == "population":
        p, r, k, t, t90 = float(v["p0"]), v["r"], float(v["k"]), 0.0, None
        while t < 2000:
            p += r * p * (1 - p / k) * 0.05
            t += 0.05
            if t90 is None and p >= 0.9 * k:
                t90 = t
        return (f"The colony reaches 90% of carrying capacity ({k:.0f}) on day "
                f"{t90:.0f}" if t90 else
                f"Sluggish growth — 90% capacity is beyond the horizon, sir.")
    if sid == "predprey":
        y, x = float(v["prey0"]), float(v["pred0"])
        a, g, b, d = v["alpha"], v["gamma"], 0.05, 0.03
        ys, xs, last, period = [], [], None, None
        t = 0.0
        for n in range(200000):
            y += (a * y - b * y * x) * 0.002
            x += (b * y * x - g * x) * 0.002
            t += 0.002
            if n % 10 == 0:
                ys.append(y); xs.append(x)
                if x > g / b * 0.2 and last is None:
                    last = t
                elif last is not None and x > g / b * 0.2 and t - last > 1:
                    period = t - last; last = t
        return (f"The system cycles: prey average {sum(ys)/len(ys):.0f}, "
                f"predators {sum(xs)/len(xs):.0f}, boom-bust every "
                f"{period:.0f} time units" if period and period < 500 else
                f"Populations wander without a clean cycle — the ecosystem is "
                f"on the edge, sir.")
    if sid == "pendulum":
        th1 = math.radians(v["theta1"]); th2 = th1 * 0.9
        w1 = w2 = 0.0
        g, l1, l2 = 9.81, v["l1"], v["l2"]
        dt = 0.0005
        div_t = None
        g1 = th1 + 1e-6
        gw1 = 0.0
        t = 0.0
        for n in range(60000):
            a1 = (-g*(2*math.sin(th1)) - math.sin(th1-th2)*(2*w2*w2*l2 +
                  g*math.cos(th2))) / (l1*(2 - math.cos(2*th1-2*th2)))
            a2 = (2*math.sin(th1-th2)*(w1*w1*l1*(2 - math.cos(2*th1-2*th2)) +
                  g*(2*math.sin(th1)) + w2*w2*l2*math.cos(th1-th2))) / \
                 (l2*(2 - math.cos(2*th1-2*th2)))
            w1 += a1*dt; w2 += a2*dt
            th1 += w1*dt; th2 += w2*dt
            ga1 = (-g*(2*math.sin(g1)) - math.sin(g1-th2)*(2*gw1*gw1*l2 +
                  g*math.cos(th2))) / (l1*(2 - math.cos(2*g1-2*th2)))
            gw1 += ga1*dt; g1 += gw1*dt
            t += dt
            if div_t is None and abs(g1 - th1) > 0.3:
                div_t = t
        return (f"Chaos confirmed: a hair's-breadth change at the start "
                f"diverges completely after {div_t:.1f} s"
                if div_t and div_t < 20 else
                f"Surprisingly tame — the swing stays predictable for the run.")
    if sid == "rocket":
        T, fuel, burn, dry = v["thrust"]*1000, v["fuel_t"]*1000, v["burn"], v["dry_t"]*1000
        g = 9.81
        m = dry + fuel
        y = vy = t = 0.0
        apogee = tbo = vmax = 0.0
        dt = 0.01
        while t < 600:
            if fuel > 0:
                a = T / m - g
                fuel -= burn * dt
                m = dry + max(0.0, fuel)
                tbo = t
            else:
                a = -g
            vy += a * dt
            y += vy * dt
            t += dt
            vmax = max(vmax, vy)
            if y < 0 and t > 1:
                break
            apogee = max(apogee, y)
        return (f"Apogee {apogee/1000:.1f} km at {t:.0f} s, burnout at "
                f"{tbo:.0f} s, max speed {vmax:.0f} m/s — Mach {vmax/343:.1f}.")
    # montecarlo — scaled for 10,000–200,000 trials, vectorised statistics
    best, like, worst = v["best"], v["likely"], v["worst"]
    lo, exp_, hi = sorted((best, like, worst))
    n = int(v["trials"])
    rng = random.Random(42)
    over = below = 0
    total = 0.0
    bins = [0] * 40
    span = (hi - lo) or 1.0
    thresh = v["thresh"]
    c = (exp_ - lo) / span if span else 0.5
    for _ in range(n):
        u = rng.random()
        if u < c:
            x = lo + math.sqrt(u * span * (exp_ - lo)) if exp_ > lo else lo
        else:
            x = hi - math.sqrt((1 - u) * span * (hi - exp_)) if hi > exp_ else hi
        total += x
        if x > thresh:
            over += 1
        elif x < lo + span * 0.25:
            below += 1
        b = min(39, int((x - lo) / span * 40))
        bins[b] += 1
    mean = total / max(1, n)
    p90 = lo + span * 0.9
    return (f"Across {n:,} trials: expected {mean:.0f}, 9-in-10 land between "
            f"{lo:.0f} and {p90:.0f}. Odds of exceeding {thresh:.0f}: "
            f"{over/max(1,n)*100:.1f}%. Worst-quarter risk: "
            f"{below/max(1,n)*100:.1f}%.")


# ── dashboard ────────────────────────────────────────────────────────────────

def _build_page(sid: str, v: dict) -> str:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    spec = SCENARIOS[sid]
    pjson = json.dumps({k: list(val) for k, val in spec["params"].items()})
    vals = json.dumps(v)
    html = _PAGE
    for k, rep in (("__TITLE__", spec["title"]), ("__SCEN__", sid),
                   ("__PARAMS__", pjson), ("__VALS__", vals)):
        html = html.replace(k, rep)
    PAGE_PATH.write_text(html, encoding="utf-8")
    return str(PAGE_PATH)


def run(parameters: dict, player=None, session_memory=None) -> str:
    parameters = parameters or {}
    prompt = str(parameters.get("scenario", "")).strip()
    if not prompt:
        return ("What shall I simulate, sir? Epidemics, orbits, ballistics, "
                "populations, ecosystems, chaos, rocket launches — or name "
                "any scenario and I'll run the odds on it.")
    sid = _pick(prompt)
    # Scenario library: a tuned pre-built run with its own what-could-happen
    # list beats generic defaults whenever the prompt names one.
    hit = _match_library(prompt)
    outcomes: list[str] = []
    if hit:
        lib_sid, lib_over, outcomes = hit
        sid = lib_sid
    v = _defaults(sid)          # defaults of the FINAL scenario, always
    if hit:
        v.update({k: float(val) for k, val in hit[1].items() if k in v})
    overrides = parameters.get("set") or {}
    if isinstance(overrides, str):
        try:
            overrides = json.loads(overrides)
        except Exception:
            overrides = {}
    for k, val in (overrides or {}).items():
        if k in v:
            try:
                v[k] = float(val)
            except (TypeError, ValueError):
                pass

    path = _build_page(sid, v)
    headline = _summary(sid, v)
    try:
        try:
            from core.opera import open_path
            open_path(path)
        except Exception:
            webbrowser.open(Path(path).as_uri())
    except Exception:
        pass
    if player and hasattr(player, "write_log"):
        try:
            player.write_log(f"SIMULACRUM: {SCENARIOS[sid]['title']} — {headline[:90]}")
        except Exception:
            pass

    tail = ""
    if outcomes:
        tail = (" What could happen: " + "; ".join(outcomes[:3]) + ".")
    return (f"Simulation running, sir — {SCENARIOS[sid]['title'].title()} is on "
            f"your display with live controls. {headline}{tail}")


# ── the dashboard page (placeholders, NOT an f-string — braces stay single) ──

_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>__TITLE__</title>
<style>
  :root { --bg:#00080a; --panel:#00101a; --b:#00a8cc; --bb:#00d4ff;
          --pri:#00d8ff; --txt:#00e8ff; --dim:#0088aa; --acc:#ff6600;
          --grn:#00ffaa; }
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:var(--bg); color:var(--txt); font-family:Consolas,'Segoe UI',monospace;
         padding:20px 26px; min-height:100vh; }
  .dots { position:fixed; inset:0; pointer-events:none; opacity:.5;
          background-image:radial-gradient(#004455 1px, transparent 1px);
          background-size:48px 48px; }
  h1 { font-family:Orbitron,'Segoe UI',monospace; font-size:22px; letter-spacing:4px;
       color:var(--bb); text-shadow:0 0 16px rgba(0,212,255,.4); }
  .sub { color:var(--dim); font-size:11px; letter-spacing:3px; margin:4px 0 16px; }
  .wrap { display:flex; gap:18px; flex-wrap:wrap; align-items:flex-start;
          max-width:100%; }
  .stage { width:644px; max-width:100%; }
  @media (max-width:720px){ .stage { width:100%; } }
  .stage { position:relative; }
  canvas#sim { background:linear-gradient(180deg,#000d14,#00060a);
               border:1px solid var(--b); border-radius:6px;
               box-shadow:0 0 30px rgba(0,212,255,.12) inset; }
  .panel { width:290px; display:flex; flex-direction:column; gap:10px; }
  .card { background:rgba(0,16,26,.85); border:1px solid var(--b); border-radius:6px;
          padding:12px 14px; }
  .card .k { color:var(--dim); font-size:10px; letter-spacing:2px; }
  .card .v { font-family:Orbitron,monospace; font-size:17px; color:var(--pri);
             margin-top:4px; white-space:pre-line; }
  label { display:block; color:var(--dim); font-size:10px; letter-spacing:2px; margin:10px 0 2px; }
  input[type=range] { width:100%; accent-color:var(--bb); }
  .val { float:right; color:var(--pri); }
  button { background:#001018; color:var(--pri); border:1px solid var(--b);
           border-radius:3px; padding:7px 14px; cursor:pointer; letter-spacing:2px;
           font-family:Orbitron,monospace; font-size:11px; margin-top:12px; }
  button:hover { background:var(--b); color:#000; }
  .spark { margin-top:16px; }
</style>
</head>
<body>
<div class="dots"></div>
<h1>&#9672; SIMULACRUM</h1>
<div class="sub">__TITLE__ · STARK INDUSTRIES SIMULATION ENVIRONMENT</div>
<div class="wrap">
  <div class="stage"><canvas id="sim" width="640" height="440"></canvas></div>
  <div class="panel">
    <div class="card"><div class="k">HEADLINE</div><div class="v" id="head">—</div></div>
    <div class="card"><div class="k">CONTROLS — move a slider to re-run</div><div id="sliders"></div>
      <button id="run">❚❚ PAUSE</button>
      <button id="reset">⟲ RESET</button>
    </div>
  </div>
</div>
<div class="spark card"><div class="k">LIVE TRACE</div>
  <canvas id="graph" width="980" height="110"></canvas></div>

<script>
const SCEN = "__SCEN__";
const PARAMS = __PARAMS__;
const START = __VALS__;
const cv = document.getElementById('sim'), cx = cv.getContext('2d');
const gv = document.getElementById('graph'), gx = gv.getContext('2d');
const $ = id => document.getElementById(id);
let vals = Object.assign({}, START);
let state = null, ghost = null, running = true, t = 0, trace = [];

/* ── models: s = state, v = params, dt fixed. Euler keeps them tiny. ── */
const MODELS = {
  epidemic: {
    init(v){ return {s:1, i:0.001, r:0, day:0, peak:0.001, peakDay:0}; },
    step(s,v,dt){
      // Proper per-day dynamics: 3 simulated days per real second keeps the
      // wave watchable and makes the day counter mean actual days.
      const d = dt * 3, b = v.beta, g = v.gamma;
      const ns = s.s - b*s.i*s.s*d, ni = s.i + (b*s.i*s.s - g*s.i)*d,
            nr = s.r + g*s.i*d;
      s.s = Math.max(0, ns); s.i = Math.max(0, ni); s.r = Math.min(1, nr);
      s.day += d;
      if(s.i > s.peak){ s.peak = s.i; s.peakDay = s.day; }
    },
    head(s,v){ return `peak ${(s.peak*100).toFixed(1)}% · day ${s.peakDay.toFixed(0)}\nnow ${(s.i*100).toFixed(2)}% infected`; },
    series(s){ return s.i; },
    draw(s,v,t){
      grid();
      const R = 118, cxx = 400, cyy = 250;
      // One donut, three sequential segments — never stacked arcs.
      const seg = [[s.s, '#00d4ff'], [s.i, '#ff2a4a'], [s.r, '#00ffaa']];
      let a0 = -Math.PI/2;
      seg.forEach(([frac, col]) => {
        if (frac <= 0.0001) return;
        cx.beginPath();
        cx.arc(cxx, cyy, R, a0, a0 + frac*2*Math.PI);
        cx.strokeStyle = col; cx.lineWidth = 26; cx.lineCap = 'butt';
        cx.stroke();
        a0 += frac*2*Math.PI;
      });
      // Centre: the number that matters, big.
      cx.textAlign = 'center';
      cx.fillStyle = '#ff2a4a';
      cx.font = 'bold 34px Orbitron, monospace';
      cx.fillText((s.i*100).toFixed(1) + '%', cxx, cyy - 2);
      cx.fillStyle = '#0088aa'; cx.font = '10px Orbitron';
      cx.fillText('INFECTED NOW', cxx, cyy + 18);
      cx.fillStyle = '#00e8ff';
      cx.fillText('DAY ' + s.day.toFixed(0), cxx, cyy + 38);
      // Legend as dark pills, far from the ring — always readable.
      const pop = (v.pop_m || 10);
      legendPill(24,  42, '#00d4ff', 'SUSCEPTIBLE', (s.s*pop).toFixed(1)+'M · '+(s.s*100).toFixed(0)+'%');
      legendPill(24,  78, '#ff2a4a', 'INFECTED',   (s.i*pop).toFixed(2)+'M · '+(s.i*100).toFixed(1)+'%');
      legendPill(24, 114, '#00ffaa', 'RECOVERED',  (s.r*pop).toFixed(1)+'M · '+(s.r*100).toFixed(0)+'%');
      legendPill(24, 150, '#ff6600', 'PEAK',        (s.peak*100).toFixed(1)+'% on day '+s.peakDay.toFixed(0));
    },
    ghostable: false
  },
  orbit: {
    init(v){
      const mu = 398600, re = 6371, r = re + v.alt_km, vel = v.vel_kms;
      const en = vel*vel/2 - mu/r, a = -mu/(2*en);
      const h = r*vel, e = Math.sqrt(Math.max(0, 1 + 2*en*h*h/(mu*mu)));
      const per = 2*Math.PI*Math.sqrt(Math.pow(a,3)/mu);
      return {r, vel, a, e, ang: 0, escaped: vel >= Math.sqrt(2*mu/r),
              dist: r, per, rate: 2*Math.PI/per * 60};
    },
    step(s,v,dt){
      if(s.escaped){ s.dist += s.vel*dt*200; s.ang += dt*0.4; return; }
      s.ang += s.rate * dt;                     // Kepler's 2nd law, stylised:
      s.dist = s.a * (1 - s.e*s.e) / (1 + s.e*Math.cos(s.ang));
    },
    head(s,v){
      if(s.escaped) return 'ESCAPE TRAJECTORY\ngoodbye, Earth';
      return `period ${(s.per/3600).toFixed(2)} h\neccentricity ${s.e.toFixed(3)}`; },
    series(s){ return s.dist; },
    draw(s,v,t){
      grid();
      const cxx = 320, cyy = 220, scale = 110/7000;
      cx.fillStyle = '#0a2a3a'; cx.beginPath();
      cx.arc(cxx, cyy, 6371*scale, 0, 7); cx.fill();
      cx.strokeStyle = '#00a8cc'; cx.lineWidth = 1.5; cx.stroke();
      if(!s.escaped){
        cx.beginPath();
        cx.ellipse(cxx, cyy, s.a*scale, s.a*Math.sqrt(1-s.e*s.e)*scale, 0, 0, 7);
        cx.strokeStyle = 'rgba(0,212,255,.35)'; cx.setLineDash([4,4]); cx.stroke(); cx.setLineDash([]);
      }
      const px = cxx + Math.cos(s.ang)*s.dist*scale, py = cyy + Math.sin(s.ang)*s.dist*scale;
      cx.fillStyle = '#ff6600'; cx.beginPath(); cx.arc(px, py, 4.5, 0, 7); cx.fill();
      legendPill(24, 42, '#ff6600', 'CRAFT',
                 s.escaped ? 'escaping' : 'ALT ' + (s.dist-6371).toFixed(0) + ' km');
      legendPill(24, 78, '#00d4ff', 'ORBIT',
                 'e=' + s.e.toFixed(3) + ' · ' + (s.per/3600).toFixed(2) + ' h');
    },
    ghostable: false
  },
  projectile: {
    init(v){ return {x:0, y:0, vx:v.v0*Math.cos(v.angle*Math.PI/180),
                     vy:v.v0*Math.sin(v.angle*Math.PI/180), trail:[], done:false}; },
    step(s,v,dt){
      if(s.done) return;
      s.vy -= v.g*dt; s.x += s.vx*dt; s.y += s.vy*dt;
      s.trail.push([s.x, s.y]);
      if(s.y < 0 && s.trail.length > 2){ s.done = true; }
    },
    head(s,v){
      const rad = v.angle*Math.PI/180;
      const apex = Math.pow(v.v0*Math.sin(rad), 2) / (2*v.g);
      return `range ${(v.v0*v.v0*Math.sin(2*rad)/v.g).toFixed(0)} m\napex ${apex.toFixed(0)} m`; },
    series(s){ return Math.max(0, s.y); },
    draw(s,v,t){
      grid();
      const cxx = 40, gy = 400, scale = 0.5;
      cx.strokeStyle = '#00a8cc'; cx.lineWidth = 1.5;
      cx.beginPath(); cx.moveTo(20, gy); cx.lineTo(620, gy); cx.stroke();
      let maxX = 60; s.trail.forEach(p => maxX = Math.max(maxX, p[0]));
      const sc = Math.min(0.5, 560/maxX);
      cx.strokeStyle = '#00d4ff'; cx.lineWidth = 2; cx.beginPath();
      s.trail.forEach((p,i) => { const X = cxx + p[0]*sc, Y = gy - p[1]*sc;
        i ? cx.lineTo(X,Y) : cx.moveTo(X,Y); });
      cx.stroke();
      if(!s.done){
        const X = cxx + s.x*sc, Y = gy - s.y*sc;
        cx.fillStyle = '#ff6600'; cx.beginPath(); cx.arc(X, Y, 5, 0, 7); cx.fill();
      }
      cx.fillStyle = '#0088aa'; cx.font = '10px Orbitron'; cx.textAlign='left';
      cx.fillText(s.x.toFixed(0) + ' m', cxx + s.x*sc, gy + 14);
    },
    ghostable: false
  },
  population: {
    init(v){ return {p: v.p0, day: 0}; },
    step(s,v,dt){ s.p += v.r * s.p * (1 - s.p/v.k) * dt; s.day += dt; },
    head(s,v){ return `pop ${s.p.toFixed(0)} / ${v.k}\nday ${s.day.toFixed(0)}`; },
    series(s){ return s.p / v.k; },
    draw(s,v,t){
      grid();
      const gy = 400, sc = 340/v.k;
      cx.strokeStyle = '#00a8cc'; cx.beginPath(); cx.moveTo(30, gy); cx.lineTo(610, gy); cx.stroke();
      cx.strokeStyle = 'rgba(0,255,170,.3)'; cx.setLineDash([3,5]);
      cx.beginPath(); cx.moveTo(30, gy - v.k*sc); cx.lineTo(610, gy - v.k*sc); cx.stroke();
      cx.setLineDash([]);
      const barW = 46, X = 80 + ((s.day*8) % 420);
      const h = Math.min(v.k*sc, s.p*sc);
      const gr = cx.createLinearGradient(0, gy-h, 0, gy);
      gr.addColorStop(0, '#00ffaa'); gr.addColorStop(1, '#004455');
      cx.fillStyle = gr; cx.fillRect(X, gy - h, barW, h);
      cx.fillStyle = '#00e8ff'; cx.font='13px Orbitron'; cx.textAlign='left';
      cx.fillText(s.p.toFixed(0), X, gy - h - 8);
    },
    ghostable: false
  },
  predprey: {
    init(v){ return {y: v.prey0, x: v.pred0, hist: [], t: 0}; },
    step(s,v,dt){
      const a=v.alpha, g=v.gamma, b=0.05, d=0.03;
      const ny = s.y + (a*s.y - b*s.y*s.x)*dt;
      const nx = s.x + (b*s.y*s.x - g*s.x)*dt;
      s.y = Math.max(0.01, ny); s.x = Math.max(0.01, nx); s.t += dt;
      s.hist.push([s.y, s.x]); if(s.hist.length > 900) s.hist.shift();
    },
    head(s,v){ return `prey ${s.y.toFixed(0)} · predators ${s.x.toFixed(0)}`; },
    series(s){ return s.y / Math.max(1, v.prey0*3); },
    draw(s,v,t){
      grid();
      const gy = 400, maxP = Math.max(v.prey0*3, 10);
      const Y = val => gy - (val/maxP)*340;
      cx.strokeStyle = '#00ffaa'; cx.lineWidth = 1.6; cx.beginPath();
      s.hist.forEach((p,i)=>{ const X = 30 + i*(580/900);
        i ? cx.lineTo(X, Y(p[0])) : cx.moveTo(X, Y(p[0])); }); cx.stroke();
      cx.strokeStyle = '#ff2a4a'; cx.beginPath();
      s.hist.forEach((p,i)=>{ const X = 30 + i*(580/900);
        i ? cx.lineTo(X, Y(p[1])) : cx.moveTo(X, Y(p[1])); }); cx.stroke();
      cx.font='10px Orbitron'; cx.textAlign='left';
      cx.fillStyle = '#00ffaa'; cx.fillText('PREY', 30, 20);
      cx.fillStyle = '#ff2a4a'; cx.fillText('PREDATOR', 80, 20);
    },
    ghostable: false
  },
  pendulum: {
    init(v){
      const th1 = v.theta1*Math.PI/180, th2 = th1*0.9;
      const s = {t1:th1, t2:th2, w1:0, w2:0, g1:th1+1e-6, gw1:0, gw2:0, trail:[], div:null, t:0};
      return s;
    },
    step(s,v,dt){
      const g = 9.81, l1 = v.l1, l2 = v.l2;
      const acc = (t1,t2,w1,w2) => [
        (-g*(2*Math.sin(t1)) - Math.sin(t1-t2)*(2*w2*w2*l2 + g*Math.cos(t2))) /
          (l1*(2 - Math.cos(2*t1-2*t2))),
        (2*Math.sin(t1-t2)*(w1*w1*l1*(2 - Math.cos(2*t1-2*t2)) + g*(2*Math.sin(t1)) +
          w2*w2*l2*Math.cos(t1-t2))) / (l2*(2 - Math.cos(2*t1-2*t2)))];
      let [a1,a2] = acc(s.t1,s.t2,s.w1,s.w2);
      s.w1 += a1*dt; s.w2 += a2*dt; s.t1 += s.w1*dt; s.t2 += s.w2*dt;
      let [ga1] = acc(s.g1,s.t2,s.gw1,s.gw2);
      s.gw1 += ga1*dt; s.g1 += s.gw1*dt;
      s.t += dt;
      if(s.div === null && Math.abs(s.g1 - s.t1) > 0.3) s.div = s.t;
      s.trail.push([s.t1,s.t2]); if(s.trail.length > 240) s.trail.shift();
    },
    head(s,v){ return s.div !== null
      ? `CHAOS: diverged at ${s.div.toFixed(1)} s`
      : `t = ${s.t.toFixed(1)} s · tracking ghost`; },
    series(s){ return (Math.sin(s.t1)+1)/2; },
    draw(s,v,t){
      grid();
      const cxx = 320, cyy = 120, L = 95;
      const px = (t1,l) => [cxx + Math.sin(t1)*l*L, cyy + Math.cos(t1)*l*L];
      cx.strokeStyle = 'rgba(0,212,255,.25)'; cx.lineWidth = 1; cx.beginPath();
      s.trail.forEach((p,i)=>{                       // trace of the second bob
        const [x1,y1] = px(p[0], v.l1);
        const X = x1 + Math.sin(p[1])*v.l2*L, Y = y1 + Math.cos(p[1])*v.l2*L;
        i ? cx.lineTo(X, Y) : cx.moveTo(X, Y); });
      cx.stroke();
      const drawArm = (t1,t2,l1,l2,col) => {
        const [x1,y1] = px(t1,l1);
        const [x2,y2] = [x1 + Math.sin(t2)*l2*L, y1 + Math.cos(t2)*l2*L];
        cx.strokeStyle = col; cx.lineWidth = 2.4;
        cx.beginPath(); cx.moveTo(cxx,cyy); cx.lineTo(x1,y1); cx.lineTo(x2,y2); cx.stroke();
        cx.fillStyle = col;
        cx.beginPath(); cx.arc(x1,y1,5,0,7); cx.fill();
        cx.beginPath(); cx.arc(x2,y2,7,0,7); cx.fill();
      };
      drawArm(s.g1, s.t2, v.l1, v.l2, 'rgba(255,42,74,.35)');
      drawArm(s.t1, s.t2, v.l1, v.l2, '#00d4ff');
    },
    ghostable: false
  },
  rocket: {
    init(v){ return {y:0, vy:0, m: v.dry_t*1000 + v.fuel_t*1000,
                     fuel: v.fuel_t*1000, t:0, apogee:0, trail:[], done:false}; },
    step(s,v,dt){
      const g = 9.81, T = v.thrust*1000;
      if(s.fuel > 0){ s.vy += (T/s.m - g)*dt; s.fuel = Math.max(0, s.fuel - v.burn*dt);
                      s.m = v.dry_t*1000 + s.fuel; }
      else { s.vy -= g*dt; }
      s.y += s.vy*dt; s.t += dt;
      s.apogee = Math.max(s.apogee, s.y);
      s.trail.push(s.y); if(s.trail.length > 700) s.trail.shift();
      if(s.y < 0 && s.t > 1) s.done = true;
    },
    head(s,v){ return `alt ${(s.y/1000).toFixed(2)} km · ${(s.vy).toFixed(0)} m/s\napogee ${(s.apogee/1000).toFixed(1)} km`; },
    series(s){ return s.y/50000; },
    draw(s,v,t){
      grid();
      const gy = 400, sc = 0.9;
      cx.strokeStyle = '#00a8cc'; cx.beginPath(); cx.moveTo(30,gy); cx.lineTo(610,gy); cx.stroke();
      const X = 90, W = 60;
      const h = Math.max(2, Math.min(360, s.y*sc/100));
      const gr = cx.createLinearGradient(0, gy-h, 0, gy);
      gr.addColorStop(0, '#ff6600'); gr.addColorStop(1, '#552200');
      cx.fillStyle = gr; cx.fillRect(X, gy-h, W, h);
      cx.fillStyle = '#00d4ff'; cx.font='12px Orbitron'; cx.textAlign='left';
      cx.fillText((s.y/1000).toFixed(2)+' km', X+W+12, gy-h+4);
      if(s.fuel > 0 && !s.done){
        cx.fillStyle = '#ffaa33';
        cx.beginPath(); cx.moveTo(X+W/2-9, gy); cx.lineTo(X+W/2+9, gy);
        cx.lineTo(X+W/2, gy + 18 + Math.random()*10); cx.fill();
      }
      cx.strokeStyle = 'rgba(0,212,255,.5)'; cx.lineWidth = 1.2; cx.beginPath();
      s.trail.forEach((yy,i)=>{ const Y = gy - Math.min(360, yy*sc/100);
        const XX = 180 + i*(400/700); i ? cx.lineTo(XX,Y) : cx.moveTo(XX,Y); });
      cx.stroke();
    },
    ghostable: false
  },
  montecarlo: {
    // 10k–200k trials: the batch scales so the histogram fills in ~8 s of
    // animation regardless of n (60k/s batch budget ≈ real-time fill).
    init(v){ return {bars: new Array(40).fill(0), done: 0, n: Math.round(v.trials), sum:0, over:0, maxBar:1}; },
    step(s,v,dt){
      const total = s.n;
      const perSec = Math.max(2000, total / 8);
      const batch = Math.max(10, Math.round(perSec * dt));
      const lo = Math.min(v.best, v.likely, v.worst),
            hi = Math.max(v.best, v.likely, v.worst),
            ex = Math.min(hi, Math.max(lo, v.likely));
      const span = hi - lo || 1;
      for(let k=0; k<batch && s.done < total; k++){
        const u = Math.random(), c = (ex-lo)/span;
        const x = u < c ? lo + Math.sqrt(u*span*(ex-lo))
                        : hi - Math.sqrt((1-u)*span*(hi-ex));
        const idx = Math.min(39, Math.floor((x-lo)/span*40));
        s.bars[idx]++; s.sum += x;
        if(x > v.thresh) s.over++;
        s.maxBar = Math.max(s.maxBar, s.bars[idx]);
        s.done++;
      }
    },
    head(s,v){
      const mean = s.sum/Math.max(1,s.done);
      return `trials ${s.done.toLocaleString()}/${s.n.toLocaleString()}\nmean ${mean.toFixed(0)} · over ${v.thresh}: ${(s.over/Math.max(1,s.done)*100).toFixed(1)}%`; },
    series(s){ return s.done/Math.max(1,s.n); },
    draw(s,v,t){
      grid();
      const bw = 580/40, gy = 400;
      const lo = Math.min(v.best, v.likely, v.worst), hi = Math.max(v.best, v.likely, v.worst);
      for(let i=0;i<40;i++){
        const h = (s.bars[i]/s.maxBar)*330;
        const gr = cx.createLinearGradient(0, gy-h, 0, gy);
        const xlo = lo + i*(hi-lo)/40;
        gr.addColorStop(0, xlo > v.thresh ? '#ff6600' : '#00d4ff');
        gr.addColorStop(1, '#003344');
        cx.fillStyle = gr;
        cx.fillRect(30 + i*bw, gy-h, bw-2, h);
      }
      const tx = 30 + ((v.thresh-lo)/((hi-lo)||1))*580;
      cx.strokeStyle = '#ff2a4a'; cx.setLineDash([5,4]); cx.beginPath();
      cx.moveTo(tx, 40); cx.lineTo(tx, gy); cx.stroke(); cx.setLineDash([]);
      cx.fillStyle = '#ff2a4a'; cx.font='10px Orbitron'; cx.textAlign='left';
      cx.fillText('THRESHOLD ' + v.thresh, tx+6, 54);
    },
    ghostable: false
  }
};

function grid(){
  /* THE readability fix: clear the frame first. Without this every draw
     stacked on the previous one — antialiased text accumulated into the
     garbled smear the first screenshots showed. The canvas itself is
     transparent; the page gradient shows through. */
  cx.clearRect(0, 0, cv.width, cv.height);
  cx.fillStyle = 'rgba(0,68,85,.16)';
  for(let x=0; x<640; x+=40) cx.fillRect(x,0,1,440);
  for(let y=0; y<440; y+=40) cx.fillRect(0,y,640,1);
}

/* Dark-backed label pill — canvas text is only readable when it has a
   surface under it; used by every model that prints over graphics. */
function legendPill(x, y, col, name, val){
  cx.textAlign = 'left';
  cx.font = '11px Orbitron, monospace';
  const w = cx.measureText(name + '  ' + val).width + 46;
  cx.fillStyle = 'rgba(0,8,10,.88)';
  cx.strokeStyle = col; cx.lineWidth = 1;
  cx.beginPath(); cx.roundRect(x, y - 11, w, 24, 4);
  cx.fill(); cx.stroke();
  cx.fillStyle = col;
  cx.beginPath(); cx.arc(x + 12, y + 1, 4, 0, 7); cx.fill();
  cx.fillStyle = '#c8f6ff';
  cx.fillText(name + '  ' + val, x + 22, y + 5);
}

/* ── sliders ── */
function buildSliders(){
  const box = $('sliders'); box.innerHTML = '';
  Object.entries(PARAMS).forEach(([key, [label, min, max, def, unit]]) => {
    const lab = document.createElement('label');
    lab.innerHTML = label + ' <span class="val" id="v_'+key+'">' + vals[key] + unit + '</span>';
    const inp = document.createElement('input');
    inp.type = 'range'; inp.min = min; inp.max = max; inp.step = (max-min)/200;
    inp.value = vals[key];
    inp.oninput = () => { vals[key] = parseFloat(inp.value);
      $('v_'+key).textContent = vals[key].toFixed(max <= 10 ? 2 : 0) + unit;
      hardReset(); };
    box.appendChild(lab); box.appendChild(inp);
  });
}
function hardReset(){ const M = MODELS[SCEN]; state = M.init(vals); ghost = M.ghostable ? M.init(vals) : null; trace = []; t = 0; }

buildSliders();
hardReset();
$('head').textContent = MODELS[SCEN].head(state, vals);

$('run').onclick = () => { running = !running;
  $('run').textContent = running ? '❚❚ PAUSE' : '▶ RUN'; };
$('reset').onclick = () => { hardReset(); };

/* ── loop: fixed-dt substeps, render ~40 fps cap, sleep when hidden ── */
let last = performance.now(), acc = 0, renderAcc = 0;
const DT = 1/120;
function loop(now){
  requestAnimationFrame(loop);
  let el = (now - last)/1000; last = now;
  if(document.hidden || !running) return;
  el = Math.min(el, 0.1);
  acc += el; renderAcc += el;
  const M = MODELS[SCEN];
  while(acc >= DT){
    M.step(state, vals, DT);
    acc -= DT; t += DT;
  }
  if(renderAcc >= 0.025){
    renderAcc = 0;
    trace.push(M.series(state)); if(trace.length > 960) trace.shift();
    M.draw(state, vals, t);
    $('head').textContent = M.head(state, vals);
    drawGraph();
  }
}
function drawGraph(){
  gx.clearRect(0, 0, gv.width, gv.height);
  gx.strokeStyle = 'rgba(0,168,204,.25)';
  for(let y=0; y<gv.height; y+=22){ gx.beginPath(); gx.moveTo(0,y); gx.lineTo(gv.width,y); gx.stroke(); }
  if(trace.length < 2) return;
  const mx = Math.max(1e-6, ...trace);
  gx.strokeStyle = '#00d4ff'; gx.lineWidth = 1.6; gx.beginPath();
  trace.forEach((v,i)=>{ const X = i*(gv.width/960), Y = gv.height - 6 - (v/mx)*(gv.height-16);
    i ? gx.lineTo(X,Y) : gx.moveTo(X,Y); });
  gx.stroke();
  gx.fillStyle = '#0088aa'; gx.font = '9px Orbitron'; gx.textAlign = 'right';
  gx.fillText('now', gv.width - 4, gv.height - 6);
}
requestAnimationFrame(loop);
</script>
</body>
</html>
"""
