"""
JARVIS Plugin: Holographic 3D CAD & Blueprint Designer (Universal Any-Object Generator)
Synthesizes 3D CAD models, exports 3D-printable STL/OBJ files, and generates
interactive 3D WebGL holographic HUD projections and vector blueprint imagery
for ANY object, concept, character, vehicle, or structure on command.

ENHANCED: Can now reference internet images, web search, and vision AI to recreate
ANYTHING from the internet as a holographic 3D projection.
"""
from __future__ import annotations

import json
import math
import os
import re
import struct
import sys
import webbrowser
from pathlib import Path
from typing import Optional

def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent

BASE_DIR = get_base_dir()
CAD_DIR = BASE_DIR / "state" / "cad_models"
HOLO_DIR = BASE_DIR / "state" / "holograms"

CAD_DIR.mkdir(parents=True, exist_ok=True)
HOLO_DIR.mkdir(parents=True, exist_ok=True)

PLUGIN = {
    "name": "hologram_cad",
    "description": (
        "Generates photorealistic volumetric 3D holographic projections with advanced physics, "
        "particle systems, additive blending, and atmospheric depth effects. Can create holograms of "
        "ANYTHING from the internet by analyzing images, web content, or visual references. Provide "
        "a URL, image description, or search term and JARVIS will synthesize a 3D holographic "
        "projection. Examples: 'a hologram of https://example.com/image.jpg', 'create a hologram "
        "of the latest iPhone from the internet', 'holographic projection of a Tesla Cybertruck', "
        "'3D hologram of my favorite movie character', 'holographic model of the Eiffel Tower', "
        "'volumetric projection of a DNA helix', 'holographic blueprint of a quantum computer'. "
        "Supports interactive 3D WebGL holograms, SVG blueprints, and 3D printable STL/OBJ files."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "prompt": {
                "type": "STRING",
                "description": "What holographic image or 3D CAD model to generate. Can be a description, URL, image reference, or internet search query for ANY object/creature/vehicle from the web.",
            },
            "format": {
                "type": "STRING",
                "description": "Output format: 'hologram' (interactive 3D viewer & blueprint), 'stl' (3D mesh), 'image' (vector blueprint image), or 'all' (default).",
            },
            "color": {
                "type": "STRING",
                "description": "Optional holographic color theme: 'cyan' (classic Stark), 'crimson' (Mark L), 'neon' (cyberpunk), 'gold' (titanium), 'emerald' (matrix).",
            },
            "style": {
                "type": "STRING",
                "description": "Optional starting render style: 'hologram' (classic volumetric wireframe, default), 'solid' (solid glowing surfaces), or 'blueprint' (technical schematic lines). The viewer's CUSTOMISE panel can change this live anyway.",
            },
            "url": {
                "type": "STRING",
                "description": "Optional URL of an image to convert to holographic 3D projection (if not included in prompt).",
            },
            "hazards": {
                "type": "ARRAY",
                "items": {"type": "OBJECT", "properties": {
                    "name": {"type": "STRING", "description": "Hazard name, e.g. 'Palladium poisoning'"},
                    "risk": {"type": "STRING", "description": "low | moderate | critical"},
                    "effect": {"type": "STRING", "description": "What it does to the user"},
                    "symptoms": {"type": "ARRAY", "items": {"type": "STRING"}, "description": "Warning signs to watch for"},
                    "mitigation": {"type": "STRING", "description": "How to avoid or treat it"}}},
                "description": "Optional hazard/side-effect analysis rendered as a HUD panel - pass the dangers of the projected object (real or fictional).",
            },
            "tutorial": {
                "type": "OBJECT",
                "properties": {
                    "title": {"type": "STRING"},
                    "steps": {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
                        "name": {"type": "STRING", "description": "Step heading, e.g. '1 · FACE SHELL'"},
                        "detail": {"type": "STRING", "description": "Exactly how to do this step"},
                        "mats": {"type": "ARRAY", "items": {"type": "STRING"}}}}},
                    "solutions": {"type": "ARRAY", "items": {"type": "STRING"},
                                  "description": "Workarounds, e.g. what to do without a 3D printer"}},
                "description": "Optional custom build tutorial. Omit to use the built-in knowledge base (spider-man mask, helmet, arc reactor, general).",
            },
        },
        "required": ["prompt"],
    },
    "behavior": "NON_BLOCKING",
    "scheduling": "WHEN_IDLE",
}


def _esc_html(s) -> str:
    """Minimal HTML escaping for hazard text injected into the viewer."""
    import html as _html
    return _html.escape(str(s or ""), quote=True)


def _slugify(text: str) -> str:
    s = re.sub(r"[^\w\s-]", "", text).strip().lower()
    return re.sub(r"[-\s]+", "_", s)[:36] or "hologram_model"


def _extract_url_from_prompt(prompt: str) -> Optional[str]:
    """Extract URL from prompt if provided."""
    url_pattern = r'https?://[^\s<>"\'\(\)]+\.[^\s<>"\'\(\)]+'
    urls = re.findall(url_pattern, prompt)
    return urls[0] if urls else None


def _download_image_from_url(url: str) -> Optional[bytes]:
    """Download image from URL for analysis."""
    try:
        import requests
        response = requests.get(url, timeout=15)
        if response.status_code == 200:
            return response.content
    except Exception as e:
        print(f"[HoloCAD] Failed to download image: {e}")
    return None


def _analyze_image_for_hologram(image_data: bytes) -> str:
    """Analyze image using vision AI to extract object description for hologram generation."""
    try:
        from core import gemini
        from google.genai import types as gtypes
        
        prompt = """Analyze this image and provide a detailed description for 3D holographic projection synthesis.
        Describe:
        1. The main object/subject
        2. Key geometric shapes and proportions
        3. Important details and features
        4. Material properties (metallic, organic, transparent, etc.)
        5. Structure and complexity level
        
        Provide a detailed description that can be used to generate a 3D holographic CAD model."""
        
        part_img = gtypes.Part.from_bytes(data=image_data, mime_type="image/jpeg")
        contents = [part_img, prompt]
        
        description = gemini.text(contents, tier=gemini.SMART, timeout_ms=18000)
        return description or "Detailed object from image"
    except Exception as e:
        print(f"[HoloCAD] Image analysis fallback: {e}")
        return "Object from provided image"


def _search_internet_for_reference(prompt: str) -> str:
    """Search the internet for reference information about the requested object."""
    try:
        from actions.web_search import web_search
        search_results = web_search(prompt, num_results=3)
        
        if search_results and len(search_results) > 0:
            # Extract key information from search results
            context = f"Based on internet search for '{prompt}': "
            for result in search_results[:2]:
                context += f"{result.get('title', '')}: {result.get('snippet', '')} "
            return context
    except Exception as e:
        print(f"[HoloCAD] Web search fallback: {e}")
    
    return prompt


# ── AI Three.js 3D Geometry Synthesizer ──────────────────────────────────────

def _extract_js_code(raw: str) -> str:
    """Pull clean JavaScript out of whatever the model returned.

    Gemini regularly wraps the code in markdown fences, or writes a complete
    `function populateCustomHologram(...) { ... }` declaration even when asked
    for the body alone. The old code checked for `group.add` / `THREE.` on the
    raw response and treated any mismatch as total failure — which silently
    degraded every hologram to the icosahedron fallback (the 'geometric
    sphere' bug). Handle both shapes here.
    """
    if not raw:
        return ""
    s = raw.strip()

    # 1. Strip markdown fences (```js ... ``` / ```javascript ... ```).
    if s.startswith("```"):
        s = re.sub(r"^```[a-zA-Z0-9_-]*\s*\n?", "", s)
        s = re.sub(r"\n?```\s*$", "", s)
    # Prose around the code: pull the largest fenced block out of the middle.
    if "```" in s:
        blocks = re.findall(r"```[a-zA-Z0-9_-]*[ \t]*\n(.*?)\n?```", s, re.S)
        if blocks:
            s = max(blocks, key=len).strip()

    # 2. If a wrapper function was declared anyway, unwrap it to its body —
    #    the template below re-wraps it, so exactly one code path exists.
    m = re.search(
        r"function\s+populateCustomHologram\s*\([^)]*\)\s*\{", s)
    if m:
        start = m.end()                       # just past the opening brace
        depth = 1
        in_str = None
        esc = False
        end = len(s)
        for i in range(start, len(s)):
            ch = s[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == in_str:
                    in_str = None
                continue
            if ch in ("'", '"', "`"):
                in_str = ch
            elif ch == "/" and i + 1 < len(s) and s[i + 1] == "/":
                j = s.find("\n", i)
                if j == -1:
                    break
            elif ch == "/" and i + 1 < len(s) and s[i + 1] == "*":
                j = s.find("*/", i)
                if j == -1:
                    break
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    end = i
                    break
        body = s[start:end]
        if body.strip():
            s = body

    return s.strip()


def _procedural_builder_for(prompt: str) -> str | None:
    """The curated procedural builder for this prompt, or None if the object
    class is unknown. Known classes always build procedurally — the hand-tuned
    builders read correctly from every angle, disassemble into named parts and
    never depend on what the model felt like drawing that day."""
    p = prompt.lower()
    # Specific objects first — "iron man arc reactor" must be a reactor, and
    # "spider-man mask" a mask, before the weak tokens ("iron man", "man",
    # "suit") can claim them for the humanoid builder.
    if any(k in p for k in ("lightsaber", "light saber", "saber", "sword",
                            "blade", "katana", "dagger", "knife", "gladius",
                            "spear", "lance", "staff", "wand", "scythe",
                            "axe", "hammer", "mastor", "master sword")):
        return "buildSword"
    if any(k in p for k in ("reactor", "power core", "engine core",
                            "fusion core", "portal", "energy disc",
                            "stargate", "emblem")):
        return "buildReactor"
    if any(k in p for k in ("head", "face", "skull", "mask", "helmet",
                            "cranium")):
        return "buildHead"
    if any(k in p for k in ("dna", "helix", "molecule", "atom", "virus",
                            "cell", "protein")):
        return "buildHelix"
    if any(k in p for k in ("ship", "jet", "plane", "aircraft", "craft",
                            "drone", "rocket", "shuttle", "fighter")):
        return "buildAircraft"
    if any(k in p for k in ("car", "vehicle", "truck", "tank", "bike",
                            "cybertruck", "motorcycle")):
        return "buildVehicle"
    if any(k in p for k in ("building", "tower", "house", "city", "castle",
                            "skyscraper", "eiffel", "structure")):
        return "buildStructure"
    if any(k in p for k in ("heart", "organ", "brain", "anatomy",
                            "lung", "kidney", "liver")):
        return None          # organs read better as the scan-core than a body
    if any(k in p for k in ("human", "person", "man", "woman", "soldier",
                            "robot", "android", "astronaut", "character",
                            "suit", "iron man", "superhero")):
        return "buildHumanoid"
    return None


def _synthesize_threejs_geometry(prompt: str, color_hex: str) -> str:
    """Three.js procedural code for ANY prompt. Known object classes go
    straight to the curated procedural builders; the model is only asked for
    the long tail, and even then its output must clear a quality gate — a
    lazy 'one sphere' answer falls back to the procedural builder."""
    if _procedural_builder_for(prompt):
        return _procedural_fallback_js(prompt)
    try:
        from core import gemini
        sys_query = f"""You are an elite 3D computational designer specializing in procedural Three.js wireframe holograms with realistic volumetric effects.
USER WANTS A 3D HOLOGRAPHIC PROJECTION OF: '{prompt}'.

Write the exact JavaScript code to construct this 3D model inside the scene.
Rules:
1. Provide ONLY the raw BODY of this function (no function declaration, no markdown fences, no commentary): function populateCustomHologram(group, colorHex, lineMaterial, wireMaterial) {{ ... }}
2. Construct detailed 3D parts using Three.js geometry primitives (CylinderGeometry, ConeGeometry, BoxGeometry, TorusGeometry, SphereGeometry, RingGeometry, TubeGeometry, LatheGeometry, IcosahedronGeometry, ExtrudeGeometry, etc.) or custom BufferGeometry/curves.
3. Position and rotate meshes/lines to form an authentic, recognizable representation of '{prompt}' with realistic proportions and details. The result must READ as the object when rendered as a wireframe — build the whole silhouette, not one primitive.
4. Add holographic glow effects using multiple mesh layers with different opacities and additive blending.
5. Add all created meshes, wireframes, or LineSegments to `group`.
6. Use `lineMaterial` for lines and `wireMaterial` for wireframes.
7. Create volumetric depth by adding semi-transparent inner structures and outer wireframes.
8. Do NOT define or use any variables named group, colorHex, lineMaterial or wireMaterial other than the parameters. Do NOT call animate/requestAnimationFrame — the viewer animates the result. Store anything to animate in group.userData.hologramParts.
9. Output ONLY raw JavaScript statements."""

        code = gemini.text(sys_query, tier=gemini.SMART, timeout_ms=22000)
        clean = _extract_js_code(code or "")
        # Quality gate: a usable hologram builds a whole silhouette from
        # several primitives. One or two primitives renders as "just a circle"
        # — exactly the failure this gate exists to catch.
        if ("THREE." in clean and clean.count("new THREE.") >= 3
                and len(clean) > 400):
            return clean
    except Exception as e:
        print(f"[HoloCAD] AI 3D synthesis fallback: {e}")

    # Model unavailable or unusable output — build a real procedural object
    # instead of a bare icosahedron, so the 3D view always shows something
    # that reads as the requested subject.
    return _procedural_fallback_js(prompt)


# ── Procedural fallback geometry — real objects, never a bare sphere ────────

def _procedural_fallback_js(prompt: str) -> str:
    """Deterministic Three.js builder for the hologram, used when the model is
    unreachable. Categorises the prompt and assembles a recognisable object
    from primitives — plus a shared projection pad, holo rings and drift
    animation, so the result always looks like a Stark projection."""
    builder = _procedural_builder_for(prompt) or "buildUnknown"
    subject = prompt[:60].replace("`", "").replace("'", "")
    return _HOLO_FALLBACK_TEMPLATE.format(builder=builder, subject=subject)


_HOLO_FALLBACK_TEMPLATE = r"""
    // ═══ Procedural holographic projection: {subject} ═══
    // Built locally (model unavailable) — still a full Stark-style projection.

    function _mat(op) {{
        return new THREE.MeshBasicMaterial({{ color: colorHex, transparent: true,
            opacity: op, side: THREE.DoubleSide, blending: THREE.AdditiveBlending,
            depthWrite: false }});
    }}
    function _add(geo, x, y, z, rx, ry, rz, op, scale) {{
        const m = new THREE.Mesh(geo, _mat(op === undefined ? 0.30 : op));
        m.position.set(x || 0, y || 0, z || 0);
        m.rotation.set(rx || 0, ry || 0, rz || 0);
        if (scale) m.scale.set(scale[0], scale[1], scale[2]);
        group.add(m);
        const w = new THREE.Mesh(geo, _mat(0.9));
        w.material.wireframe = true;
        w.position.copy(m.position); w.rotation.copy(m.rotation);
        if (scale) w.scale.set(scale[0], scale[1], scale[2]);
        group.add(w);
        return m;
    }}
    // _named: like _add, but into a labelled Group — the part the viewer
    // disassembles, drags and names on screen.
    function _named(name, build) {{
        const g = new THREE.Group();
        g.userData.partName = name;
        group.add(g);
        const save = group.add.bind(group);
        group.add = (o) => {{ g.add(o); return o; }};
        try {{ build(); }} finally {{ group.add = save; }}
        return g;
    }}

    // ── the object itself ──────────────────────────────────────────────────
    const B = {builder};
    const animated = B();

    function buildReactor() {{
        // The classic arc-reactor: back plate, coil ring, thick outer ring,
        // inner rings and the glowing triangular core — facing the viewer.
        const parts = [];
        const CY = 10;                                  // floats above the pad
        parts.push(_named('BACK PLATE', () => {{
            _add(new THREE.CylinderGeometry(10.5, 10.5, 0.9, 32),
                 0, CY, -0.8, Math.PI / 2, 0, 0, 0.22);
        }}));
        parts.push(_named('OUTER RING', () => {{
            _add(new THREE.TorusGeometry(9.6, 1.05, 10, 48),
                 0, CY, 0, 0, 0, 0, 0.42);
        }}));
        parts.push(_named('COIL RING · 10 SEGMENTS', () => {{
            for (let i = 0; i < 10; i++) {{
                const a = i * Math.PI / 5;
                _add(new THREE.BoxGeometry(2.1, 2.5, 1.7),
                     Math.cos(a) * 7.1, CY + Math.sin(a) * 7.1, 0.4,
                     0, 0, a + Math.PI / 2, 0.38);
            }}
        }}));
        parts.push(_named('INNER RING', () => {{
            _add(new THREE.TorusGeometry(4.6, 0.4, 8, 40), 0, CY, 0.6, 0, 0, 0, 0.5);
        }}));
        parts.push(_named('TRIANGLE CORE', () => {{
            // THE TRIANGLE CORE — prism with 3 sides, pointing up
            const tri = _add(new THREE.CylinderGeometry(2.9, 2.9, 0.55, 3, 1),
                             0, CY, 1.0, Math.PI / 2, 0, 0, 0.55);
            tri.rotation.z = 0;                         // vertex up
            _add(new THREE.TorusGeometry(1.7, 0.22, 8, 32), 0, CY, 1.4, 0, 0, 0, 0.6);
        }}));
        return parts;
    }}

    function buildSword() {{
        // A lightsaber-class prop: vertical hilt with emitter shroud, glowing
        // plasma blade and inner core, control housing, pommel. Reads from
        // every angle, and disassembles into named components.
        const parts = [];
        const GY = 10;                                  // float above the pad
        parts.push(_named('PLASMA BLADE', () => {{
            // the blade itself — a tall tube, brighter than the hilt
            _add(new THREE.CylinderGeometry(0.95, 1.15, 34, 14),
                 0, GY + 17.5, 0, 0, 0, 0, 0.34);
        }}));
        parts.push(_named('BLADE CORE', () => {{
            // inner brighter core — sells the volumetric plasma look
            _add(new THREE.CylinderGeometry(0.45, 0.55, 32, 10),
                 0, GY + 16.5, 0, 0, 0, 0, 0.85);
            // tip cap
            _add(new THREE.SphereGeometry(0.95, 12, 10), 0, GY + 34.5, 0, 0, 0, 0, 0.55);
        }}));
        parts.push(_named('EMITTER SHROUD', () => {{
            // flared mouth the blade ignites from
            _add(new THREE.CylinderGeometry(1.7, 1.25, 2.6, 14),
                 0, GY - 1.6, 0, 0, 0, 0, 0.42);
            _add(new THREE.TorusGeometry(1.68, 0.28, 8, 24),
                 0, GY - 0.3, 0, 1.5708, 0, 0, 0.55);
        }}));
        parts.push(_named('CONTROL HOUSING + SWITCH', () => {{
            // the grip — ribbed cylinders + activation box + side buttons
            _add(new THREE.CylinderGeometry(1.2, 1.2, 9.5, 14),
                 0, GY - 7.6, 0, 0, 0, 0, 0.40);
            for (let i = 0; i < 6; i++) {{
                _add(new THREE.TorusGeometry(1.21, 0.13, 6, 20),
                     0, GY - 4.4 - i * 1.5, 0, 1.5708, 0, 0, 0.5);
            }}
            _add(new THREE.BoxGeometry(1.5, 2.4, 0.9), 0, GY - 5.2, 1.25, 0.25, 0, 0, 0.5);
            _add(new THREE.CylinderGeometry(0.28, 0.28, 0.5, 8),
                 1.25, GY - 8.6, 0, 0, 0, 1.5708, 0.7);
        }}));
        parts.push(_named('POMMEL', () => {{
            _add(new THREE.CylinderGeometry(1.15, 1.45, 2.2, 14),
                 0, GY - 13.5, 0, 0, 0, 0, 0.42);
            _add(new THREE.SphereGeometry(0.6, 10, 8), 0, GY - 14.9, 0, 0, 0, 0, 0.6);
        }}));
        return parts;
    }}

    function buildHumanoid() {{
        const parts = [];
        parts.push(_named('HEAD', () => {{
            _add(new THREE.SphereGeometry(4.2, 16, 12), 0, 26.5, 0, 0, 0, 0, 0.35);
            _add(new THREE.CylinderGeometry(1.6, 2.4, 4, 10), 0, 21.5, 0);   // neck
        }}));
        parts.push(_named('TORSO · ARC REACTOR', () => {{
            _add(new THREE.CylinderGeometry(5.5, 4, 13, 12), 0, 12.5, 0);
            _add(new THREE.TorusGeometry(3.2, 0.5, 8, 32), 0, 14.5, 3.4, 0, 0, 0);
        }}));
        parts.push(_named('SHOULDER ASSEMBLY', () => {{
            _add(new THREE.BoxGeometry(15.5, 4.5, 6.5), 0, 17.5, 0);
        }}));
        parts.push(_named('LEFT ARM', () => {{
            _add(new THREE.CylinderGeometry(1.9, 1.5, 12.5, 8), -9.6, 10, 0, 0, 0, 0.12);
            _add(new THREE.SphereGeometry(1.9, 10, 8), -10.4, 2.6, 0);
        }}));
        parts.push(_named('RIGHT ARM', () => {{
            _add(new THREE.CylinderGeometry(1.9, 1.5, 12.5, 8), 9.6, 10, 0, 0, 0, -0.12);
            _add(new THREE.SphereGeometry(1.9, 10, 8), 10.4, 2.6, 0);
        }}));
        parts.push(_named('LEFT LEG', () => {{
            _add(new THREE.CylinderGeometry(2.9, 2.2, 11, 8), -3.4, -6.5, 0, 0, 0, 0.05);
            _add(new THREE.BoxGeometry(3.6, 2.2, 7.5), -3.4, -13.2, 0);
        }}));
        parts.push(_named('RIGHT LEG', () => {{
            _add(new THREE.CylinderGeometry(2.9, 2.2, 11, 8), 3.4, -6.5, 0, 0, 0, -0.05);
            _add(new THREE.BoxGeometry(3.6, 2.2, 7.5), 3.4, -13.2, 0);
        }}));
        return parts;
    }}

    function buildAircraft() {{
        const parts = [];
        parts.push(_named('FUSELAGE + NOSE', () => {{
            _add(new THREE.CylinderGeometry(3.2, 1.4, 26, 14), 0, 0, 0, 1.5708, 0, 0);
            _add(new THREE.SphereGeometry(3.2, 14, 10), 0, 0.5, 13, 0, 0, 0, 0.08, [1, 0.72, 1]);
            _add(new THREE.TorusGeometry(2.2, 0.45, 8, 24), 0, 0, 14.2);   // intake glow
        }}));
        parts.push(_named('MAIN WINGS', () => {{
            _add(new THREE.BoxGeometry(30, 0.7, 7), 0, -0.6, -1.5);
        }}));
        parts.push(_named('TAIL SECTION', () => {{
            _add(new THREE.BoxGeometry(11, 0.6, 4), 0, 1.8, -12.4);
            _add(new THREE.BoxGeometry(0.7, 6.2, 5.4), 0, 3.4, -12.2);
        }}));
        parts.push(_named('ENGINES · LEFT + RIGHT', () => {{
            _add(new THREE.CylinderGeometry(1.5, 1.1, 8, 10), -6.5, -1.8, -1.5, 1.5708, 0, 0);
            _add(new THREE.CylinderGeometry(1.5, 1.1, 8, 10), 6.5, -1.8, -1.5, 1.5708, 0, 0);
        }}));
        return parts;
    }}

    function buildVehicle() {{
        const parts = [];
        parts.push(_named('CHASSIS', () => {{
            _add(new THREE.BoxGeometry(9, 4, 19), 0, 0, 0);
        }}));
        parts.push(_named('CABIN', () => {{
            _add(new THREE.BoxGeometry(7.6, 3.6, 9), 0, 3.6, -1.2);
            _add(new THREE.BoxGeometry(6.4, 1.6, 0.4), 0, 3.4, 3.4);       // windshield
        }}));
        parts.push(_named('HOOD', () => {{
            _add(new THREE.BoxGeometry(8.2, 1.2, 4.6), 0, 1.4, 9.6);
        }}));
        parts.push(_named('WHEELS · 4×', () => {{
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), -4.9, -2.6, 6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), 4.9, -2.6, 6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), -4.9, -2.6, -6.2, 0, 0, 1.5708);
            _add(new THREE.CylinderGeometry(2.6, 2.6, 1.6, 14), 4.9, -2.6, -6.2, 0, 0, 1.5708);
        }}));
        return parts;
    }}

    function buildStructure() {{
        const parts = [];
        parts.push(_named('TIERED BLOCKS · 6×', () => {{
            for (let i = 0; i < 6; i++) {{
                const w = 16 - i * 2.1;
                _add(new THREE.BoxGeometry(w, 5.5, w), 0, 2.75 + i * 5.5, 0);
            }}
        }}));
        parts.push(_named('SPIRE', () => {{
            _add(new THREE.CylinderGeometry(0.8, 1.6, 8, 8), 0, 38, 0);
        }}));
        parts.push(_named('STRUCTURAL BRACES · 4×', () => {{
            for (let i = 0; i < 4; i++) {{
                const a = i * 1.5708 + 0.7854;
                _add(new THREE.BoxGeometry(1.2, 36, 1.2), Math.cos(a) * 8.5, 18, Math.sin(a) * 8.5);
            }}
        }}));
        return parts;
    }}

    function buildHelix() {{
        const parts = [];
        parts.push(_named('HELIX STRANDS · 2×', () => {{
        const pts1 = [], pts2 = [];
        for (let i = 0; i <= 60; i++) {{
            const t = i / 60, a = t * Math.PI * 4.5;
            pts1.push(new THREE.Vector3(Math.cos(a) * 7, (t - 0.5) * 40, Math.sin(a) * 7));
            pts2.push(new THREE.Vector3(Math.cos(a + Math.PI) * 7, (t - 0.5) * 40, Math.sin(a + Math.PI) * 7));
        }}
        const lm = new THREE.LineBasicMaterial({{ color: colorHex, transparent: true, opacity: 0.9 }});
        group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts1), lm));
        group.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts2), lm));
        }}));
        parts.push(_named('BASE PAIRS · 13×', () => {{
            for (let i = 0; i <= 12; i++) {{
                const t = i / 12, a = t * Math.PI * 4.5;
                const v1 = new THREE.Vector3(Math.cos(a) * 7, (t - 0.5) * 40, Math.sin(a) * 7);
                const v2 = new THREE.Vector3(Math.cos(a + Math.PI) * 7, (t - 0.5) * 40, Math.sin(a + Math.PI) * 7);
                const mid = v1.clone().add(v2).multiplyScalar(0.5);
                const g = new THREE.CylinderGeometry(0.28, 0.28, 14, 6);
                const m = new THREE.Mesh(g, _mat(0.35));
                m.position.copy(mid);
                m.rotation.z = 1.5708; m.rotation.y = -a;
                group.add(m);
            }}
        }}));
        return parts;
    }}

    function buildHead() {{
        const parts = [];
        parts.push(_named('CRANIUM', () => {{
            const skull = new THREE.SphereGeometry(9, 20, 14);
            skull.scale(0.86, 1.06, 0.94);
            _add(skull, 0, 2, 0, 0, 0, 0, 0.3);
        }}));
        parts.push(_named('JAW', () => {{
            const jaw = new THREE.SphereGeometry(5.4, 16, 10);
            jaw.scale(0.82, 0.7, 0.9);
            _add(jaw, 0, -6.4, 2.2, 0, 0, 0, 0.3);
        }}));
        parts.push(_named('OPTICAL SENSORS · 2×', () => {{
            _add(new THREE.SphereGeometry(1.05, 8, 8), -3.2, 3.4, 7.6, 0, 0, 0, 0.95);
            _add(new THREE.SphereGeometry(1.05, 8, 8), 3.2, 3.4, 7.6, 0, 0, 0, 0.95);
        }}));
        parts.push(_named('NASAL ARRAY', () => {{
            _add(new THREE.ConeGeometry(1.1, 3.6, 8), 0, -1.2, 9.2, 1.5708, 0, 0, 0.5);
        }}));
        parts.push(_named('HELMET RIM', () => {{
            const rm = new THREE.Mesh(new THREE.RingGeometry(8.9, 9.15, 48), _mat(0.6));
            rm.position.set(0, 2, 0);
            group.add(rm);
        }}));
        return parts;
    }}

    function buildUnknown() {{
        // The honest default for an object class nothing matches: not a face,
        // not a bare sphere — a faceted scan-core with gyro rings and survey
        // nodes, reading as "object acquired, resolving topology".
        const parts = [];
        parts.push(_named('CORE LATTICE', () => {{
            _add(new THREE.IcosahedronGeometry(8, 1), 0, 14, 0, 0, 0, 0, 0.22);
            _add(new THREE.IcosahedronGeometry(4.6, 0), 0, 14, 0, 0.4, 0.3, 0, 0.75);
            _add(new THREE.SphereGeometry(1.7, 10, 8), 0, 14, 0, 0, 0, 0, 0.95);
        }}));
        parts.push(_named('GYRO RINGS · 2×', () => {{
            _add(new THREE.TorusGeometry(13.5, 0.5, 8, 48), 0, 14, 0, 1.2, 0, 0.3, 0.5);
            _add(new THREE.TorusGeometry(16.5, 0.4, 8, 48), 0, 14, 0, 0.4, 0, 1.1, 0.4);
        }}));
        parts.push(_named('SURVEY NODES · 6×', () => {{
            for (let i = 0; i < 6; i++) {{
                const a = (i / 6) * Math.PI * 2;
                _add(new THREE.OctahedronGeometry(1.15, 0),
                     Math.cos(a) * 19, 14 + Math.sin(a * 2) * 4, Math.sin(a) * 19,
                     0, a, 0, 0.85);
                _add(new THREE.RingGeometry(0.1, 2.6, 20),
                     Math.cos(a) * 21, 14 + Math.sin(a * 2) * 4, Math.sin(a) * 21,
                     1.5708, 0, -a, 0.4);
            }}
        }}));
        parts.push(_named('SCAN PLATFORM', () => {{
            _add(new THREE.CylinderGeometry(7, 8.5, 1.6, 24), 0, -2.5, 0, 0, 0, 0, 0.3);
            _add(new THREE.TorusGeometry(7.6, 0.35, 8, 36), 0, -1.6, 0, 1.5708, 0, 0, 0.6);
        }}));
        return parts;
    }}

    // ── projection pad, holo rings, drift — the Stark dressing ───────────
    // One labelled rig group so disassembly never tears the stage down with it.
    let pad, padRing, dust, scan;
    const holoRings = [];
    const rig = _named('PROJECTION RIG', () => {{
        pad = new THREE.Mesh(new THREE.CylinderGeometry(26, 26, 0.5, 48), _mat(0.10));
        pad.position.y = -21;
        group.add(pad);
        padRing = new THREE.Mesh(new THREE.TorusGeometry(26.5, 0.35, 8, 96), _mat(0.55));
        padRing.rotation.x = 1.5708;
        padRing.position.y = -20.6;
        group.add(padRing);
        for (let i = 0; i < 3; i++) {{
            const rg = new THREE.Mesh(new THREE.TorusGeometry(15 + i * 5.5, 0.28, 8, 72), _mat(0.4 - i * 0.1));
            rg.rotation.x = 1.5708 + (i - 1) * 0.22;
            group.add(rg);
            holoRings.push(rg);
        }}
        // floating dust particles inside the projection volume
        const pN = 140, pGeo = new THREE.BufferGeometry();
        const pPos = new Float32Array(pN * 3);
        for (let i = 0; i < pN; i++) {{
            pPos[i * 3]     = (Math.random() - 0.5) * 46;
            pPos[i * 3 + 1] = (Math.random() - 0.5) * 44;
            pPos[i * 3 + 2] = (Math.random() - 0.5) * 46;
        }}
        pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
        const pMat = new THREE.PointsMaterial({{ color: colorHex, size: 0.9,
            transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false }});
        dust = new THREE.Points(pGeo, pMat);
        group.add(dust);
        // scan plane sweeping up the object
        scan = new THREE.Mesh(new THREE.PlaneGeometry(56, 0.9), _mat(0.45));
        scan.rotation.x = -1.5708;
        group.add(scan);
    }});
    rig.userData.isRig = true;   // never flies apart — it is the stage itself

    // everything the viewer's animation loop already knows how to drive
    group.userData.hologramParts = {{
        core: animated[0] || null,
        wireCore2: null,
        ring1: holoRings[0], ring2: holoRings[1], ring3: holoRings[2], ring4: null,
        scan: scan,
        particles: dust,
        particleVelocities: null,
        basePositions: null,
        padRing: padRing
    }};
"""


# ── AI Vector Holographic Blueprint Generator ────────────────────────────────

def _synthesize_hologram_svg(prompt: str, color_hex: str) -> str:
    """Ask Gemini to generate an intricate technical holographic blueprint SVG for ANY prompt."""
    try:
        from core import gemini
        sys_query = f"""You are a Stark Industries holographic blueprint designer.
The user requested a holographic technical schematic image of: '{prompt}'.
Generate a complete, intricate vector graphic in SVG format (width="800" height="600" viewBox="0 0 800 600").
Aesthetic guidelines:
- Background: dark sci-fi void #00060a
- Primary glowing neon color: {color_hex}
- Secondary accent: #ffaa00 or #00ffcc
- Include detailed wireframe silhouettes, schematic cross-sections, dimension lines, measurement ticks, target reticles, technical callouts, and Stark Industries HUD telemetry labels.
- Output ONLY the raw <svg>...</svg> element. No markdown fences, no chat prose."""

        svg = gemini.text(sys_query, tier=gemini.SMART, timeout_ms=22000)
        if svg and "<svg" in svg and "</svg>" in svg:
            start = svg.find("<svg")
            end = svg.rfind("</svg>") + len("</svg>")
            return svg[start:end].strip()
    except Exception as e:
        print(f"[HoloCAD] AI SVG synthesis fallback: {e}")

    # Clean default technical holographic blueprint SVG
    return f"""<svg width="800" height="600" viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg">
  <rect width="800" height="600" fill="#00060a"/>
  <circle cx="400" cy="300" r="180" stroke="{color_hex}" stroke-width="1.5" fill="none" opacity="0.4" stroke-dasharray="8 4"/>
  <circle cx="400" cy="300" r="130" stroke="{color_hex}" stroke-width="2" fill="none" opacity="0.7"/>
  <circle cx="400" cy="300" r="70" stroke="#ffaa00" stroke-width="1.5" fill="none" opacity="0.6"/>
  <line x1="200" y1="300" x2="600" y2="300" stroke="{color_hex}" stroke-width="1" opacity="0.3"/>
  <line x1="400" y1="100" x2="400" y2="500" stroke="{color_hex}" stroke-width="1" opacity="0.3"/>
  <rect x="320" y="240" width="160" height="120" stroke="{color_hex}" stroke-width="2" fill="none" opacity="0.8"/>
  <text x="40" y="50" fill="{color_hex}" font-family="monospace" font-size="16" letter-spacing="2">MARK LIV // HOLOGRAPHIC PROJECTION: {prompt.upper()}</text>
  <text x="40" y="75" fill="#ffaa00" font-family="monospace" font-size="11">STATUS: VOLUMETRIC SYNTHESIS NOMINAL</text>
  <text x="640" y="560" fill="{color_hex}" font-family="monospace" font-size="10">STARK INDUSTRIES</text>
</svg>"""


# ── 3D STL Binary Mesh Generator ─────────────────────────────────────────────

def _write_stl_triangles(file_path: Path, triangles: list[tuple]):
    """Write binary STL file from list of ((x1,y1,z1), (x2,y2,z2), (x3,y3,z3))."""
    with open(file_path, "wb") as f:
        header = b"STARK INDUSTRIES CAD - MARK LIV UNIVERSAL HOLOGRAPHIC MESH"
        header = header.ljust(80, b"\x00")[:80]
        f.write(header)
        f.write(struct.pack("<I", len(triangles)))

        for (v1, v2, v3) in triangles:
            ax, ay, az = v2[0] - v1[0], v2[1] - v1[1], v2[2] - v1[2]
            bx, by, bz = v3[0] - v1[0], v3[1] - v1[1], v3[2] - v1[2]
            nx, ny, nz = ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx
            mag = math.sqrt(nx * nx + ny * ny + nz * nz)
            if mag > 1e-6:
                nx, ny, nz = nx / mag, ny / mag, nz / mag
            else:
                nx, ny, nz = 0.0, 0.0, 1.0

            data = struct.pack(
                "<12fH",
                nx, ny, nz,
                v1[0], v1[1], v1[2],
                v2[0], v2[1], v2[2],
                v3[0], v3[1], v3[2],
                0
            )
            f.write(data)


def _generate_parametric_stl_triangles(prompt: str) -> list:
    """Generate rich 3D triangles matching the prompt category."""
    p = prompt.lower()
    tris = []

    def _cylinder(r, h, segs=36, z_off=0):
        t = []
        z_t, z_b = z_off + h/2.0, z_off - h/2.0
        for i in range(segs):
            th1, th2 = 2 * math.pi * i / segs, 2 * math.pi * (i + 1) / segs
            x1, y1 = r * math.cos(th1), r * math.sin(th1)
            x2, y2 = r * math.cos(th2), r * math.sin(th2)
            t.append(((x1, y1, z_b), (x2, y2, z_b), (x1, y1, z_t)))
            t.append(((x2, y2, z_b), (x2, y2, z_t), (x1, y1, z_t)))
            t.append(((0, 0, z_t), (x1, y1, z_t), (x2, y2, z_t)))
            t.append(((0, 0, z_b), (x2, y2, z_b), (x1, y1, z_b)))
        return t

    def _box(w, d, h, ox=0, oy=0, oz=0):
        hw, hd, hh = w/2.0, d/2.0, h/2.0
        c = [
            (ox-hw, oy-hd, oz-hh), (ox+hw, oy-hd, oz-hh), (ox+hw, oy+hd, oz-hh), (ox-hw, oy+hd, oz-hh),
            (ox-hw, oy-hd, oz+hh), (ox+hw, oy-hd, oz+hh), (ox+hw, oy+hd, oz+hh), (ox-hw, oy+hd, oz+hh),
        ]
        quads = [(0,1,2,3), (4,7,6,5), (0,4,5,1), (2,6,7,3), (0,3,7,4), (1,5,6,2)]
        t = []
        for q in quads:
            t.append((c[q[0]], c[q[1]], c[q[2]]))
            t.append((c[q[0]], c[q[2]], c[q[3]]))
        return t

    if any(k in p for k in ("ship", "jet", "plane", "craft", "drone")):
        # Aerospace fuselage + delta wings
        tris.extend(_cylinder(12.0, 80.0, segs=28))
        tris.extend(_box(90.0, 30.0, 4.0, oz=0))
        tris.extend(_box(6.0, 18.0, 22.0, oz=10, oy=-25))
    elif any(k in p for k in ("skull", "head", "face", "helmet")):
        # Cranium + jaw
        tris.extend(_cylinder(28.0, 36.0, segs=32, z_off=10))
        tris.extend(_box(26.0, 24.0, 18.0, oz=-14, oy=6))
    elif any(k in p for k in ("car", "vehicle", "truck")):
        # Chassis + cabin
        tris.extend(_box(40.0, 90.0, 16.0))
        tris.extend(_box(32.0, 45.0, 14.0, oz=12, oy=-5))
    else:
        # Complex multi-tier technical mechanism
        tris.extend(_cylinder(32.0, 20.0, segs=36, z_off=-10))
        tris.extend(_cylinder(18.0, 40.0, segs=32, z_off=10))
        for i in range(6):
            ang = i * math.pi / 3
            cx, cy = 35 * math.cos(ang), 35 * math.sin(ang)
            tris.extend(_box(10.0, 10.0, 24.0, ox=cx, oy=cy, oz=-5))

    return tris


# ── Interactive 3D WebGL Holographic HUD Master Viewer ───────────────────────

# ── Hazard lore ───────────────────────────────────────────────────────────────
# Side effects the projected object would pose to its user. JARVIS can pass a
# full hazards list; when he doesn't, well-known Stark canon is auto-applied.
_HAZARDS = {
    "reactor": [
        {"name": "Palladium poisoning", "risk": "critical",
         "effect": "The reactor's palladium core slowly leaches into the bloodstream. Palladium is toxic in cumulative doses.",
         "symptoms": ["Dark pulsing veins spreading from the chest", "Skin pallor", "Fatigue and dizziness", "Hand tremor"],
         "mitigation": "Replace the palladium core with a vibranium synthesis, or switch to the new-element arc created from the Stark Expo model."},
        {"name": "Magnetospheric interference", "risk": "low",
         "effect": "The reactor's electromagnetic field interferes with nearby pacemakers, watches and unshielded electronics.",
         "symptoms": ["Devices glitching near the chest", "Magnetic attraction of small metal objects"],
         "mitigation": "Keep magnetic-sensitive devices 30 cm clear; shielded housing resolves it."},
    ],
    "suit": [
        {"name": "Altitude hypoxia", "risk": "moderate",
         "effect": "Thin air above 18,000 m — the suit must recycle oxygen or blackouts follow.",
         "symptoms": ["Tunnel vision", "Euphoria then confusion", "Blue lips"],
         "mitigation": "Never disable the oxygen recycler; monitor cabin pressure on ascent."},
        {"name": "G-force blackout", "risk": "moderate",
         "effect": "Hard maneuvers push blood from the head; unassisted turns above 9 g cause grey-out.",
         "symptoms": ["Grey-out, then blackout", "Neck strain"],
         "mitigation": "Keep the flight computer's g-limit enabled unless trained."},
    ],
    "portal": [
        {"name": "Radiation bleed", "risk": "critical",
         "effect": "Unstable apertures leak particle radiation; exposure compounds per second of contact.",
         "symptoms": ["Metallic taste", "Static on skin", "Nausea within minutes"],
         "mitigation": "Stand clear of the event horizon; never touch an unstable ring."},
    ],
    "default": [
        {"name": "Holographic emitter exposure", "risk": "low",
         "effect": "Prolonged close-range exposure to the projection field causes mild eye strain and disorientation.",
         "symptoms": ["Dry eyes", "Mild headache after long sessions"],
         "mitigation": "Take a break every 30 minutes; dim the glow in the CUSTOMISE panel."},
    ],
}


# ── Build tutorials ─────────────────────────────────────────────────────────
# Real construction guides for the projected object — sub-assemblies, materials
# and fallback solutions ("no 3D printer? use cardboard and resin"). JARVIS can
# pass a custom tutorial; otherwise the knowledge base below applies.
_TUTORIALS = {
    "spiderman": {
        "title": "SPIDER-MAN MASK — THE REAL BUILD",
        "traps": [
            "Printing the shell too thin — under 2.5 mm walls it flexes and the lenses pop off. 3 mm walls, 4 perimeters.",
            "Skipping the filler skim: paint shows every layer line on a curved shell. Two thin skims of spot putty beat one thick one.",
            "Heat-forming lenses too hot — above 150 C the acrylic bubbles. 120-130 C, watch it sag, then press.",
            "Gluing the fabric to the OUTSIDE rim: pull it through and glue INSIDE, or the rim shows a hard edge on your face.",
        ],
        "steps": [
            {"name": "1 · FACE SHELL — THE CHASSIS (10-12 h, ~$6)",
             "detail": "Find a model: search 'cosplay face shell STL' on Etsy, MyMiniFactory or Cults3D (worbla-makers and CP cosplay versions are the known-good ones). Print in TWO halves plus a separate chin/jaw piece so it fits any printer. Settings: PETG or PLA+, 0.2 mm layers, 4-6 perimeters (this IS the strength), 15% gyroid infill, supports only under the nose bridge and brow. Total print ~10 h. Assemble the halves with CA glue + activated concave ridge, or 2-part epoxy for a cleaner bond.",
             "time": "10-12 h print + 1 h assembly", "cost": "~$6 filament",
             "mats": ["PETG or PLA+ (~250 g)", "CA glue / 2-part epoxy", "Masking tape"]},
            {"name": "2 · SANDING + SKIM — WHERE PROP BECOMES PRODUCT (2-3 h hands-on)",
             "detail": "Sand 120 grit to knock the layer lines flat, 220 to smooth, 400 before primer. Then spot putty (Bondo spot putty or Polisher's glazing putty): two THIN skims with a rubber squeegee, 30 min cure between, sand each back at 220→400. Finish with filler primer (2-3 light coats, 10 min flash), wet-sand 600. Now the shell reads as moulded, not printed. Wipe with isopropyl before every stage.",
             "time": "2-3 h across an evening", "cost": "~$12",
             "mats": ["Sandpaper 120/220/400/600", "Bondo spot putty", "Filler primer rattle can", "Nitrile gloves"]},
            {"name": "3 · REINFORCE FROM THE INSIDE (1 h + overnight cure)",
             "detail": "Lay 1-2 layers of 2 oz chopped-strand fibreglass mat inside the shell with laminating epoxy (not polyester — lower odour, longer work time). Press the wet mat into the brow and cheek curves with a brush, pop air bubbles with a pin. Overnight cure. This is the step that stops the shell cracking when it takes a knock. If resin is a no-go: 3 layers of paper-mache + PVA, fully dry in 24 h, adds ~80% of the stiffness.",
             "time": "1 h work + overnight cure", "cost": "~$18",
             "mats": ["2 oz fibreglass mat", "Laminating epoxy + hardener", "Disposable brush", " gloves + respirator (fumes)"]},
            {"name": "4 · LENSES — THE PART EVERYONE STARES AT (3-4 h, ~$15)",
             "detail": "Cut two-way mirror acrylic 2-3 mm oversize (lens templates ship with most shell STLs, or trace the shell's eye holes). Heat-form: oven at 120 C on a clean baking tray, 3-5 min until it slumps — press gently over a hemispherical former (bowl wrapped in felt) and hold 30 s. Trim with a rotary tool + cutoff wheel, sand edges 400. Bezel: 2 mm EVA foam, contact cement, wrap the rim. Magnetic mount: four 8x2 mm N35 magnets per lens — SUPERGLUE magnets to the shell FIRST, then epoxy matching pairs to the lens backs (polarity test every pair, one flipped magnet ruins the set).",
             "time": "3-4 h", "cost": "~$15",
             "mats": ["2-way mirror acrylic A4 sheet", "EVA foam 2 mm", "8x2 mm N35 magnets x8", "Contact cement + CA", "Oven + rotary tool"]},
            {"name": "5 · FABRIC SHELL — PATTERN TO PULL (4-6 h, ~$20)",
             "detail": "Get a lycra/spandex faceshell pattern (search 'spiderman mask pattern faceshell' — The Foam Cave and several Etsy shops sell print-and-sew versions sized to shells). Print at 100% scale, cut 2-way stretch WITH the stretch wrapping horizontally. Sew seams with a zigzag or serger, 2.5 mm — or fabric glue (E6000) + hem tape if you don't sew. Dye: Rit Dye More in the sink at 90 C for the classic red, or buy pre-coloured 4-way stretch and print the webbing via inkjet-on-fabric sheets for accuracy.",
             "time": "4-6 h", "cost": "~$20",
             "mats": ["2-way stretch spandex 0.5 m", "Pattern printout", "Sewing machine or E6000 + hem tape", "Rit Dye More (optional)"]},
            {"name": "6 · ASSEMBLY — THE PULL-THROUGH (45 min)",
             "detail": "Turn the fabric inside-out, roll the shell into it face-down, then roll it back through the neck opening — the fabric seats itself over the shell with no wrinkles. Glue the fabric edge to the shell's INNER rim with contact cement, 10 cm at a time. Stretch the neck hole over a jar overnight to relax it. Seat the lenses on their magnets — they should click and hold through a headshake.",
             "time": "45 min + overnight relax", "cost": "$0 — all glue work",
             "mats": ["Contact cement", "A jar"]},
            {"name": "7 · FINISHING TOUCHES (optional)",
             "detail": "Magnetic jaw piece for eating/talking on the go (same 8x2 magnets, inset into the chin). Hidden rear zip stitched into the fabric seam. For moving lenses: a servo + Arduino Nano in the brow is a weekend project — most cosplayers stop at static.",
             "time": "2-4 h", "cost": "~$10 if adding the jaw",
             "mats": ["8x2 mm magnets", "Optional: servo + Nano + battery"]},
        ],
        "solutions": [
            "NO 3D PRINTER: laminate 6-7 layers of cardboard + PVA over a balloon/mannequin head (rock-hard when dry), or build it from EVA-foam pepakura pieces — then seal with PVA and finish the same.",
            "NO SEWING MACHINE: fabric glue + hem tape hold a spandex shell fine at this scale.",
            "NO 2-WAY MIRROR: clear acrylic + one-way window-tint film looks 90% the same for a tenth the price.",
            "NO RESIN for reinforcing: 3 layers of paper-mache + white glue is the poor-cousin version and still stiff.",
            "NO OVEN for lens forming: hot-water pour-over forming works at 90 C with 4-5 min hold — slower but shapes fine.",
        ],
    },
    "helmet": {
        "title": "HELMET — FULL BUILD",
        "steps": [
            {"name": "1 · SHELL",
             "detail": "3D print the helmet in 4 interlocking pieces (top, back, two sides) or pepakura EVA foam. Sand + filler + primer until smooth.",
             "mats": ["Filament or EVA foam", "Filler", "Primer"]},
            {"name": "2 · INNER HARNESS",
             "detail": "Glue a foam head-liner and chin strap inside so the shell sits level and doesn't rattle.",
             "mats": ["EVA foam 5 mm", "Elastic strap", "Contact adhesive"]},
            {"name": "3 · FACEPLATE & ELECTRONICS",
             "detail": "Hinge the faceplate on small hinges or magnets; LEDs behind acrylic eyes on a coin-cell or Arduino driver.",
             "mats": ["Hinges/magnets", "LED strip", "Acrylic"]},
            {"name": "4 · FINISH",
             "detail": "Prime → base coat → detail pass → clear. Matte clear for armour, gloss for glass parts.",
             "mats": ["Spray paints", "Clear coat"]},
        ],
        "solutions": [
            "NO 3D PRINTER: EVA-foam pepakura is the standard alternative — heat-shape with a heat gun, glue with contact cement.",
            "NO PEPAKURA SOFTWARE: cardboard prototype first, then transfer to foam.",
        ],
    },
    "reactor": {
        "title": "ARC REACTOR PROP — FULL BUILD",
        "steps": [
            {"name": "1 · CORE RING",
             "detail": "3D print or cut the housing rings from 3 mm acrylic/foam-board; the copper-coil effect is ten small segments around the ring.",
             "mats": ["Acrylic or foam board", "Copper paint/wire"]},
            {"name": "2 · THE GLOW",
             "detail": "An LED ring + frosted acrylic diffuser reads as plasma; EL-wire behind a triangular mask gives the triangle core.",
             "mats": ["LED ring", "Frosted acrylic", "EL-wire", "Coin cell/Arduino"]},
            {"name": "3 · FINISH",
             "detail": "Weather the rim with dark wash, mount in a display stand or chest rig.",
             "mats": ["Dark wash", "Stand"]},
        ],
        "solutions": [
            "NO 3D PRINTER: foam-board + compass-cut rings are indistinguishable after paint.",
            "NO LED RING: fairy LEDs behind frosted plastic work, just dimmer.",
        ],
    },
}

_DEFAULT_TUTORIAL = {
    "title": "BUILD PROTOCOL — FROM PROJECTION TO PHYSICAL",
    "steps": [
        {"name": "1 · SOURCE A MODEL",
         "detail": "Search the object + 'STL free' — most popular objects exist as printable models. This viewer's own blueprint SVG and STL export give you the geometry.",
         "mats": ["Internet", "This viewer's STL export"]},
        {"name": "2 · PICK YOUR PROCESS",
         "detail": "3D print (detail) · EVA foam (big + cheap) · cardboard + PVA lamination (strongest free option) · papier-mache + resin (rigid shells).",
         "mats": []},
        {"name": "3 · BUILD, SAND, SEAL",
         "detail": "Assemble, sand 120 → 400, seal with PVA or primer — the sealer decides whether paint looks cheap or real.",
         "mats": ["Sandpaper", "PVA/primer"]},
        {"name": "4 · FINISH",
         "detail": "Base coat, detail pass, clear coat. Matte reads as scale, gloss reads as prop.",
         "mats": ["Paints", "Clear coat"]},
    ],
    "solutions": [
        "NO 3D PRINTER: cardboard + PVA lamination (6-7 layers, rock hard) or EVA-foam pepakura — both finish identically after priming.",
        "NO BUDGET: paper-mache + white glue for rigidity; cereal-box card for small parts.",
    ],
}


def _pick_tutorial_key(prompt: str) -> str:
    p = prompt.lower()
    for key in ("spiderman", "spider-man", "spider man"):
        if key in p:
            return "spiderman"
    if any(k in p for k in ("helmet", "suit", "iron man", "mask")) and "spider" not in p:
        return "helmet"
    if "reactor" in p:
        return "reactor"
    return "default"


# ── universal build-plan generator — ANY object, not just the curated few ────
# The curated KB covers three famous builds; everything else used to fall back
# to a generic four-step outline. This composes a REAL plan for whatever the
# user names: how to get its shape, which materials fit its size class, the
# process order, and the working alternatives when tools are missing.

# size class drives material quantities and technique choices
_BIG_WORDS = ("life size", "full size", "cosplay", "wearable", "human", "giant",
              "statue", "suit", "armor", "armour", "helmet", "mask", "car",
              "vehicle", "jet", "ship", "door", "sword", "shield", "bow",
              "rifle", "gun", "staff", "hammer")

# object class → how makers actually capture its shape
_SHAPE_RECIPES = (
    (("mask", "face", "helmet", "head", "visor"),
     "an existing STL ('<object> STL free' on Printables/MyMiniFactory/Thingiverse) or a plaster strip cast of your own face as the buck"),
    (("armor", "armour", "chest", "gauntlet", "boot", "shin", "shoulder pauldron"),
     "pepakura/EVA-foam templates (search '<object> foam template') — scale to your body measurements before cutting"),
    (("gun", "rifle", "blaster", "sword", "blade", "axe", "hammer", "staff", "wand", "saber"),
     "a side-profile printout glued to 6 mm MDF or layered foam-board, cut and stacked to thickness (props-first method)"),
    (("drone", "jet", "plane", "rocket", "ship", "car", "vehicle", "engine"),
     "a 3-view blueprint printed at target scale as the reference, then either an STL or built-up foam/card over a light frame"),
    (("ring", "medallion", "amulet", "badge", "coin", "emblem", "sigil"),
     "the viewer's own blueprint SVG printed at size as the template — cast in resin, carve from layered card, or print flat with a raised rim"),
    (("reactor", "core", "lamp", "lantern", "glowing"),
     "printed or acrylic cut rings, a diffuser disc, and LEDs inside — the light is the prop, so plan the wiring channel first"),
    (("creature", "skull", "dragon", "monster", "skeleton"),
     "a printable model in sections (search '<object> STL'), or sculpt over a crumpled-foil armature with air-dry clay"),
    (("house", "tower", "castle", "building", "city", "bridge"),
     "cardboard + hot-glue over a card skeleton for volume, xps foam sheets for surfaces, scribe panel lines before priming"),
)

# electronics-y objects get a light-wiring step
_LIGHT_WORDS = ("reactor", "core", "glowing", "led", "lamp", "neon", "light",
                "energy", "plasma", "saber", "laser")


def _generate_universal_tutorial(prompt: str) -> dict:
    """Compose a real, object-specific build protocol for ANY prompt."""
    p = (prompt or "").lower()
    obj = prompt.strip().rstrip(".!")
    if len(obj) > 48:
        obj = obj[:45].rstrip() + "…"
    short = obj if len(obj) <= 28 else obj[:25].rstrip() + "…"

    big = any(k in p for k in _BIG_WORDS)
    lights = any(k in p for k in _LIGHT_WORDS)

    shape = "the viewer's own blueprint SVG printed at scale as your master template"
    for keys, rec in _SHAPE_RECIPES:
        if any(k in p for k in keys):
            shape = rec.replace("<object>", short)
            break

    if big:
        body_mat = "6-10 mm EVA foam as the primary body (cheap, light, heat-shapes over curves), backed with contact-cement"
        body_finish = "seal foam with 2-3 coats of PVA/weldbond, then plasti-dip or flexible primer so paint never cracks on flex"
        scale_note = "It is sized to a person or a room, so pattern it on paper first and test-fit as you go — measure twice, cut once."
        est = "1-2 weekends"
    else:
        body_mat = "layered cardboard + PVA (free, rock hard) or a small 3D print if the STL exists — resin-print fine detail if you have the access"
        body_finish = "sand 120 → 400, skim spot-putty over the joins, filler primer, then wet-sand 600 for a moulded surface"
        scale_note = "At this size accuracy comes from the template — tape the printed plan to the material and cut through both."
        est = "an evening to a weekend"

    steps = [
        {"name": "1 · CAPTURE THE SHAPE",
         "detail": f"Get the geometry of the {short} before touching material: {shape}. Draw or print the front + side views at final scale — every measurement comes off these.",
         "mats": ["Reference views", "Printer"]},
        {"name": "2 · BUILD THE BODY",
         "detail": f"{body_mat}. Cut all major pieces from your pattern in one session — batching keeps the edges consistent. {scale_note}",
         "mats": (["EVA foam 6-10 mm", "Contact cement", "Utility knife + cutting mat"] if big
                  else ["Cardboard layers", "PVA glue", "Craft knife"])},
        {"name": "3 · DETAIL PASS",
         "detail": f"Add the {short}'s signature details as separate small pieces glued on — panel lines scribed with a blunt tool, raised trim from thin foam strip. Depth reads far better than paint alone.",
         "mats": ["Thin foam/card strip", "Scribing tool (blunt pencil)"]},
        {"name": "4 · HARDEN + SMOOTH",
         "detail": f"{body_finish}. This stage is 80 % of how real the final prop looks — do not rush it.",
         "mats": (["Heat gun", "Flexible primer"] if big else
                  ["Sandpaper 120/400/600", "Spot putty", "Filler primer"])},
        {"name": "5 · PAINT + ASSEMBLE",
         "detail": f"Prime, base coat, then shade recesses with a dark wash and catch edges with a light dry-brush — the two tricks that make anything look machined. Assemble last so every face stays reachable.",
         "mats": ["Acrylic or spray paints", "Wash + dry-brush", "CA glue"]},
    ]
    if lights:
        steps.append({"name": "6 · LIGHT IT",
                      "detail": "Wire the glow: LED strip or fairy-LEDs on a coin cell / small battery pack, diffused behind frosted plastic or 2 layers of baking paper — bare LEDs read as dots, diffusion reads as plasma. Leave a hidden battery hatch.",
                      "mats": ["LEDs + coin cell/pack", "Frosted acrylic/baking paper", "Thin wire"]})
    else:
        steps.append({"name": "6 · DISPLAY",
                      "detail": f"Finish the {short} for its setting: a stand, wall mount or wear rig. A clear coat (matte = screen-accurate, gloss = fresh-off-the-line) locks the paint against handling.",
                      "mats": ["Clear coat", "Stand/mount"]})

    solutions = [
        "NO 3D PRINTER: cardboard + PVA lamination (6-7 layers, rock hard when dry) or EVA-foam layered and heat-shaped — both finish identically after primer.",
        "NO BUDGET: cereal-box card for detail parts, paper-mache (3 layers + white glue) for rigidity, egg-carton texture for organic surfaces.",
        "NO WORKSHOP TOOLS: a sharp craft knife, steel ruler and cutting mat replace 90 % of power tools; sandpaper wrapped round a block replaces a sander.",
        "NO PAINT BUDGET: one grey primer + one accent colour + a black wash covers most sci-fi and fantasy schemes.",
    ]
    if big:
        solutions.append("NO LARGE SHEETS: join smaller foam offcuts with contact cement overlapped 15 mm — the seam sands flat and disappears.")
    if lights:
        solutions.append("NO ELECTRONICS: EL-wire, a battery fairy-light string, or even a phone-torch behind the diffuser works for static glow.")

    return {
        "title": f"BUILD PROTOCOL — {obj.upper()}",
        "generated": True,
        "steps": steps,
        "solutions": solutions,
        "estimate": est,
    }


def _pick_tutorial(prompt: str, explicit) -> dict:
    if isinstance(explicit, dict) and explicit.get("steps"):
        return explicit
    curated = _TUTORIALS.get(_pick_tutorial_key(prompt))
    return curated or _generate_universal_tutorial(prompt)


def _pick_hazards(prompt: str, explicit) -> list:
    """JARVIS's hazards win; otherwise canon entries by keyword; else default."""
    if explicit:
        return [h for h in explicit if isinstance(h, dict) and h.get("name")]
    p = prompt.lower()
    for key in ("reactor", "suit", "portal"):
        if key in p:
            return _HAZARDS[key]
    return _HAZARDS["default"]


def _generate_interactive_hologram_viewer(slug: str, prompt: str, threejs_logic: str, svg_content: str, color_hex: str, fallback_js: str = "", initial_style: str = "hologram", hazards=None) -> Path:
    """Build a comprehensive, futuristic Stark HUD Hologram Viewer with 3D WebGL and 2D Blueprint tabs."""
    out_file = HOLO_DIR / f"{slug}_hologram.html"

    escaped_svg = svg_content.replace("`", "\\`")

    hazards = _pick_hazards(prompt, hazards)

    # build tutorial — a real, generated plan for THIS object + the curated
    # knowledge base so the in-page assistant can answer "what about a helmet?"
    tut = _pick_tutorial(prompt, None)
    tut_payload = dict(tut)
    tut_payload["kb"] = _TUTORIALS
    tut_payload["prompt"] = prompt
    tut_json = json.dumps(tut_payload, ensure_ascii=False).replace("</", "<\\/")

    _RISK_COL = {"low": "#37ffb5", "moderate": "#ffaa00", "critical": "#ff4455"}
    worst = "low"
    for h in hazards:
        if h.get("risk") == "critical":
            worst = "critical"
        elif h.get("risk") == "moderate" and worst != "critical":
            worst = "moderate"
    _RISK_LBL = {"low": "SAFE OPERATING ENVELOPE", "moderate": "CAUTION ADVISED",
                 "critical": "EXTREME DANGER"}
    hazards_html = ""
    hazards_risk = _RISK_LBL[worst]
    for h in hazards:
        rc = _RISK_COL.get(str(h.get("risk", "low")).lower(), "#37ffb5")
        syms = "".join(f'<span class="haz-sym">{s}</span>'
                       for s in (h.get("symptoms") or []))
        hazards_html += (
            f'<div class="haz-item">'
            f'<div class="haz-name">▸ {_esc_html(h.get("name", "Hazard"))}'
            f'<span class="haz-risk" style="color:{rc};border-color:{rc};">'
            f'{str(h.get("risk", "low")).upper()}</span></div>'
            f'<div class="haz-effect">{_esc_html(h.get("effect", ""))}</div>'
            + (f'<div class="haz-sub">SYMPTOMS: {syms}</div>' if syms else '')
            + (f'<div class="haz-mit">✚ {_esc_html(h.get("mitigation", ""))}</div>'
               if h.get("mitigation") else '')
            + '</div>'
        )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>MARK LIV // HOLOGRAPHIC PROJECTION — {prompt.upper()}</title>
  <style>
    :root {{
      --holo-color: {color_hex};
      --holo-dim: rgba(0, 212, 255, 0.15);
      --holo-glow: 0 0 14px {color_hex};
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      padding: 0;
      overflow: hidden;
      background: radial-gradient(circle at center, #02121d 0%, #00060a 100%);
      font-family: 'Consolas', 'Courier New', monospace;
      color: var(--holo-color);
      user-select: none;
    }}
    #hud-header {{
      position: absolute;
      top: 24px;
      left: 28px;
      z-index: 20;
      pointer-events: none;
      text-shadow: var(--holo-glow);
    }}
    h1 {{
      font-size: 22px;
      margin: 0 0 6px 0;
      letter-spacing: 3.5px;
      font-weight: 700;
    }}
    .subhead {{
      font-size: 11px;
      opacity: 0.85;
      letter-spacing: 1.5px;
    }}
    #toolbar {{
      position: absolute;
      top: 24px;
      right: 28px;
      z-index: 30;
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      justify-content: flex-end;
      max-width: 62vw;
    }}
    /* ── Iron-Man-style customisation panel ─────────────────────────── */
    #cfg-panel {{
      position: absolute;
      top: 72px;
      right: 28px;
      width: 244px;
      z-index: 35;
      background: rgba(0, 10, 18, 0.9);
      border: 1px solid var(--holo-color);
      box-shadow: 0 0 24px rgba(0, 212, 255, 0.2);
      padding: 14px 16px;
      backdrop-filter: blur(6px);
      transform: translateX(130%);
      transition: transform 0.3s ease;
      font-size: 11px;
      max-height: calc(100vh - 130px);
      overflow-y: auto;
    }}
    #cfg-panel.open {{ transform: translateX(0); }}
    .cfg-hdr {{ font-weight: bold; letter-spacing: 2px; margin-bottom: 10px;
               display: flex; justify-content: space-between; align-items: center;
               text-shadow: var(--holo-glow); }}
    #cfg-close {{ cursor: pointer; color: #ff3355; font-size: 15px; }}
    .cfg-lbl {{ color: rgba(255,255,255,0.55); letter-spacing: 1.5px;
               margin: 11px 0 5px; font-size: 9px; }}
    .cfg-lbl span {{ color: var(--holo-color); float: right; }}
    #cfg-styles {{ display: flex; gap: 6px; }}
    #cfg-styles button {{
      flex: 1; background: rgba(0,15,25,0.7); border: 1px solid var(--holo-color);
      color: var(--holo-color); font-family: monospace; font-size: 10px;
      padding: 5px 0; cursor: pointer; letter-spacing: 1px;
    }}
    #cfg-styles button.active {{ background: var(--holo-color); color: #00060a; font-weight: bold; }}
    #cfg-swatches {{ display: flex; gap: 7px; flex-wrap: wrap; }}
    .swatch {{ width: 22px; height: 22px; border-radius: 50%; cursor: pointer;
              border: 2px solid rgba(255,255,255,0.25); }}
    .swatch.sel {{ border-color: #fff; box-shadow: 0 0 8px var(--holo-color); }}
    #cfg-color {{ width: 100%; margin-top: 8px; background: transparent;
                 border: 1px solid var(--holo-color); height: 26px; cursor: pointer; }}
    #cfg-panel input[type=range] {{ width: 100%; accent-color: var(--holo-color);
                                   background: transparent; }}
    .cfg-row {{ display: block; margin: 5px 0; cursor: pointer;
               color: rgba(255,255,255,0.78); letter-spacing: 0.5px; }}
    .cfg-row input {{ accent-color: var(--holo-color); margin-right: 6px; }}
    #cfg-reset {{ width: 100%; margin-top: 12px; }}
    .holo-btn {{
      background: rgba(0, 15, 25, 0.7);
      border: 1px solid var(--holo-color);
      color: var(--holo-color);
      padding: 7px 14px;
      font-size: 11px;
      font-family: monospace;
      cursor: pointer;
      letter-spacing: 1.5px;
      text-shadow: 0 0 6px var(--holo-color);
      box-shadow: 0 0 10px rgba(0, 212, 255, 0.15);
      transition: all 0.2s ease;
      backdrop-filter: blur(4px);
    }}
    .holo-btn:hover {{
      background: var(--holo-color);
      color: #00060a;
      box-shadow: 0 0 18px var(--holo-color);
    }}
    .holo-btn.active {{
      background: var(--holo-color);
      color: #00060a;
      font-weight: bold;
    }}
    #tut-panel {{
      position: absolute;
      top: 72px;
      left: 28px;
      width: 300px;
      z-index: 35;
      background: rgba(0, 10, 18, 0.9);
      border: 1px solid var(--holo-color);
      box-shadow: 0 0 24px rgba(0, 212, 255, 0.2);
      padding: 14px 16px;
      backdrop-filter: blur(6px);
      transform: translateX(-130%);
      transition: transform 0.3s ease;
      max-height: calc(100vh - 120px);
      overflow-y: auto;
    }}
    #tut-panel.open {{ transform: translateX(0); }}
    .tut-step {{ margin: 9px 0; }}
    .tut-step b {{ color: var(--holo-color); font-size: 11px; letter-spacing: 1px; display: block; }}
    .tut-step span {{ color: rgba(255,255,255,0.72); font-size: 11px; line-height: 1.55; }}
    .tut-mat {{ margin-top: 10px; padding-top: 8px; border-top: 1px dashed var(--holo-color);
               color: #ffaa00; font-size: 10px; letter-spacing: 1px; }}
    #haz-panel {{
      position: absolute;
      top: 72px;
      right: 300px;
      width: 300px;
      z-index: 36;
      background: rgba(20, 4, 8, 0.92);
      border: 1px solid #ff4455;
      box-shadow: 0 0 26px rgba(255, 60, 80, 0.25);
      padding: 12px 14px;
      backdrop-filter: blur(6px);
      display: none;
      max-height: calc(100vh - 140px);
      overflow-y: auto;
    }}
    #haz-panel.open {{ display: block; }}
    .haz-hdr {{ color: #ff5566; font-size: 11px; letter-spacing: 2px; margin-bottom: 10px;
               border-bottom: 1px solid rgba(255,68,85,.4); padding-bottom: 6px; }}
    #haz-close {{ float: right; cursor: pointer; }}
    .haz-item {{ margin: 9px 0; }}
    .haz-name {{ font-size: 11px; letter-spacing: 1px; color: #ffb3c0; }}
    .haz-risk {{ float: right; font-size: 9px; letter-spacing: 1px; padding: 1px 7px; border: 1px solid; }}
    .haz-effect {{ color: rgba(255,255,255,.7); font-size: 10.5px; line-height: 1.5; margin-top: 4px; }}
    .haz-sub {{ color: rgba(255,255,255,.55); font-size: 10px; margin-top: 4px; }}
    .haz-sym {{ display: inline-block; font-size: 9px; letter-spacing: .5px; padding: 1px 6px;
               margin: 3px 4px 0 0; border: 1px solid rgba(255,170,0,.5); color: #ffcc66; }}
    .haz-mit {{ color: #7fe8a8; font-size: 10px; line-height: 1.5; margin-top: 5px; }}
    .haz-foot {{ border-top: 1px dashed rgba(255,68,85,.4); margin-top: 10px; padding-top: 7px;
               color: rgba(255,179,192,.6); font-size: 9px; letter-spacing: 1.5px; }}
    .tut-ask {{ margin: 8px 0 12px; padding: 8px; border: 1px dashed var(--holo-color); }}
    .tut-ask input {{ width: 100%; background: rgba(0,15,25,.8); border: 1px solid var(--holo-color);
                    color: #eafcff; font-family: monospace; font-size: 11px; padding: 6px 8px;
                    margin: 6px 0; outline: none; }}
    .tut-ask button {{ width: 100%; }}
    .tut-step {{ margin: 10px 0; border-left: 2px solid var(--holo-color); padding-left: 9px; }}
    .tut-step b {{ color: var(--holo-color); font-size: 11px; letter-spacing: 1px; display: block; }}
    .tut-step span {{ color: rgba(255,255,255,.72); font-size: 11px; line-height: 1.55; }}
    .tut-step .bin {{ float: right; cursor: pointer; opacity: .55; font-size: 12px; padding: 0 3px;
                     filter: grayscale(1); }}
    .tut-step .bin:hover {{ opacity: 1; filter: none; }}
    .tut-step.gone {{ transition: all .3s ease; opacity: 0; margin-left: -14px; }}
    .tut-mats {{ margin-top: 5px; }}
    .tut-mats i {{ display: inline-block; font-style: normal; font-size: 9px; letter-spacing: .5px;
                 padding: 1px 6px; margin: 3px 4px 0 0; border: 1px solid var(--holo-color);
                 color: var(--holo-color); opacity: .85; }}
    .tut-sol {{ margin-top: 12px; padding-top: 8px; border-top: 1px dashed #ffaa00; }}
    .tut-sol h4 {{ color: #ffaa00; font-size: 10px; letter-spacing: 1.5px; margin-bottom: 6px; }}
    .tut-sol p {{ color: rgba(255,231,168,.85); font-size: 10px; line-height: 1.55; margin: 5px 0; }}
    .tut-est {{ color: #ffaa00; font-size: 9px; letter-spacing: 1.5px; margin: 8px 0 0;
              border-top: 1px dashed rgba(255,170,0,.35); padding-top: 6px; }}
    .tut-chips {{ margin-top: 7px; }}
    .tut-chips button {{ display: inline-block; font-family: monospace; font-size: 9px; letter-spacing: .5px;
                        padding: 3px 8px; margin: 2px 4px 2px 0; background: rgba(0,20,30,.7);
                        border: 1px solid var(--holo-color); color: var(--holo-color); cursor: pointer; }}
    .tut-chips button:hover {{ background: rgba(0,212,255,.15); }}
    .jh-chip {{ display: inline-block; font-size: 9px; padding: 2px 8px; margin: 2px 4px 2px 0;
               border: 1px solid var(--holo-color); color: var(--holo-color); cursor: pointer;
               opacity: .8; }}
    .jh-chip:hover {{ opacity: 1; background: rgba(0,212,255,.12); }}
    .jh-m .bin {{ float: right; cursor: pointer; opacity: .45; filter: grayscale(1); padding: 0 3px; }}
    .jh-m .bin:hover {{ opacity: 1; filter: none; }}
    #jh-wrap {{ position: absolute; right: 24px; top: 50%; transform: translateY(-50%);
               z-index: 40; display: flex; align-items: center; gap: 10px; }}
    #jh-avatar {{ writing-mode: vertical-rl; text-orientation: mixed; background: rgba(0,15,25,.85);
                 border: 1px solid var(--holo-color); color: var(--holo-color); padding: 14px 6px;
                 font-size: 10px; letter-spacing: 3px; cursor: pointer; user-select: none;
                 box-shadow: 0 0 14px rgba(0,212,255,.2); }}
    #jh-avatar span {{ font-size: 13px; animation: jhPulse 2.4s ease-in-out infinite; }}
    @keyframes jhPulse {{ 50% {{ text-shadow: 0 0 14px var(--holo-color); }} }}
    #jh-avatar i {{ font-style: normal; margin-top: 8px; }}
    #jh-panel {{ display: none; width: 280px; height: 380px; background: rgba(0,10,18,.94);
                border: 1px solid var(--holo-color); box-shadow: 0 0 24px rgba(0,212,255,.25);
                backdrop-filter: blur(6px); flex-direction: column; }}
    #jh-panel.open {{ display: flex; }}
    .jh-hdr {{ color: var(--holo-color); font-size: 10px; letter-spacing: 2px; padding: 9px 12px;
              border-bottom: 1px solid var(--holo-color); }}
    #jh-close {{ float: right; cursor: pointer; }}
    #jh-msgs {{ flex: 1; overflow-y: auto; padding: 10px 12px; }}
    .jh-m {{ font-size: 11px; line-height: 1.55; margin: 7px 0; padding: 7px 9px; max-width: 92%; }}
    .jh-m.jarvis {{ color: #cff7ff; border-left: 2px solid var(--holo-color);
                  background: rgba(0,212,255,.06); }}
    .jh-m.user {{ color: #ffd9a8; margin-left: auto; border-right: 2px solid #ffaa00;
                 background: rgba(255,170,0,.05); }}
    .jh-inrow {{ display: flex; border-top: 1px solid var(--holo-color); }}
    .jh-inrow input {{ flex: 1; background: rgba(0,15,25,.8); border: none; color: #eafcff;
                     font-family: monospace; font-size: 11px; padding: 8px 10px; outline: none; }}
    .jh-inrow button {{ background: var(--holo-color); border: none; color: #00060a;
                      font-weight: bold; padding: 0 14px; cursor: pointer; }}
    #telemetry-box {{
      position: absolute;
      bottom: 24px;
      right: 28px;
      z-index: 20;
      font-size: 11px;
      text-align: right;
      line-height: 1.7;
      opacity: 0.9;
      text-shadow: var(--holo-glow);
      pointer-events: none;
    }}
    #controls-hint {{
      position: absolute;
      bottom: 24px;
      left: 28px;
      z-index: 20;
      font-size: 11px;
      opacity: 0.7;
      pointer-events: none;
      letter-spacing: 1px;
    }}
    #blueprint-modal {{
      display: none;
      position: absolute;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 6, 10, 0.92);
      z-index: 50;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(8px);
    }}
    #blueprint-container {{
      max-width: 90vw;
      max-height: 85vh;
      border: 1px solid var(--holo-color);
      box-shadow: 0 0 30px rgba(0, 212, 255, 0.25);
      padding: 16px;
      background: #000a12;
      position: relative;
    }}
    #blueprint-container svg {{
      width: 100%;
      height: auto;
      max-height: 75vh;
      display: block;
    }}
    #close-modal {{
      position: absolute;
      top: 10px;
      right: 14px;
      color: #ff3355;
      font-size: 18px;
      font-weight: bold;
      cursor: pointer;
    }}
    .part-lbl {{
      position: fixed; pointer-events: none; display: none;
      transform: translate(-50%, -50%);
      color: var(--holo-color); font-family: monospace; font-size: 10px;
      letter-spacing: 1px; text-shadow: 0 0 6px var(--holo-color);
      white-space: nowrap; z-index: 30;
    }}
    canvas {{ display: block; }}
  </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
</head>
<body>
  <div id="hud-header">
    <h1>STARK HOLOGRAPHIC DISPLAY // MARK LIV</h1>
    <div class="subhead">SUBJECT: {prompt.upper()}</div>
    <div class="subhead" style="margin-top: 4px; color: #ffaa00;">RENDER: 3D VOLUMETRIC WIREFRAME PROJECTION</div>
  </div>

  <div id="toolbar">
    <button class="holo-btn" onclick="toggleSpin()">TOGGLE ROTATION</button>
    <button class="holo-btn" onclick="toggleStereoscopic()">3D DEPTH MODE</button>
    <button class="holo-btn" id="style-cycle" onclick="cycleStyle()">MODE: HOLOGRAM</button>
    <button class="holo-btn" onclick="openBlueprint()">2D BLUEPRINT VIEW</button>
    <button class="holo-btn" onclick="toggleColor()">COLOR SHIFT</button>
    <button class="holo-btn" id="cfg-btn" onclick="toggleCfg()">⚙ CUSTOMISE</button>
    <button class="holo-btn" onclick="openTutorial()">📐 HOW TO BUILD</button>
    <button class="holo-btn" id="tear-btn" onclick="teardown()">DISASSEMBLE [CTRL+A]</button>
    <button class="holo-btn" id="haz-btn" onclick="toggleHaz()">⚠ HAZARDS</button>
    <button class="holo-btn" onclick="window.open('../health/library.html','_blank')">✚ MEDICAL BAY</button>
  </div>

  <!-- Iron-Man-style projection customisation panel -->
  <div id="cfg-panel">
    <div class="cfg-hdr">⚙ PROJECTION CONTROLS <span id="cfg-close" onclick="closeCfg()">✕</span></div>

    <div class="cfg-lbl">RENDER STYLE</div>
    <div id="cfg-styles">
      <button data-s="hologram" onclick="setStyle('hologram')">HOLO</button>
      <button data-s="solid" onclick="setStyle('solid')">SOLID</button>
      <button data-s="blueprint" onclick="setStyle('blueprint')">SCHEMATIC</button>
    </div>

    <div class="cfg-lbl">COLOUR — ARC PALETTE &amp; ANY HEX</div>
    <div id="cfg-swatches"></div>
    <input type="color" id="cfg-color" value="{color_hex}" oninput="setColor(this.value)">

    <div class="cfg-lbl">GLOW <span id="glow-val">100%</span></div>
    <input type="range" id="cfg-glow" min="0" max="200" value="100" oninput="setGlow(this.value)">

    <div class="cfg-lbl">OPACITY <span id="op-val">100%</span></div>
    <input type="range" id="cfg-op" min="20" max="100" value="100" oninput="setOpacity(this.value)">

    <div class="cfg-lbl">ROTATION <span id="spin-val">1.0x</span></div>
    <label class="cfg-row"><input type="checkbox" id="cfg-spinon" onchange="setSpin(this.checked)"> auto-rotate</label>
    <input type="range" id="cfg-spin" min="5" max="150" value="50" oninput="setSpinSpeed(this.value)">

    <div class="cfg-lbl">EFFECTS</div>
    <label class="cfg-row"><input type="checkbox" id="cfg-scan" onchange="setFx('scan', this.checked)"> scan beams</label>
    <label class="cfg-row"><input type="checkbox" id="cfg-dust" onchange="setFx('dust', this.checked)"> dust particles</label>
    <label class="cfg-row"><input type="checkbox" id="cfg-grid" onchange="setFx('grid', this.checked)"> floor grid</label>

    <button class="holo-btn" id="cfg-reset" onclick="resetPrefs()">RESET DEFAULTS</button>
  </div>

  <div id="telemetry-box">
    VOLUMETRIC FLUX: 99.84%<br>
    PROJECTION FREQUENCY: 4.8 THz<br>
    TARGET COORDINATE: [0.0, 0.0, 0.0]<br>
    STARK PROTOCOL: ONLINE
  </div>

  <div id="controls-hint">
    [LEFT MOUSE]: Orbit &nbsp;|&nbsp; [SCROLL]: Zoom &nbsp;|&nbsp; [RIGHT MOUSE]: Pan
  </div>

  <!-- 2D Blueprint Overlay Modal -->
  <!-- Hazard / side-effect analysis -->
  <div id="haz-panel">
    <div class="haz-hdr">⚠ HAZARD ANALYSIS <span id="haz-close" onclick="toggleHaz()">✕</span></div>
    {hazards_html}
    <div class="haz-foot">ANALYSIS: {hazards_risk} · STARK MEDICAL BAY HAS TREATMENT PROTOCOLS</div>
  </div>

  <div id="blueprint-modal" onclick="closeBlueprint()">
    <div id="blueprint-container" onclick="event.stopPropagation()">
      <span id="close-modal" onclick="closeBlueprint()">✕</span>
      <div id="svg-host"></div>
    </div>
  </div>

  <!-- Build tutorial panel -->
  <div id="tut-panel">
    <div class="cfg-hdr">📐 <span id="tut-title">BUILD PROTOCOL</span> <span id="tut-close" onclick="closeTutorial()">✕</span></div>
    <div class="tut-ask">▸ WHAT DO YOU WANT TO BUILD? <i style="color:#0088aa;font-style:normal">— anything at all</i>
      <input id="tut-q" placeholder="lightsaber, master sword, iron man helmet, death star, dalek, portal gun…">
      <div class="tut-chips">
        <button onclick="askQuick('iron man helmet')">Iron-Man helmet</button>
        <button onclick="askQuick('lightsaber')">Lightsaber</button>
        <button onclick="askQuick('master sword')">Master Sword</button>
        <button onclick="askQuick('death star')">Death Star</button>
        <button onclick="askQuick('working owl house model')">Owl House</button>
      </div>
      <button class="holo-btn" onclick="askBuild()">GET BUILD ▸</button>
      <script>document.addEventListener('DOMContentLoaded', function() {{ var q = document.getElementById('tut-q'); if (q) q.addEventListener('keydown', function (e) {{ if (e.key === 'Enter') {{ e.stopPropagation(); askBuild(); }} }}); }});</script>
    </div>
    <div id="tut-steps"></div>
  </div>

  <!-- JARVIS build assistant — middle-right -->
  <div id="jh-wrap">
    <div id="jh-panel">
      <div class="jh-hdr">J.A.R.V.I.S · BUILD ASSISTANT <span id="jh-close" onclick="toggleJH()">✕</span></div>
      <div id="jh-msgs"></div>
      <div class="jh-inrow">
        <input id="jh-in" placeholder="Ask me about the build…">
        <button onclick="jhSend()">▸</button>
      </div>
    </div>
    <div id="jh-avatar" onclick="toggleJH()"><span>◉</span><i>JARVIS</i></div>
  </div>

  <script>
    const svgCode = `{escaped_svg}`;
    document.getElementById('svg-host').innerHTML = svgCode;

    function openBlueprint() {{
      document.getElementById('blueprint-modal').style.display = 'flex';
    }}
    function closeBlueprint() {{
      document.getElementById('blueprint-modal').style.display = 'none';
    }}

    // Three.js Holographic Setup with Enhanced 3D Depth
    const scene = new THREE.Scene();
    
    // Enhanced camera with stronger perspective for better 3D perception
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(60, 40, 80);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({{ antialias: true, alpha: true }});
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setClearColor(0x00080a, 1); // Deep background
    document.body.appendChild(renderer.domElement);

    // Stage sizing that never trusts a zero-size window: embedded webviews and
    // pre-layout loads can report innerWidth/Height 0 at script time, which
    // collapses the canvas to 0x0 and kills the projection for good (no
    // resize event ever fires to fix it). fitStage() clamps to >=1 px, derives
    // the aspect safely, and is re-run from several hooks so the stage always
    // matches the real viewport.
    function fitStage() {{
      const w = Math.max(1, window.innerWidth  || document.documentElement.clientWidth  || 960);
      const h = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 600);
      // same-size calls realloc the GL drawing buffer mid-render and the
      // context rejects the in-flight batch — vertex-buffer warning spam
      if (renderer.domElement.width === w * window.devicePixelRatio &&
          renderer.domElement.height === h * window.devicePixelRatio) return;
      renderer.setSize(w, h, true);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    }}
    fitStage();

    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 30;
    controls.maxDistance = 200;

    // Enhanced multi-directional lighting for 3D depth
    scene.add(new THREE.AmbientLight(0x002233, 0.5));
    
    const pLight = new THREE.PointLight('{color_hex}', 3, 400);
    pLight.position.set(50, 80, 50);
    scene.add(pLight);
    
    const pLight2 = new THREE.PointLight('{color_hex}', 2, 300);
    pLight2.position.set(-50, 40, -50);
    scene.add(pLight2);
    
    const pLight3 = new THREE.PointLight(0xff6600, 1.5, 250);
    pLight3.position.set(0, -30, 60);
    scene.add(pLight3);

    // Enhanced 3D coordinate grid with depth
    const grid = new THREE.GridHelper(160, 32, '{color_hex}', 0x052336);
    grid.position.y = -35;
    grid.material.opacity = 0.3;
    grid.material.transparent = true;
    scene.add(grid);
    
    // Add vertical grid for 3D depth perception
    const gridV = new THREE.GridHelper(160, 32, '{color_hex}', 0x052336);
    gridV.rotation.x = Math.PI / 2;
    gridV.position.z = -35;
    gridV.material.opacity = 0.2;
    gridV.material.transparent = true;
    scene.add(gridV);

    // Enhanced 3D fog for atmospheric depth
    scene.fog = new THREE.FogExp2(0x00080a, 0.008);

    // Rotating Holographic Concentric Tech Rings with 3D depth
    function makeRing(rad, y, opacity = 0.35) {{
      const geo = new THREE.RingGeometry(rad, rad + 0.8, 128);
      const mat = new THREE.MeshBasicMaterial({{
        color: '{color_hex}',
        side: THREE.DoubleSide,
        transparent: true,
        opacity: opacity,
        wireframe: true,
        blending: THREE.AdditiveBlending
      }});
      const ring = new THREE.Mesh(geo, mat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = y;
      scene.add(ring);
      return ring;
    }}
    
    // Multiple ring layers for depth perception
    const ringInner = makeRing(50, -34.8, 0.5);
    const ringMiddle = makeRing(60, -34.8, 0.35);
    const ringOuter = makeRing(72, -34.8, 0.25);
    const ringOuter2 = makeRing(85, -34.8, 0.15);

    // Enhanced 3D Scanning Laser Beam with depth
    const scanPlaneGeo = new THREE.PlaneGeometry(150, 0.6);
    const scanPlaneMat = new THREE.MeshBasicMaterial({{
      color: 0xffaa00,
      transparent: true,
      opacity: 0.7,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending
    }});
    const scanBeam = new THREE.Mesh(scanPlaneGeo, scanPlaneMat);
    scanBeam.rotation.x = Math.PI / 2;
    scene.add(scanBeam);
    
    // Add horizontal scanning beam for 3D depth
    const scanBeamH = new THREE.Mesh(scanPlaneGeo, scanPlaneMat);
    scanBeamH.rotation.z = Math.PI / 2;
    scene.add(scanBeamH);

    // Object Group with enhanced depth
    const hologramGroup = new THREE.Group();
    scene.add(hologramGroup);

    let currentHex = '{color_hex}';
    let lineMaterial = new THREE.LineBasicMaterial({{
      color: currentHex,
      linewidth: 2,
      transparent: true,
      opacity: 0.9
    }});
    let wireMaterial = new THREE.MeshBasicMaterial({{
      color: currentHex,
      wireframe: true,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending
    }});

    let autoSpin = true;
    let stereoscopicMode = false;
    
    function toggleSpin() {{
      autoSpin = !autoSpin;
    }}
    
    function toggleStereoscopic() {{
      stereoscopicMode = !stereoscopicMode;
      if (stereoscopicMode) {{
        camera.position.set(50, 35, 70);
        camera.fov = 75;
        camera.updateProjectionMatrix();
        scene.fog.density = 0.012;
        grid.material.opacity = 0.5;
        gridV.material.opacity = 0.4;
      }} else {{
        camera.position.set(60, 40, 80);
        camera.fov = 60;
        camera.updateProjectionMatrix();
        scene.fog.density = 0.008;
        grid.material.opacity = 0.3;
        gridV.material.opacity = 0.2;
      }}
    }}

    // Execute Dynamic Three.js Geometry for ANY object.
    // The synthesiser returns the BODY of populateCustomHologram (if the model
    // added its own wrapper declaration anyway, Python unwraps it back to a
    // body), so it is re-wrapped here exactly once and then called. If the
    // dynamic code fails to parse or run, the procedural Stark fallback
    // builds a real object locally — never the bare geometric sphere.
    function populateCustomHologram(group, colorHex, lineMaterial, wireMaterial) {{
      {threejs_logic}
    }}

    function buildProceduralFallback(group, colorHex, lineMaterial, wireMaterial) {{
      {fallback_js}
    }}

    try {{
      populateCustomHologram(hologramGroup, currentHex, lineMaterial, wireMaterial);
    }} catch(e) {{
      console.warn("Dynamic geometry fallback:", e);
      try {{
        buildProceduralFallback(hologramGroup, currentHex, lineMaterial, wireMaterial);
      }} catch(e2) {{
        console.warn("Procedural fallback failed:", e2);
        const fallbackGeo = new THREE.IcosahedronGeometry(28, 2);
        hologramGroup.add(new THREE.LineSegments(new THREE.WireframeGeometry(fallbackGeo), lineMaterial));
      }}
    }}

    // Particle Cloud
    const partCount = 220;
    const partGeo = new THREE.BufferGeometry();
    const pPos = new Float32Array(partCount * 3);
    for (let i = 0; i < partCount * 3; i += 3) {{
      pPos[i] = (Math.random() - 0.5) * 160;
      pPos[i + 1] = (Math.random() - 0.5) * 90;
      pPos[i + 2] = (Math.random() - 0.5) * 160;
    }}
    partGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    const partMat = new THREE.PointsMaterial({{ color: currentHex, size: 1.4, transparent: true, opacity: 0.55 }});
    const particles = new THREE.Points(partGeo, partMat);
    scene.add(particles);

    // Render style cycling (toolbar button) — same engine as ⚙ CUSTOMISE
    const STYLE_CYCLE = ['hologram', 'solid', 'blueprint'];
    const STYLE_LABEL = {{ hologram: 'MODE: HOLOGRAM', solid: 'MODE: SOLID', blueprint: 'MODE: SCHEMATIC' }};
    function cycleStyle() {{
      const next = STYLE_CYCLE[(STYLE_CYCLE.indexOf(holo.style) + 1) % STYLE_CYCLE.length];
      setStyle(next);
      const lbl = document.getElementById('style-cycle');
      if (lbl) lbl.textContent = STYLE_LABEL[next];
    }}

    // ═══ Iron-Man-style customisation engine ════════════════════════════
    // Every visual aspect of the projection is a preference: style, colour,
    // glow, opacity, spin, scan/dust/grid. Preferences persist in
    // localStorage, so the suit is configured once and stays configured —
    // across every hologram, and across sessions.
    const HOLO_PRESETS = ['#00d4ff', '#e0143c', '#ffaa00', '#00ff88', '#aa00ff', '#e8f6ff'];
    const HOLO_DEFAULTS = {{
      style: '{initial_style}',
      color: currentHex,
      glow: 1.0,
      opacity: 1.0,
      spin: true,
      spinSpeed: 1.0,
      scan: true,
      dust: true,
      grid: true
    }};
    let holo = Object.assign({{}}, HOLO_DEFAULTS);
    try {{
      const raw = localStorage.getItem('holo_prefs_v1');
      if (raw) {{
        const saved = JSON.parse(raw);
        Object.keys(holo).forEach(k => {{ if (saved[k] !== undefined) holo[k] = saved[k]; }});
      }}
    }} catch(e) {{}}

    function savePrefs() {{
      try {{ localStorage.setItem('holo_prefs_v1', JSON.stringify(holo)); }} catch(e) {{}}
    }}

    // Every material the hologram was born with, so style/glow/opacity can
    // be re-applied relative to the ORIGINAL look instead of compounding.
    let holoMats = [];
    (function collectMats() {{
      hologramGroup.traverse(c => {{
        if (c.material && c.material.opacity !== undefined) {{
          if (c.material.userData.baseOpacity === undefined)
            c.material.userData.baseOpacity = c.material.opacity;
          holoMats.push(c.material);
        }}
      }});
    }})();

    function applyColor() {{
      const c = holo.color;
      document.documentElement.style.setProperty('--holo-color', c);
      lineMaterial.color.set(c);
      wireMaterial.color.set(c);
      pLight.color.set(c);
      if (pLight2) pLight2.color.set(c);
      [ringInner, ringMiddle, ringOuter, ringOuter2].forEach(r => r && r.material.color.set(c));
      grid.material.color.set(c);
      gridV.material.color.set(c);
      scanPlaneMat.color.set(c);
      holoMats.forEach(m => m.color && m.color.set(c));
      document.querySelectorAll('.swatch').forEach(s => s.classList.toggle('sel', s.dataset.c === c));
      const inp = document.getElementById('cfg-color');
      if (inp && inp.value.toLowerCase() !== c.toLowerCase()) inp.value = c;
      savePrefs();
    }}

    function applyStyle() {{
      const st = holo.style;
      document.querySelectorAll('#cfg-styles button').forEach(
        b => b.classList.toggle('active', b.dataset.s === st));
      hologramGroup.traverse(c => {{
        if (!c.material || c.material.userData.baseOpacity === undefined) return;
        const base = c.material.userData.baseOpacity;
        if (st === 'solid') {{
          c.material.wireframe = false;
          c.material.opacity = Math.min(0.85, base * 2.2) * holo.opacity;
        }} else if (st === 'blueprint') {{
          c.material.wireframe = true;
          c.material.opacity = Math.min(1, base * 1.15) * holo.opacity;
        }} else {{
          c.material.wireframe = true;
          c.material.opacity = base * holo.opacity;
        }}
      }});
      grid.material.opacity = st === 'blueprint' ? 0.5 : 0.3;
      gridV.material.opacity = st === 'blueprint' ? 0.35 : 0.2;
      const lbl = document.getElementById('style-cycle');
      if (lbl) lbl.textContent = STYLE_LABEL[st];
      savePrefs();
    }}

    function applyGlow() {{
      const c = holo.color;
      document.documentElement.style.setProperty('--holo-glow',
        '0 0 ' + Math.round(14 * holo.glow) + 'px ' + c);
      holoMats.forEach(m => {{
        const base = m.userData.baseOpacity || 0.3;
        const boost = (m.blending === THREE.AdditiveBlending) ? holo.glow : 1.0;
        m.opacity = Math.min(1, base * holo.opacity * boost);
      }});
      savePrefs();
    }}

    function applyFx() {{
      scanBeam.visible = scanBeamH.visible = holo.scan;
      particles.visible = holo.dust;
      hologramGroup.traverse(c => {{ if (c.type === 'Points') c.visible = holo.dust; }});
      grid.visible = gridV.visible = holo.grid;
      autoSpin = holo.spin;
      savePrefs();
    }}

    function applyAll() {{ applyColor(); applyStyle(); applyGlow(); applyFx(); }}

    // ── panel wiring ────────────────────────────────────────────────────
    const cfgPanel = document.getElementById('cfg-panel');
    function toggleCfg() {{ cfgPanel.classList.toggle('open'); }}
    function openCfg()  {{ cfgPanel.classList.add('open'); }}
    function closeCfg() {{ cfgPanel.classList.remove('open'); }}

    function setStyle(s) {{ holo.style = s; applyStyle(); applyGlow(); }}
    function setColor(c) {{ holo.color = c; applyColor(); applyGlow(); }}
    function setGlow(v) {{
      holo.glow = v / 100;
      document.getElementById('glow-val').textContent = v + '%';
      applyGlow();
    }}
    function setOpacity(v) {{
      holo.opacity = v / 100;
      document.getElementById('op-val').textContent = v + '%';
      applyStyle(); applyGlow();
    }}
    function setSpin(on) {{ holo.spin = on; applyFx(); }}
    function setSpinSpeed(v) {{
      holo.spinSpeed = v / 50;
      document.getElementById('spin-val').textContent = (v / 50).toFixed(1) + 'x';
      savePrefs();
    }}
    function setFx(k, on) {{ holo[k] = on; applyFx(); }}
    function resetPrefs() {{
      holo = Object.assign({{}}, HOLO_DEFAULTS);
      document.getElementById('cfg-glow').value = 100;
      document.getElementById('glow-val').textContent = '100%';
      document.getElementById('cfg-op').value = 100;
      document.getElementById('op-val').textContent = '100%';
      document.getElementById('cfg-spin').value = 50;
      document.getElementById('spin-val').textContent = '1.0x';
      document.getElementById('cfg-spinon').checked = true;
      document.getElementById('cfg-scan').checked = true;
      document.getElementById('cfg-dust').checked = true;
      document.getElementById('cfg-grid').checked = true;
      applyAll();
    }}

    function toggleColor() {{
      const i = HOLO_PRESETS.indexOf(holo.color.toLowerCase());
      setColor(HOLO_PRESETS[(i + 1) % HOLO_PRESETS.length]);
    }}

    // build swatches + sync every control to the saved prefs, then apply
    (function initCfg() {{
      const sw = document.getElementById('cfg-swatches');
      HOLO_PRESETS.forEach(c => {{
        const s = document.createElement('div');
        s.className = 'swatch'; s.dataset.c = c; s.style.background = c;
        s.title = c;
        s.onclick = () => setColor(c);
        sw.appendChild(s);
      }});
      document.getElementById('cfg-glow').value = Math.round(holo.glow * 100);
      document.getElementById('glow-val').textContent = Math.round(holo.glow * 100) + '%';
      document.getElementById('cfg-op').value = Math.round(holo.opacity * 100);
      document.getElementById('op-val').textContent = Math.round(holo.opacity * 100) + '%';
      document.getElementById('cfg-spin').value = Math.round(holo.spinSpeed * 50);
      document.getElementById('spin-val').textContent = Number(holo.spinSpeed).toFixed(1) + 'x';
      document.getElementById('cfg-spinon').checked = !!holo.spin;
      document.getElementById('cfg-scan').checked = !!holo.scan;
      document.getElementById('cfg-dust').checked = !!holo.dust;
      document.getElementById('cfg-grid').checked = !!holo.grid;
      applyAll();
    }})();

    // Volumetric holographic animation loop with realistic physics
    let time = 0;
    // Render only when the tab is visible; skip duplicate frames at high
    // refresh rates (144 Hz screens do not need 144 WebGL renders per second
    // for a hologram that rotates at 0.008 rad/frame).
    let _lastRender = 0;
    let _warmup = 2;   // first frames skip drawing — the embedded compositor
                       // is not yet attached and the GL context rejects the
                       // batch, spamming vertex-buffer warnings on load
    function animate(now) {{
      requestAnimationFrame(animate);
      now = now || performance.now();
      if (document.hidden) return;
      if (_warmup > 0) {{ _warmup--; return; }}
      if (now - _lastRender < 24) return;   // ~40 fps ceiling, smooth at any Hz
      const dt = Math.min(0.05, (now - _lastRender) / 1000);
      _lastRender = now;
      time += dt;
      
      // Smooth rotation with momentum (speed is a preference)
      if (autoSpin) {{
        hologramGroup.rotation.y += 0.008 * holo.spinSpeed;
        hologramGroup.rotation.x = Math.sin(time * 0.3) * 0.05;
      }}
      
      // Animate holographic parts for volumetric effect
      if (hologramGroup.userData.hologramParts) {{
        const parts = hologramGroup.userData.hologramParts;
        
        // Core breathing effect with complex harmonic motion
        if (parts.core) {{
          const scale = 1 + Math.sin(time * 2) * 0.04;
          parts.core.scale.set(scale, scale, scale);
        }}
        
        // Wireframe secondary rotation for depth
        if (parts.wireCore2) {{
          parts.wireCore2.rotation.x += 0.005;
          parts.wireCore2.rotation.y += 0.003;
        }}
        
        // Multi-ring rotation at different speeds for depth perception
        if (parts.ring1) parts.ring1.rotation.z += 0.012;
        if (parts.ring2) parts.ring2.rotation.z -= 0.009;
        if (parts.ring3) parts.ring3.rotation.z += 0.007;
        if (parts.ring4) parts.ring4.rotation.z -= 0.005;
        
        // Scanning plane vertical movement with varying speed
        if (parts.scan) {{
          parts.scan.position.y = Math.sin(time * 1.8) * 25;
          parts.scan.material.opacity = 0.05 + Math.sin(time * 2) * 0.03;
        }}
        
        // Enhanced particle system with individual velocity and Brownian motion
        if (parts.particles && parts.particleVelocities) {{
          const positions = parts.particles.geometry.attributes.position.array;
          const basePositions = parts.basePositions;
          const velocities = parts.particleVelocities;
          
          for(let i = 0; i < positions.length; i += 3) {{
            // Apply velocity with time-varying component
            positions[i] += velocities[i/3].x + Math.sin(time + i) * 0.02;
            positions[i + 1] += velocities[i/3].y + Math.cos(time + i) * 0.02;
            positions[i + 2] += velocities[i/3].z + Math.sin(time * 0.5 + i) * 0.02;
            
            // Boundary wrapping for continuous effect
            if(Math.abs(positions[i]) > 70) positions[i] *= -0.9;
            if(Math.abs(positions[i + 1]) > 70) positions[i + 1] *= -0.9;
            if(Math.abs(positions[i + 2]) > 70) positions[i + 2] *= -0.9;
          }}
          
          parts.particles.geometry.attributes.position.needsUpdate = true;
        }}
      }}
      
      // Background rings rotation with 3D depth motion
      if (ringInner) ringInner.rotation.z += 0.005;
      if (ringMiddle) ringMiddle.rotation.z -= 0.004;
      if (ringOuter) ringOuter.rotation.z += 0.003;
      if (ringOuter2) ringOuter2.rotation.z -= 0.002;
      
      // Enhanced 3D oscillation for depth perception
      if (ringInner) ringInner.position.y = -34.8 + Math.sin(time * 2) * 2;
      if (ringMiddle) ringMiddle.position.y = -34.8 + Math.sin(time * 2.2) * 1.5;
      if (ringOuter) ringOuter.position.y = -34.8 + Math.sin(time * 2.4) * 1;
      if (ringOuter2) ringOuter2.position.y = -34.8 + Math.sin(time * 2.6) * 0.5;
      
      // 3D scanning beam motion
      if (scanBeam) {{
        scanBeam.position.y = Math.sin(time * 1.5) * 30;
        scanBeam.material.opacity = 0.5 + Math.sin(time * 3) * 0.2;
      }}
      if (scanBeamH) {{
        scanBeamH.position.z = Math.sin(time * 1.5) * 30;
        scanBeamH.material.opacity = 0.5 + Math.cos(time * 3) * 0.2;
      }}
      
      // Scanning beam horizontal sweep
      scanBeam.position.x = Math.sin(time * 0.8) * 30;
      
      // Controls update
      controls.update();
      renderer.render(scene, camera);

      // Projected part names — float over each piece while disassembled.
      // Read after render so matrixWorld is fresh; ~10 DOM writes only when
      // exploded, zero cost otherwise.
      if (exploded && _labels.size) {{
        const vp = renderer.domElement.getBoundingClientRect();
        const v = new THREE.Vector3();
        _parts.forEach(p => {{
          const el = _labels.get(p);
          if (!el) return;
          v.setFromMatrixPosition(p.matrixWorld).project(camera);
          if (v.z < 1) {{
            el.style.display = 'block';
            el.style.left = (vp.left + (v.x * 0.5 + 0.5) * vp.width) + 'px';
            el.style.top  = (vp.top + (-v.y * 0.5 + 0.5) * vp.height) + 'px';
          }} else el.style.display = 'none';
        }});
      }}
    }}

    // ── BUILD TUTORIAL + TEARDOWN / DRAG ───────────────────────────────
    function openTutorial() {{ document.getElementById('tut-panel').classList.add('open'); }}
    function closeTutorial() {{ document.getElementById('tut-panel').classList.remove('open'); }}

    function toggleHaz() {{ document.getElementById('haz-panel').classList.toggle('open'); }}

    // ── real build tutorial (knowledge base injected by Python) ─────────
    const TUT = {tut_json};
    let _curPlan = TUT;   // plan currently rendered — the assistant reads it

    // ── universal planner: composes a real build protocol for ANY object ──
    // Mirrors the Python generator: shape recipe by object class, materials
    // by size class, process order, tool-free alternatives.
    function universalPlan(q) {{
      const s = q.toLowerCase();
      const short = q.length > 28 ? q.slice(0, 25).trim() + '…' : q;
      const big = /(life ?size|full ?size|cosplay|wearable|human|giant|statue|suit|armou?r|helmet|mask|car|vehicle|jet|ship|door|sword|shield|bow|rifle|gun|staff|hammer)/.test(s);
      const lights = /(reactor|core|glow|led|lamp|neon|light|energy|plasma|saber|laser)/.test(s);
      let shape = "the viewer's own blueprint SVG printed at scale as your master template";
      const recipes = [
        [/mask|face|helmet|head|visor/, "an existing STL ('{{o}} STL free' on Printables/MyMiniFactory/Thingiverse) or a plaster strip cast of your own face as the buck"],
        [/armou?r|chest|gauntlet|boot|shin|pauldron/, "pepakura/EVA-foam templates (search '{{o}} foam template') — scale to your body measurements before cutting"],
        [/gun|rifle|blaster|sword|blade|axe|hammer|staff|wand|saber/, "a side-profile printout glued to 6 mm MDF or layered foam-board, cut and stacked to thickness"],
        [/drone|jet|plane|rocket|ship|car|vehicle|engine/, "a 3-view blueprint printed at target scale, then an STL or built-up foam/card over a light frame"],
        [/ring|medallion|amulet|badge|coin|emblem|sigil/, "the viewer's own blueprint SVG printed at size — cast in resin, carve from layered card, or print flat with a raised rim"],
        [/reactor|core|lamp|lantern/, "printed or acrylic cut rings, a diffuser disc, and LEDs inside — plan the wiring channel first"],
        [/creature|skull|dragon|monster|skeleton/, "a printable model in sections, or sculpt over a crumpled-foil armature with air-dry clay"],
        [/house|tower|castle|building|city|bridge|station|star/, "cardboard + hot-glue over a card skeleton for volume, xps foam sheets for surfaces"],
      ];
      for (const [re, rec] of recipes) if (re.test(s)) {{ shape = rec.replace('{{o}}', short); break; }}
      const steps = [
        {{ name: 'CAPTURE THE SHAPE', detail: 'Get the geometry of the ' + short + ' before touching material: ' + shape + '. Draw or print front + side views at final scale — every measurement comes off these.', mats: ['Reference views', 'Printer'] }},
        big
          ? {{ name: 'BUILD THE BODY', detail: '6-10 mm EVA foam as the primary body — cheap, light, heat-shapes over curves. Cut all major pieces from your pattern in one session, test-fit as you go: measure twice, cut once.', mats: ['EVA foam 6-10 mm', 'Contact cement', 'Utility knife + mat'] }}
          : {{ name: 'BUILD THE BODY', detail: 'Layered cardboard + PVA (free, rock hard) or a small 3D print if the STL exists. Tape the printed plan to the material and cut through both — accuracy comes from the template.', mats: ['Cardboard layers', 'PVA glue', 'Craft knife'] }},
        {{ name: 'DETAIL PASS', detail: "Add the " + short + "'s signature details as separate small pieces glued on — panel lines scribed with a blunt tool, raised trim from thin foam strip. Depth reads better than paint alone.", mats: ['Thin foam/card strip', 'Scribing tool'] }},
        big
          ? {{ name: 'HARDEN + SMOOTH', detail: 'Heat-shape foam over curves, then seal with 2-3 coats of PVA and flexible primer so paint never cracks on flex. This stage is 80 % of how real it looks.', mats: ['Heat gun', 'PVA', 'Flexible primer'] }}
          : {{ name: 'HARDEN + SMOOTH', detail: 'Sand 120 → 400, skim spot-putty over joins, filler primer, wet-sand 600 for a moulded surface. Do not rush it.', mats: ['Sandpaper 120/400/600', 'Spot putty', 'Filler primer'] }},
        {{ name: 'PAINT + ASSEMBLE', detail: 'Prime, base coat, shade recesses with a dark wash, catch edges with a light dry-brush — the two tricks that make anything look machined. Assemble last so every face stays reachable.', mats: ['Paints', 'Wash + dry-brush', 'CA glue'] }},
        lights
          ? {{ name: 'LIGHT IT', detail: 'Wire the glow: LEDs on a coin cell or battery pack, diffused behind frosted plastic or baking paper — bare LEDs read as dots, diffusion reads as plasma. Leave a hidden battery hatch.', mats: ['LEDs + cell/pack', 'Frosted acrylic/baking paper', 'Thin wire'] }}
          : {{ name: 'DISPLAY', detail: 'Finish the ' + short + ' for its setting: stand, wall mount or wear rig. Clear coat (matte = screen-accurate, gloss = fresh off the line) locks the paint.', mats: ['Clear coat', 'Stand/mount'] }},
      ];
      const solutions = [
        'NO 3D PRINTER: cardboard + PVA lamination (6-7 layers, rock hard) or EVA-foam layered and heat-shaped — both finish identically after primer.',
        'NO BUDGET: cereal-box card for detail parts, paper-mache (3 layers + white glue) for rigidity, egg-carton texture for organic surfaces.',
        'NO WORKSHOP TOOLS: sharp craft knife + steel ruler + cutting mat replace 90 % of power tools; sandpaper on a block replaces a sander.',
        'NO PAINT BUDGET: one grey primer + one accent colour + a black wash covers most schemes.',
      ];
      if (lights) solutions.push('NO ELECTRONICS: EL-wire, battery fairy-lights, or a phone-torch behind the diffuser for static glow.');
      return {{ title: 'BUILD PROTOCOL — ' + q.toUpperCase(), steps, solutions,
               estimate: big ? '1-2 weekends' : 'an evening to a weekend' }};
    }}
    // planner bridge: curated KB first, then the universal composer
    window.__holoPlan = function (q, ok, fail) {{
      const key = matchTut(q);
      if (TUT.kb && TUT.kb[key]) {{ ok(TUT.kb[key]); return; }}
      ok(universalPlan(q));
    }};

    // talk: shared voice handle for the build assistant
    let _voice = null;
    function _pickVoice() {{
      if (!window.speechSynthesis) return null;
      const vs = speechSynthesis.getVoices();
      const prefs = [/daniel/i, /google uk english male/i, /ryan/i, /george/i, /arthur/i, /oliver/i];
      for (const re of prefs) for (const v of vs) if (re.test(v.name)) return v;
      for (const v of vs) if (/en[-_]GB/i.test(v.lang)) return v;
      for (const v of vs) if (/^en/i.test(v.lang)) return v;
      return vs[0] || null;
    }}
    function say(text) {{
      try {{
        if (!window.speechSynthesis) return;
        const u = new SpeechSynthesisUtterance(text);
        if (!_voice) _voice = _pickVoice();
        if (_voice) u.voice = _voice;
        u.lang = (_voice && _voice.lang) || 'en-GB';
        u.pitch = 0.92; u.rate = 0.97; u.volume = 0.9;
        speechSynthesis.speak(u);
      }} catch (e) {{}}
    }}

    // render a plan; rem numbers after removals; every step gets a bin
    function renderTut(t) {{
      _curPlan = t;
      const host = document.getElementById('tut-steps');
      let h = '';
      t.steps.forEach((s, i) => {{
        h += '<div class="tut-step" data-i="' + i + '"><span class="bin" title="Remove this step" onclick="dropStep(this)">🗑</span>' +
             '<b>' + (i + 1) + ' · ' + s.name.replace(/^\\d+\\s*·\\s*/, '') + '</b><span>' + s.detail + '</span>';
        if (s.mats && s.mats.length)
          h += '<div class="tut-mats">' + s.mats.map(m => '<i>' + m + '</i>').join('') + '</div>';
        h += '</div>';
      }});
      if (t.solutions && t.solutions.length) {{
        h += '<div class="tut-sol"><h4>◆ NO PRINTER? NO PROBLEM — WORKING ALTERNATIVES</h4>';
        t.solutions.forEach(s => h += '<p>' + s + '</p>');
        h += '</div>';
      }}
      if (t.estimate) h += '<div class="tut-est">ESTIMATED BUILD TIME: ' + t.estimate.toUpperCase() + '</div>';
      host.innerHTML = h;
    }}
    function dropStep(binEl) {{
      const row = binEl.closest('.tut-step');
      if (!row) return;
      row.classList.add('gone');
      setTimeout(() => {{
        row.remove();
        // renumber what is left so the protocol stays readable
        document.querySelectorAll('#tut-steps .tut-step').forEach((el, i) => {{
          const b = el.querySelector('b');
          if (b) b.textContent = (i + 1) + ' · ' + b.textContent.replace(/^\\d+\\s*·\\s*/, '');
        }});
      }}, 300);
      say('Step removed, sir.');
    }}
    renderTut(TUT);

    // BUILD ANYTHING: try the AI planner first (full custom build-plan),
    // then the curated KB, then Python's universal generator baked into TUT.
    function askBuild(qIn) {{
      const q = (qIn !== undefined ? qIn : document.getElementById('tut-q').value).trim();
      if (!q) return;
      document.getElementById('tut-q').value = q;
      openTutorial();
      const host = document.getElementById('tut-steps');
      host.innerHTML = '<div style="color:#0088aa;font-size:10px;letter-spacing:1px">▸ SYNTHESISING BUILD PROTOCOL FOR: ' +
        q.toUpperCase() + ' …</div>';
      const done = (plan, src) => {{
        if (!plan || !plan.steps || !plan.steps.length) {{ plan = TUT; src = 'protocol'; }}
        plan.title = plan.title || ('BUILD PROTOCOL — ' + q.toUpperCase());
        const ttl = document.getElementById('tut-title');
        if (ttl) ttl.textContent = '📐 ' + plan.title;
        renderTut(plan);
        say('Build protocol for ' + q + ' synthesised, sir. ' + plan.steps.length + ' stages.');
      }};
      // planner bridge: curated KB, else the universal composer (any object)
      try {{
        if (window.__holoPlan) {{ window.__holoPlan(q, plan => done(plan, 'plan')); return; }}
      }} catch (e) {{}}
      const key = matchTut(q);
      done(TUT.kb && TUT.kb[key] ? TUT.kb[key] : TUT, 'kb');
    }}
    function askQuick(q) {{ askBuild(q); }}
    function matchTut(q) {{
      q = q.toLowerCase();
      if (q.includes('spider')) return 'spiderman';
      if (/(helmet|mask|suit|iron man)/.test(q) && !q.includes('spider')) return 'helmet';
      if (q.includes('reactor')) return 'reactor';
      return 'default';
    }}

    // ── JARVIS build assistant (middle-right) — talks, helps, removable ──
    const KB = TUT.kb || {{}};
    function jhSay(text, who, opts) {{
      const box = document.getElementById('jh-msgs');
      const el = document.createElement('div');
      el.className = 'jh-m ' + (who || 'jarvis');
      const bin = who === 'user' ? '<span class="bin" title="Remove message" onclick="this.parentNode.remove()">🗑</span> ' : '';
      el.innerHTML = bin + document.createElement('div').appendChild(document.createTextNode(text)).textContent;
      box.appendChild(el);
      box.scrollTop = box.scrollHeight;
      if (who !== 'user' && !(opts && opts.quiet)) say(text);
      return el;
    }}
    function jhHelp() {{
      const box = document.getElementById('jh-msgs');
      const el = document.createElement('div');
      el.style.margin = '6px 0';
      el.innerHTML =
        `<span class="jh-chip" onclick="jhAsk('What do I need for this build?')">What do I need?</span>` +
        `<span class="jh-chip" onclick="jhAsk('Where do I start?')">Where do I start?</span>` +
        `<span class="jh-chip" onclick="jhAsk('I do not have a 3D printer')">No 3D printer</span>` +
        `<span class="jh-chip" onclick="jhAsk('How long will this take?')">How long?</span>` +
        `<span class="jh-chip" onclick="jhAsk('What are the hazards?')">Hazards</span>`;
      box.appendChild(el);
      box.scrollTop = box.scrollHeight;
    }}
    const JH_GREET = 'At your service, sir. I can plan the build of anything you name — say the word. Ask about materials, order of operations, or working without a 3D printer.';
    jhSay(JH_GREET, 'jarvis', {{ quiet: true }});
    jhHelp();
    function toggleJH() {{
      const p = document.getElementById('jh-panel');
      const opening = !p.classList.contains('open');
      p.classList.toggle('open');
      if (opening) say('Yes, sir?');
    }}
    function jhAsk(q) {{ jhSend(q); }}
    function jhSend(forced) {{
      const inp = document.getElementById('jh-in');
      const q = (forced || inp.value).trim();
      if (!q) return;
      if (!forced) inp.value = '';
      jhSay(q, 'user');
      setTimeout(() => {{ const a = jhAnswer(q); jhSay(a); }}, 350);
    }}
    document.getElementById('jh-in').addEventListener('keydown', e => {{ if (e.key === 'Enter') jhSend(); }});
    function jhAnswer(q) {{
      const s = q.toLowerCase();
      const t = _curPlan || TUT;
      // “build me X / how to build X / make X” → synthesise that plan on the spot
      if (/^(build|make|create|how (do|to) (i )?(build|make))/.test(s) || /build (me |a |an |the )/.test(s)) {{
        const obj = q.replace(/^(build|make|create|how (do|to) (i )?(build|make))\\s*(me |a |an |the )?/i, '').trim() || q;
        setTimeout(() => askBuild(obj), 500);
        return 'Right away, sir — synthesising the build protocol for ' + obj + '.';
      }}
      if (/printer|3d print|no printer/.test(s))
        return 'Without a 3D printer, sir: ' + (t.solutions && t.solutions[0] ? t.solutions[0] : 'cardboard + PVA lamination or EVA-foam pepakura — both finish identically after priming.') + ' The WORKING ALTERNATIVES section has the full list.';
      if (/material|need|supplies|buy/.test(s)) {{
        const mats = [...new Set(t.steps.flatMap(x => x.mats || []))];
        return 'For ' + (t.title || 'this build').toLowerCase().replace('build protocol — ', '') + ' you will need: ' + (mats.slice(0, 8).join(', ') || 'the basics — see the panel') + '. The full list sits under each step in the BUILD PROTOCOL panel.';
      }}
      if (/start|first|order|begin/.test(s))
        return 'Start with: ' + (t.steps[0] ? t.steps[0].name + ' — ' + t.steps[0].detail.slice(0, 130) + '…' : 'step one in the panel') + ' Everything else mounts to it.';
      if (/time|long|when/.test(s))
        return t.estimate ? 'Realistically: ' + t.estimate + ', sir. Rushing the finishing stage is where builds go wrong.' : 'A weekend usually covers it, sir — two if you are weathering and lighting it as well.';
      if (/remind|what.*doing|where.*we|summary/.test(s))
        return 'You are on the build of ' + (document.getElementById('tut-title').textContent.replace('📐 BUILD PROTOCOL — ', '') || 'this object') + ', at step ' + document.querySelectorAll('#tut-steps .tut-step').length + ' of the protocol. Ask me to repeat any stage.';
      if (/hazard|safe|danger|poison/.test(s))
        return 'Open the HAZARDS panel — the full risk analysis lives there, with symptoms and mitigation for anything critical.';
      return 'I can plan the build of anything, sir — try “build a lightsaber” or type it in the BUILD panel. For this ' + (t.title || 'project').toLowerCase() + ': ' + t.steps.length + ' stages, materials listed under each.';
    }}

    let exploded = false;
    let explodeAnim = null;
    // Named parts fly apart on disassembly; the projection rig (pad, rings,
    // dust, scan) stays put — it is the stage, not a component.
    let _parts = hologramGroup.children.filter(ch => ch.userData.partName && !ch.userData.isRig);
    if (!_parts.length) _parts = hologramGroup.children.filter(ch => !ch.userData.isRig);
    const _labels = new Map();   // part Group -> its floating name label
    _parts.forEach(p => {{
      if (!p.userData.partName) return;
      const el = document.createElement('div');
      el.className = 'part-lbl';
      el.textContent = p.userData.partName;
      document.body.appendChild(el);
      _labels.set(p, el);
    }});
    function teardown() {{
      exploded = !exploded;
      document.getElementById('tear-btn').classList.toggle('active', exploded);
      _parts.forEach((ch, i) => {{
        if (!ch.userData._origPos) {{
          ch.userData._origPos = ch.position.clone();
          const dir = ch.position.clone();
          if (dir.length() < 0.001) dir.set(Math.cos(i * 0.7), 0.5, Math.sin(i * 0.7));
          dir.normalize();
          // Near-vertical parts (blades, spires, masts) would fly straight up
          // and out of frame — flatten the direction so they spread sideways
          // where the camera can see them, with only a gentle lift.
          if (Math.abs(dir.y) > 0.8) {{
            const ang = i * 1.7;
            dir.set(Math.cos(ang), 0.25, Math.sin(ang)).normalize();
          }}
          ch.userData._awayPos = ch.userData._origPos.clone().add(dir.multiplyScalar(24 + (i % 5) * 8));
        }}
        ch.userData._explodeTo = (exploded ? ch.userData._awayPos : ch.userData._origPos).clone();
        if (!exploded) {{
          const el = _labels.get(ch);
          if (el) el.style.display = 'none';
        }}
      }});
      document.getElementById('controls-hint').innerHTML = exploded
        ? '[CTRL+A] REASSEMBLE &nbsp;|&nbsp; [DRAG A PART] Move it — parts are named'
        : '[LEFT MOUSE]: Orbit &nbsp;|&nbsp; [SCROLL]: Zoom &nbsp;|&nbsp; [RIGHT MOUSE]: Pan';
      if (!explodeAnim) startExplodeAnim();
    }}
    function startExplodeAnim() {{
      (function step() {{
        let moving = false;
        hologramGroup.children.forEach(ch => {{
          const tgt = ch.userData._explodeTo;
          if (tgt) {{
            ch.position.lerp(tgt, 0.12);
            if (ch.position.distanceTo(tgt) > 0.05) moving = true;
            else {{ ch.position.copy(tgt); ch.userData._explodeTo = null; }}
          }}
        }});
        explodeAnim = moving ? requestAnimationFrame(step) : null;
      }})();
    }}

    // drag a disassembled part with the mouse
    const _ray = new THREE.Raycaster();
    const _ptr = new THREE.Vector2();
    let _dragPart = null;
    const _dragPlane = new THREE.Plane();
    const _dragOff = new THREE.Vector3();
    renderer.domElement.addEventListener('pointerdown', ev => {{
      if (!exploded || ev.button !== 0) return;
      _ptr.set(ev.clientX / innerWidth * 2 - 1, -(ev.clientY / innerHeight) * 2 + 1);
      _ray.setFromCamera(_ptr, camera);
      const hits = _ray.intersectObjects(hologramGroup.children, true);
      if (hits.length) {{
        let obj = hits[0].object;
        while (obj.parent && obj.parent !== hologramGroup) obj = obj.parent;
        if (!_parts.includes(obj)) return;   // only real parts are grabbable
        _dragPart = obj;
        _dragPlane.setFromNormalAndCoplanarPoint(
          camera.getWorldDirection(new THREE.Vector3()),
          obj.getWorldPosition(new THREE.Vector3()));
        controls.enabled = false;
        const hit = _ray.ray.intersectPlane(_dragPlane, new THREE.Vector3());
        if (hit) _dragOff.copy(obj.position).sub(hologramGroup.worldToLocal(hit.clone()));
      }}
    }});
    addEventListener('pointermove', ev => {{
      if (!_dragPart) return;
      _ptr.set(ev.clientX / innerWidth * 2 - 1, -(ev.clientY / innerHeight) * 2 + 1);
      _ray.setFromCamera(_ptr, camera);
      const hit = _ray.ray.intersectPlane(_dragPlane, new THREE.Vector3());
      if (hit) {{
        const local = hologramGroup.worldToLocal(hit.clone());
        _dragPart.position.copy(local.add(_dragOff));
        _dragPart.userData._explodeTo = null;   // it stays where dropped
      }}
    }});
    addEventListener('pointerup', () => {{ if (_dragPart) {{ _dragPart = null; controls.enabled = true; }} }});
    addEventListener('keydown', ev => {{
      if ((ev.ctrlKey || ev.metaKey) && (ev.key === 'a' || ev.key === 'A')) {{ ev.preventDefault(); teardown(); }}
    }});

    // Auto-frame now that geometry exists: tall builds (sabers, towers) get
    // a wider view instead of poking out of frame.
    (function frameObject() {{
      try {{
        const box = new THREE.Box3().setFromObject(hologramGroup);
        if (!box.isEmpty()) {{
          const h = box.max.y - box.min.y, r = Math.max(box.max.x - box.min.x, box.max.z - box.min.z);
          const need = Math.max(h * 1.15, r * 1.6, 60);
          if (need > 90) {{
            const s = need / 90;
            camera.position.set(60 * s, 40 * s + h * 0.1, 80 * s);
          }}
        }}
      }} catch (e) {{}}
    }})();

    // The render loop reads teardown state (exploded/_labels), so it may only
    // start once every declaration above exists — starting it earlier threw
    // a TDZ ReferenceError every frame and froze the whole viewer.
    fitStage();   // size the canvas synchronously — the first frames otherwise
                  // render into a stale framebuffer and spam GL warnings
    animate();

    window.addEventListener('resize', fitStage);
    if (window.ResizeObserver) new ResizeObserver(fitStage).observe(document.documentElement);
    document.addEventListener('visibilitychange', () => {{ if (!document.hidden) fitStage(); }});
    [120, 500, 1500].forEach(ms => setTimeout(fitStage, ms));   // late-layout catch
  </script>
</body>
</html>"""

    out_file.write_text(html, encoding="utf-8")
    return out_file


def run(parameters: dict, player=None, session_memory=None) -> str:
    """Execute Universal Hologram & 3D CAD Generation with Internet Capabilities."""
    parameters = parameters or {}
    prompt = str(parameters.get("prompt", "")).strip()
    fmt = str(parameters.get("format", "all")).strip().lower()
    color_theme = str(parameters.get("color", "")).strip().lower()
    url_param = str(parameters.get("url", "")).strip()

    if not prompt:
        return "Sir, please tell me what holographic image or 3D CAD model you would like me to synthesize."

    def log(msg: str):
        print(f"[HoloCAD] {msg}")
        if player:
            try:
                player.write_log(f"JARVIS: {msg}")
            except Exception:
                pass

    # Enhanced: Check for URL in prompt or parameter
    target_url = url_param or _extract_url_from_prompt(prompt)
    enhanced_prompt = prompt
    
    if target_url:
        log(f"Detected URL: {target_url}")
        log("Downloading image for holographic analysis...")
        image_data = _download_image_from_url(target_url)
        
        if image_data:
            log("Analyzing image with vision AI for holographic synthesis...")
            image_description = _analyze_image_for_hologram(image_data)
            enhanced_prompt = f"{prompt} (Based on image analysis: {image_description})"
            log(f"Enhanced prompt: {enhanced_prompt}")
        else:
            log("Image download failed, proceeding with text-based synthesis")
    else:
        # Check if prompt sounds like it needs internet reference
        if any(word in prompt.lower() for word in ["latest", "new", "current", "2024", "2025", "2026", "modern", "real"]):
            log("Searching internet for reference information...")
            search_context = _search_internet_for_reference(prompt)
            enhanced_prompt = f"{prompt} ({search_context})"
            log(f"Enhanced with internet context")

    slug = _slugify(enhanced_prompt)
    stl_path = CAD_DIR / f"{slug}.stl"
    svg_path = HOLO_DIR / f"{slug}_blueprint.svg"

    # Resolve theme color
    color_map = {
        "cyan": "#00d4ff",
        "crimson": "#ff2233",
        "neon": "#00ffcc",
        "gold": "#ffcc00",
        "emerald": "#00ff66",
        "violet": "#aa00ff",
    }
    color_hex = color_map.get(color_theme)
    if not color_hex:
        try:
            from memory.config_manager import load_api_keys
            color_hex = load_api_keys().get("ui_color", "#00d4ff") or "#00d4ff"
        except Exception:
            color_hex = "#00d4ff"

    log(f"Synthesizing realistic volumetric holographic projection for: '{enhanced_prompt}'...")
    log("Applying advanced holographic physics: volumetric depth, particle systems, additive blending, and atmospheric effects")

    # 1. Synthesize 3D Dynamic Three.js Geometry for ANY object (with enhanced prompt)
    threejs_code = _synthesize_threejs_geometry(enhanced_prompt, color_hex)

    # 2. Synthesize High-Resolution Vector Holographic Blueprint Graphic
    svg_content = _synthesize_hologram_svg(enhanced_prompt, color_hex)
    svg_path.write_text(svg_content, encoding="utf-8")
    log(f"Generated Vector Holographic Blueprint -> {svg_path.name}")

    # 3. Generate 3D Printable STL Mesh
    triangles = _generate_parametric_stl_triangles(enhanced_prompt)
    _write_stl_triangles(stl_path, triangles)
    log(f"Generated 3D STL Mesh ({len(triangles):,} facets) -> {stl_path.name}")

    # 4. Generate Interactive 3D Hologram HUD Viewer
    start_style = str(parameters.get("style", "hologram")).strip().lower()
    if start_style not in ("hologram", "solid", "blueprint"):
        start_style = "hologram"
    viewer_path = _generate_interactive_hologram_viewer(
        slug=slug,
        prompt=enhanced_prompt,
        threejs_logic=threejs_code,
        svg_content=svg_content,
        color_hex=color_hex,
        fallback_js=_procedural_fallback_js(enhanced_prompt),
        initial_style=start_style,
        hazards=parameters.get("hazards"),
    )
    log(f"Assembled Interactive Holographic Projection -> {viewer_path.name}")

    # 5. Launch Holographic Projection in Browser
    try:
        try:
            from core.opera import open_path
            open_path(viewer_path)
        except Exception:
            webbrowser.open(f"file:///{viewer_path.as_posix()}")
    except Exception as e:
        log(f"Hologram projection launch note: {e}")

    # 6. Display Telemetry Card in HUD Panel
    spec_card = f"""══════════════════════════════════════════════════════════════
          UNIVERSAL HOLOGRAPHIC PROJECTION & CAD SYSTEM
══════════════════════════════════════════════════════════════
• OBJECT:          {enhanced_prompt.upper()}
• RENDER TYPE:     Volumetric 3D Wireframe + 2D Vector Blueprint
• MESH DENSITY:    {len(triangles):,} Facets (Standard Binary STL)
• HOLOGRAPHIC HUD: Projected Live via Interactive WebGL
• COLOR THEME:     {color_hex}

OUTPUT FILES:
1. Holographic Viewer: {viewer_path.as_posix()}
2. 2D Vector Blueprint: {svg_path.as_posix()}
3. 3D Printable Mesh:  {stl_path.as_posix()}

STATUS: 3D Holographic projection is active on your display.
══════════════════════════════════════════════════════════════"""

    if player and hasattr(player, "show_content"):
        try:
            player.show_content(f"HOLOGRAPHIC PROJECTION — {slug.upper()}", spec_card)
        except Exception:
            pass

    return (
        f"Sir, I have synthesized the holographic projection and 3D schematics for {prompt}. "
        f"The volumetric 3D wireframe hologram and vector blueprint are now live on your display, "
        f"and the manufacturing mesh file is ready for 3D printing or fabrication."
    )
