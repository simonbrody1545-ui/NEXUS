"""
main_bridge — the session-level wiring between main.py's JarvisLive core and
everything this build added on top of the original Mark-LV base:

  * REMOTE: the phone link (graph-server QR dialog + LAN URL direct-entry)
  * mute:   'mute yourself' / 'unmute' handled locally, plus ev_core commands
  * phone:  transcript mirroring onto the :5000 feed
  * brain:  A.G.I. brain directive injection + activity pulses to The Inside
  * talk:   The Inside / phone talk queue poller feeding _on_text_command

boot_hooks(jarvis) is called once from JarvisLive.__init__ (via the _MAIN_BRIDGE
anchor in main.py). It wraps the existing methods instead of editing them, so
upstream base changes stay intact.
"""
from __future__ import annotations

import json
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
SERVER_URL = "http://127.0.0.1:5000"

_win_flags: dict = {}
if sys.platform == "win32":
    _win_flags = {"creationflags": 0x08000000}   # CREATE_NO_WINDOW


# ── phone transcript mirror ──────────────────────────────────────────────────
def _post_json(url: str, obj: dict) -> None:
    try:
        req = urllib.request.Request(
            url, data=json.dumps(obj).encode("utf-8"),
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=2)
    except Exception:
        pass


def phone_feed(role: str, text: str) -> None:
    """Fire-and-forget mirror of a transcript line onto the phone feed."""
    text = str(text or "").strip()
    if text:
        threading.Thread(
            target=_post_json, args=(SERVER_URL + "/api/transcript",
                                     {"role": role, "text": text}),
            daemon=True, name="phone-feed").start()


def brain_feed(kind: str, text: str) -> None:
    """Fire-and-forget brain-activity pulse for The Inside's hologram."""
    text = str(text or "").strip()
    if text:
        threading.Thread(
            target=_post_json, args=(SERVER_URL + "/api/brain/activity",
                                     {"kind": kind, "text": text}),
            daemon=True, name="brain-feed").start()


# ── A.G.I. brain directive ───────────────────────────────────────────────────
def brain_directive() -> str:
    """What his brain holds, for injection into the system instruction."""
    try:
        from core.agi_brain import context_lines
        txt = context_lines()
    except Exception:
        return ""
    if txt:
        brain_feed("recall", "mind awake — memories online")
        return txt
    return ""


# ── local commands (mute + E.V.) ────────────────────────────────────────────
_MUTE_DOWN = ("mute", "mute yourself", "mute your voice", "shut up",
              "stop talking", "silence", "be quiet", "go quiet",
              "mute yourself now", "be silent")
_MUTE_UP = ("unmute", "you can talk", "start talking", "speak again",
            "talk to me", "come back on", "un-mute", "unmute yourself")


def _clean(text: str) -> str:
    t = " ".join(str(text or "").lower().split())
    t = t.strip(".,!?")
    wake = "jarvis"
    for pre in (f"hey {wake}", f"ok {wake}", wake):
        if t.startswith(pre + " "):
            t = t[len(pre) + 1:]
        elif t == pre:
            t = ""
    return t.strip(".,!?")


def _handle_mute(jarvis, text: str) -> bool:
    """True when consumed as a mute/unmute command (never reaches the model).

    In THIS build 'muted' is the master word: it mutes him AND locks the HUD
    (the lock screen, not the computer). 'Mute' alone is a voice off-switch.
    """
    t = _clean(text)
    lock_too = False
    muting = (t in _MUTE_DOWN or t == "mute" or t.startswith("mute ")
              or t == "muted" or t == "red button" or t == "lock down")
    if t in ("muted", "lock down"):
        lock_too = True
    unmuting = any(t == c or t.startswith(c + " ") for c in _MUTE_UP) \
        or t.startswith("unmute ")
    if not (muting or unmuting):
        return False
    try:
        jarvis.ui.set_muted_ui(muting)
    except Exception:
        jarvis.ui.muted = muting
    jarvis.ui.write_log("SYS: JARVIS muted — he hears you, never speaks."
                        " HUD locked." if lock_too and muting else
                        "SYS: JARVIS muted — he hears you, never speaks."
                        if muting else
                        "SYS: JARVIS unmuted — voice restored.")
    if lock_too and muting:
        try:
            jarvis.ui.lock_now()
        except Exception:
            pass
    if unmuting and not jarvis.ui.muted:
        try:
            if time.time() - getattr(jarvis, "_last_mute_reply", 0) > 5:
                jarvis._last_mute_reply = time.time()
                jarvis.speak("Unmuted, sir — listening again.")
        except Exception:
            pass
    return True


def _handle_ev(jarvis, text: str) -> bool:
    """E.V. core commands (spread ur roots → Done, sir; add-to-roots…)."""
    try:
        from core import ev_core
        ev_core.set_speaker(jarvis.speak)
        return bool(ev_core.parse_command(text))
    except Exception:
        return False


def boot_hooks(jarvis) -> None:
    """Call once from JarvisLive.__init__ (via the _MAIN_BRIDGE anchor).

    Wraps rather than rewrites the base methods, so the untouched upstream
    core keeps its behaviour:
      * REMOTE button → the QR phone-remote dialog (no fastapi needed)
      * The Inside + phone talk queue → polled into the typed-command path
      * every typed/voice line → mirrored to the phone feed, then local
        mute / E.V. handling first, model second
    """
    jarvis._last_mute_reply = 0.0

    # REMOTE — QR remote replaces the fastapi-dashboard dialog entirely.
    jarvis.ui.on_remote_clicked = lambda: remote_dialog(jarvis)

    # The Inside / phone talk poller — drains the :5000 queue into the
    # same pipeline as typed input ("spread ur roots" from the browser, etc.)
    threading.Thread(target=_talk_poller, args=(jarvis,), daemon=True,
                     name="ev-talk-poller").start()

    # Wrap the typed-command path: phone mirror + local handlers first.
    _inner_text = jarvis._on_text_command

    def on_text(text: str) -> None:
        phone_feed("user", str(text))
        try:
            if _handle_ev(jarvis, text):
                return
        except Exception:
            pass
        try:
            if _handle_mute(jarvis, text):
                return
        except Exception:
            pass
        _inner_text(text)

    jarvis._on_text_command = on_text
    jarvis.ui.on_text_command = on_text


def _talk_poller(jarvis) -> None:
    """Drain The Inside / phone talk queue into the assistant. Never raises;
    idles politely while the grid server is down."""
    while True:
        items = []
        try:
            with urllib.request.urlopen(SERVER_URL + "/api/talk/poll",
                                        timeout=4) as r:
                items = json.loads(r.read()).get("items", [])
        except Exception:
            items = []
        for it in items:
            text = (it or {}).get("text", "").strip()
            if not text:
                continue
            try:
                jarvis.ui.write_log(f"INSIDE: {text}")
            except Exception:
                pass
            try:
                jarvis._on_text_command(text)
            except Exception:
                pass
        time.sleep(1.5)


def remote_dialog(jarvis) -> None:
    """REMOTE — the phone link. Ensures the grid server is up, builds the LAN
    address and shows a scannable QR. The phone page talks through the same
    bridge as The Inside (/api/talk → _talk_poller → session)."""
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QImage, QPixmap
    from PyQt6.QtWidgets import QDialog, QLabel, QVBoxLayout

    ui = jarvis.ui
    base = SERVER_URL

    def _up() -> bool:
        try:
            with urllib.request.urlopen(base + "/api/status", timeout=2) as r:
                return r.status == 200
        except Exception:
            return False

    if not _up():
        ui.write_log("SYS: Grid server down — starting it for the remote link…")
        try:
            kw = {"cwd": str(BASE_DIR),
                  "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
            if _win_flags:
                kw.update(_win_flags)
            subprocess.Popen([sys.executable, "dashboard/graph_server.py"], **kw)
        except Exception as e:
            ui.write_log(f"ERR: grid server start — {e}")
        for _ in range(20):
            if _up():
                break
            time.sleep(0.3)

    # LAN address — the iPhone dial
    ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass
    url = f"http://{ip}:5000/phone"

    # QR — pure matrix, painted as an image (no PIL needed)
    pm = None
    try:
        import qrcode
        q = qrcode.QRCode(border=2, box_size=8)
        q.add_data(url)
        q.make(fit=True)
        mx = q.get_matrix()
        n = len(mx)
        img = QImage(n, n, QImage.Format.Format_Grayscale8)
        for yy in range(n):
            for xx in range(n):
                img.setPixel(xx, yy, 0 if mx[yy][xx] else 255)
        pm = QPixmap.fromImage(img.scaled(
            300, 300, Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.FastTransformation))
    except Exception:
        pm = None

    from ui import C
    dlg = QDialog(ui)
    dlg.setWindowTitle("REMOTE LINK")
    dlg.setStyleSheet(f"background-color: {C.BG};")
    v = QVBoxLayout(dlg)
    v.setContentsMargins(18, 18, 18, 18)
    v.setSpacing(10)

    title = QLabel("PHONE REMOTE — SCAN TO CONNECT")
    title.setStyleSheet(f"color: {C.BORDER_B}; font-family: 'Consolas',monospace;"
                        " font-size: 13px; letter-spacing: 2px;")
    title.setAlignment(Qt.AlignmentFlag.AlignHCenter)
    v.addWidget(title)

    if pm is not None:
        qr_lbl = QLabel()
        qr_lbl.setPixmap(pm)
        qr_lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        v.addWidget(qr_lbl)
    else:
        miss = QLabel("(qrcode module missing — type the address manually)")
        miss.setStyleSheet(f"color: {C.ACC}; font-family: 'Consolas',monospace;")
        v.addWidget(miss)

    url_lbl = QLabel(url)
    url_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    url_lbl.setStyleSheet(
        f"color: {C.WHITE}; font-family: 'Consolas',monospace; font-size: 16px;"
        f" font-weight: bold; background: {C.PANEL2}; border: 1px solid"
        f" {C.BORDER}; padding: 10px;")
    url_lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
    v.addWidget(url_lbl)

    hint = QLabel("Scan with your phone camera, or type the address in its browser.\n"
                  "Phone and PC must share the same Wi-Fi.\n"
                  "You can then talk to J.A.R.V.I.S. — he answers out loud here "
                  "and replies stream on the phone.")
    hint.setStyleSheet(f"color: {C.TEXT_DIM}; font-family: 'Consolas',monospace;"
                       " font-size: 10.5px;")
    v.addWidget(hint)

    if _up():
        ui.write_log(f"SYS: Remote link ready — {url}")
    else:
        ui.write_log("SYS: Remote page will answer once the grid server is up.")
    dlg.exec()
