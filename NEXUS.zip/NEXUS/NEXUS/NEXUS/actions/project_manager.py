"""Project manager — JARVIS keeps its own project folders and the files in them.

"Make a project called web fluid" creates  projects/<date>-<slug>/  with a
notes.md stub. "Save this in the web fluid project" writes a file into that
project folder. Every write is recorded in the project's manifest.json so
"what's in my web fluid project" lists it back with sizes and dates.

Deliberately its own root (BASE/projects) rather than loose on the Desktop —
the desktop tools already handle loose files; this is JARVIS's filing cabinet.
"""
from __future__ import annotations

import json
import re
import subprocess
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ROOT     = BASE_DIR / "projects"

_TOOL = "project_manager"


def _safe_slug(name: str) -> str:
    s = re.sub(r"[^\w\s-]", "", (name or "").strip().lower())
    s = re.sub(r"[\s_]+", "-", s).strip("-")
    return s or "project"


def _find(name: str) -> Path | None:
    """Match a project by prefix, so 'web fluid' finds '2026-09-21-web-fluid'."""
    if not ROOT.exists():
        return None
    slug = _safe_slug(name)
    if not slug or slug == "project":
        return None
    cands = sorted(p for p in ROOT.iterdir()
                   if p.is_dir() and slug in p.name.lower())
    return cands[-1] if cands else None


def _manifest(pdir: Path) -> dict:
    try:
        return json.loads((pdir / "manifest.json").read_text(encoding="utf-8"))
    except Exception:
        return {"name": pdir.name, "created": "", "files": []}


def _save_manifest(pdir: Path, m: dict) -> None:
    try:
        (pdir / "manifest.json").write_text(
            json.dumps(m, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def _log(player, line: str) -> None:
    try:
        if player is not None:
            player.write_log(f"[{_TOOL}] {line}")
    except Exception:
        pass


def _open_in_explorer(pdir: Path) -> None:
    try:
        subprocess.Popen(["explorer", str(pdir)])
    except Exception:
        pass


# ── operations ───────────────────────────────────────────────────────────────

def create_project(name: str, player=None) -> str:
    name = (name or "").strip()
    if not name:
        return "What should the project be called, sir?"
    ROOT.mkdir(parents=True, exist_ok=True)
    slug = _safe_slug(name)
    stamp = datetime.now().strftime("%Y-%m-%d")
    pdir  = ROOT / f"{stamp}-{slug}"
    n = 2
    while pdir.exists():                    # same-day duplicates get -2, -3…
        pdir = ROOT / f"{stamp}-{slug}-{n}"
        n += 1
    pdir.mkdir(parents=True)
    (pdir / "notes.md").write_text(
        f"# {name}\n\nCreated {datetime.now():%Y-%m-%d %H:%M} by JARVIS.\n",
        encoding="utf-8")
    _save_manifest(pdir, {"name": name, "created": pdir.name, "files": []})
    _log(player, f"project created: {pdir.name}")
    return (f"Project '{name}' created at {pdir} — with notes.md inside. "
            f"Say 'save this in the {slug} project' to file things into it.")


def save_file(name: str, filename: str, content: str, player=None) -> str:
    """Write a file into a project (creating it on the spot if needed)."""
    name = (name or "").strip()
    filename = (filename or "").strip()
    if not name or not filename:
        return "I need both a project name and a filename, sir."
    pdir = _find(name)
    if pdir is None:
        create_project(name, player)
        pdir = _find(name)
        if pdir is None:
            return "I couldn't create the project folder."
    if "/" in filename or "\\" in filename or ".." in filename:
        return "Filenames go flat inside the project folder — no paths, sir."
    target = pdir / filename
    try:
        target.write_text(content or "", encoding="utf-8")
    except Exception as e:
        return f"Couldn't write {filename}: {e}"
    m = _manifest(pdir)
    files = [f for f in m.get("files", []) if f.get("file") != filename]
    files.append({"file": filename,
                  "bytes": target.stat().st_size,
                  "at":   datetime.now().isoformat(timespec="seconds")})
    m["files"] = files
    _save_manifest(pdir, m)
    _log(player, f"saved {filename} → {pdir.name}")
    return f"Saved {filename} ({target.stat().st_size} bytes) in project '{pdir.name}'."


def list_projects() -> str:
    if not ROOT.exists():
        return "No projects yet — say 'make a project called …'."
    dirs = sorted(p for p in ROOT.iterdir() if p.is_dir())
    if not dirs:
        return "No projects yet — say 'make a project called …'."
    lines = []
    for p in dirs[-12:]:
        m = _manifest(p)
        nfiles = len(m.get("files", []))
        lines.append(f"📁 {p.name}  ({nfiles} file(s))")
    return f"{len(dirs)} project(s):\n" + "\n".join(lines)


def project_contents(name: str) -> str:
    pdir = _find(name)
    if pdir is None:
        return f"No project matching '{name}'."
    try:
        entries = sorted(pdir.iterdir(), key=lambda x: x.stat().st_mtime)
    except Exception as e:
        return f"Couldn't read the project: {e}"
    lines = [f"Project {pdir.name}:"]
    for f in entries:
        if f.is_file():
            lines.append(f"  📄 {f.name} ({f.stat().st_size} B)")
        else:
            lines.append(f"  📁 {f.name}/")
    return "\n".join(lines)


def open_project(name: str) -> str:
    pdir = _find(name)
    if pdir is None:
        return f"No project matching '{name}'."
    _open_in_explorer(pdir)
    return f"Opened {pdir} in Explorer."


# ── tool entry point (auto-discovered) ───────────────────────────────────────

def run(parameters: dict = None, response=None, player=None, **_) -> str:
    params = parameters or {}
    action = (params.get("action") or "").lower().strip()
    name   = (params.get("project") or params.get("name") or "").strip()
    if not action:
        if params.get("content") or params.get("filename"):
            action = "save"
        elif name:
            action = "contents"
        else:
            action = "list"
    try:
        if action == "create":
            return create_project(name, player)
        if action == "save":
            return save_file(name, params.get("filename", ""),
                             params.get("content", ""), player)
        if action == "list":
            return list_projects()
        if action == "contents":
            return project_contents(name) if name else list_projects()
        if action == "open":
            return open_project(name) if name else open_project(str(ROOT))
        return f"Unknown project action '{action}'."
    except Exception as e:
        return f"Project manager error: {e}"


TOOL = {
    "name": "project_manager",
    "description": (
        "JARVIS's own project folders: create a project ('make a project called "
        "web fluid'), save files into it ('save the formula in the web fluid "
        "project'), list projects, show a project's contents, or open it in "
        "Explorer. Projects live under the app's projects/ folder with a "
        "manifest recording every file."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action":   {"type": "STRING",
                         "description": "create | save | list | contents | open"},
            "project":  {"type": "STRING",
                         "description": "Project name (matched by prefix)"},
            "filename": {"type": "STRING",
                         "description": "File name for save (flat, e.g. formula.md)"},
            "content":  {"type": "STRING",
                         "description": "Text content for save"},
        },
        "required": [],
    },
    "handler": run,
}
