"""Speed test — a real measurement, not a widget.

Downloads a known test payload from a fast public CDN for a bounded time and
counts the bytes that actually crossed the interface (psutil net counters, so
nothing is double-counted by cache or compression), then reports Mbps. Upload
is not tested — most free endpoints take POSTs badly and a fake number is
worse than half an honest one; the report says download only.
"""
from __future__ import annotations

import time

import psutil

# Multiple endpoints: the first that answers serves the test.
_URLS = (
    "https://speed.cloudflare.com/__down?bytes=104857600",   # 100 MB
    "https://proof.ovh.net/files/100Mb.dat",
    "http://speedtest.tele2.net/100MB.zip",
)


def run(parameters: dict, **_ctx) -> str:
    secs = min(12.0, max(4.0, float(parameters.get("seconds", 8))))
    import urllib.request
    for url in _URLS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "JARVIS/1.0"})
            n0 = psutil.net_io_counters()
            t0 = time.monotonic()
            got = 0
            with urllib.request.urlopen(req, timeout=10) as r:
                while True:
                    if time.monotonic() - t0 > secs:
                        break
                    chunk = r.read(262144)
                    if not chunk:
                        break
                    got += len(chunk)
            dt = time.monotonic() - t0
            n1 = psutil.net_io_counters()
            # Interface bytes over the same window — the honest cross-check.
            iface = (n1.bytes_recv - n0.bytes_recv) / max(dt, 0.2)
            mbps_file = got * 8 / dt / 1e6
            mbps_all = iface * 8 / 1e6
            use = mbps_file if got > 2_000_000 else mbps_all
            if got > 0:
                return (f"Download measured at {use:.0f} Mbps "
                        f"({got / 1e6:.0f} MB in {dt:.1f}s)")
        except Exception:
            continue
    return ("Speed test failed — every test endpoint refused. The network "
            "may be down or heavily filtered, sir.")


TOOL = {
    "name": "speed_test",
    "description": (
        "Real internet download speed test (measured, ~8 s). Use when the "
        "user asks about internet speed, connection quality, or why the "
        "network is slow."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "seconds": {"type": "INTEGER",
                        "description": "Test duration 4-12 s (default 8)."},
        },
        "required": [],
    },
    "handler": run,
}
