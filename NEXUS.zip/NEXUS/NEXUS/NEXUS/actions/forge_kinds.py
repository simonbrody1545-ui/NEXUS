"""
forge_kinds — what the Forge can build, and how.

Every kind carries: display label, default extension, the per-kind prompt
contract for the AI builders, an offline starter (when every provider is
down), and how the artifact launches.
"""
from __future__ import annotations

import re

# detection keywords → kind (first match wins; checked in order)
_DETECT: list[tuple[str, tuple[str, ...]]] = [
    ("game",       ("game", "pygame", "arcade", "shooter", "platformer", "puzzle game")),
    ("bot",        ("bot", "discord", "telegram", "chatbot", "auto-reply")),
    ("api",        ("api", "server", "backend", "endpoint", "rest", "flask", "fastapi")),
    ("app",        ("desktop app", "window app", "tkinter", "gui app", "pygame app",
                    "launcher", "desktop program", "app with a window", "an app")),
    ("automation", ("automation", "auto-", "monitor my", "watch my", "rename",
                    "organize", "clean up", "bulk", "batch", "schedule")),
    ("data",       ("data", "analyz", "csv", "excel", "chart", "graph", "statistics",
                    "dashboard of", "report on")),
    ("doc",        ("document", "essay", "article", "letter", "resume", "cv",
                    "report about", "write me a", "blog post")),
    ("script",     ("script", "cli", "command line", "tool that", "util")),
]

KINDS: dict[str, dict] = {
    "website": {
        "label": "website", "ext": ".html", "single": True,
        "prompt": ("a complete, modern, production-quality single-file website. "
                   "Full HTML5 + CSS3 + vanilla JS, striking responsive design, "
                   "smooth animations, real content (no lorem ipsum), semantic "
                   "markup, works offline. No external CDNs."),
    },
    "game": {
        "label": "HTML5 game", "ext": ".html", "single": True,
        "prompt": ("a complete, genuinely playable single-file HTML5 game. "
                   "Canvas rendering, full game loop, keyboard+touch controls, "
                   "score/lives/levels as appropriate, start & game-over screens, "
                   "juicy feedback (particles, sounds via WebAudio), polished "
                   "visual identity. It must be fun in the first five seconds."),
    },
    "app": {
        "label": "desktop app", "ext": ".py", "single": False,
        "prompt": ("a polished Python desktop app using only the standard "
                   "library (tkinter/ttk). Real, working functionality — every "
                   "button does what it says. Clean layout, sensible defaults, "
                   "keyboard shortcuts, status bar, and error handling. "
                   "Single file, runs with plain `python <file>`."),
        "run": "python",
    },
    "script": {
        "label": "CLI tool", "ext": ".py", "single": False,
        "prompt": ("a robust, complete Python CLI tool using only the standard "
                   "library. argparse interface with --help, correct error "
                   "handling, dry-run safety for destructive ops, clean output. "
                   "Single file."),
        "run": "python",
    },
    "bot": {
        "label": "bot", "ext": ".py", "single": False,
        "prompt": ("a well-structured Python bot skeleton (discord.py or "
                   "telebot style per the request) with config via constants at "
                   "the top, slash-style command handlers, logging, graceful "
                   "errors, and a clear README block as a comment. The token "
                   "is read from an env var, never hard-coded."),
    },
    "api": {
        "label": "API server", "ext": ".py", "single": False,
        "prompt": ("a complete Python REST API server. Prefer the standard "
                   "library (http.server + json) so it runs with zero pip "
                   "installs, unless the request demands a framework. JSON "
                   "endpoints, CORS, clean routing, in-memory store, clear "
                   "comments, and a self-test when run with --selftest."),
        "run": "python",
    },
    "automation": {
        "label": "automation", "ext": ".py", "single": False,
        "prompt": ("a reliable Python automation using only the standard "
                   "library. Safe-by-default: preview/dry-run first, explicit "
                   "flag to execute, refuses to touch anything outside the "
                   "folder it is given, and prints a clear plan before acting."),
        "run": "python",
    },
    "data": {
        "label": "data analysis", "ext": ".py", "single": False,
        "prompt": ("a complete Python analysis using only the standard library "
                   "(csv, statistics, json). Reads the data file if one is "
                   "named, computes real summary statistics, and writes a "
                   "readable report to stdout plus a self-contained HTML chart "
                   "(inline SVG/CSS bars) next to the data."),
        "run": "python",
    },
    "doc": {
        "label": "document", "ext": ".md", "single": True,
        "prompt": ("a well-structured, genuinely useful document in clean "
                   "Markdown: strong title, tight sections, concrete examples, "
                   "no filler. Match the requested length and tone."),
    },
    "anything": {
        "label": "build", "ext": ".txt", "single": False,
        "prompt": ("exactly what the request asks for, built as completely as "
                   "possible. Choose the right language and file layout for the "
                   "job yourself."),
    },
}


def detect(request: str, explicit: str = "") -> str:
    """Pick the kind: explicit override first, then keyword scan, else website."""
    e = str(explicit or "").lower().strip()
    if e in KINDS:
        return e
    if e:
        if "game" in e:
            return "game"
        if "web" in e:
            return "website"
    text = " " + str(request or "").lower() + " "
    for kind, words in _DETECT:
        if any(re.search(rf"\b{re.escape(w)}", text) for w in words):
            return kind
    return "website"


def spec(kind: str) -> dict:
    return KINDS.get(kind, KINDS["website"])


def run_command(kind: str, path) -> list[str] | None:
    """How to launch a forged artifact (None = just open/serve it)."""
    sp = spec(kind)
    if sp.get("run") == "python" and str(path).endswith(".py"):
        import sys
        return [sys.executable, str(path)]
    return None


def offline_starter(kind: str, name: str, desc: str) -> str:
    """Last-resort build when every AI provider is unreachable."""
    sp = spec(kind)
    if sp["ext"] == ".html":
        body = (f"<h1>{name}</h1><p>{desc}</p>"
                "<p style='opacity:.7'>Forged offline — every AI provider was "
                "unreachable, so this is the built-in fallback template. Ask "
                "me to rebuild it when the network is back.</p>")
        return ("<!DOCTYPE html><html><head><meta charset='utf-8'>"
                f"<title>{name}</title><style>"
                "body{background:#03131c;color:#cfe8ef;font-family:Consolas,"
                "monospace;display:grid;place-items:center;height:100vh;margin:0}"
                "div{max-width:640px;border:1px solid #00d8ff55;border-radius:12px;"
                "padding:36px;box-shadow:0 0 40px #00d8ff22}</style></head>"
                f"<body><div>{body}</div></body></html>")
    if sp["ext"] == ".py":
        return (
            '"""\n' + f"{name}\n{desc}\n\nForged offline: the AI builders were "
            "unreachable, so this is a working stub with the plan inside.\n"
            '"""\n\ndef main() -> None:\n    print(f"[{name}] online.")\n'
            f'    print("Plan: {desc[:200]}")\n    print("Ask JARVIS to forge '
            'this again with the network up for the full build.")\n\n\n'
            'if __name__ == "__main__":\n    main()\n')
    return f"# {name}\n\n{desc}\n\n(Forged offline — rebuild with network up.)\n"
