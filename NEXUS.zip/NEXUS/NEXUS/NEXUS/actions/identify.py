"""
identify — JARVIS's identifier. "Scan this" / "what is this thing?" →
he points his eye (camera or screen), captures a frame, and the model answers
from what it actually sees through the same vision pipeline as screen_process.

Implementation: this tool returns an IDENTIFY directive that main.py's inline
screen_process executor understands (it sets the same _pending_vision bridge),
so the actual image + description happen in one exchange, no double answers.
"""
from __future__ import annotations


def identify(params: dict = None, **_ctx) -> str:
    p = params or {}
    angle = str(p.get("angle") or "camera").lower().strip()
    extra = str(p.get("question") or "").strip()
    mode = str(p.get("mode") or "identify").lower().strip()

    if angle not in ("camera", "screen"):
        angle = "camera"

    if mode in ("describe", "identify", ""):
        ask = ("Identify this for sir. State what the object most likely is, "
               "its purpose, and any text/markings you can read. One crisp "
               "spoken paragraph — no bullet lists.")
    elif mode == "read":
        ask = "Read out every piece of text you can see in this capture, exactly."
    elif mode == "price":
        ask = ("Identify this object, then estimate its typical market price "
               "range for sir. Say what you base the estimate on, briefly.")
    else:
        ask = extra or "What is this?"
    if extra:
        ask += f" Also: {extra}"

    return (f"[IDENTIFY_ACTIVE] angle={angle}::prompt={ask}::"
            "Capture in flight — the image arrives in this same exchange. "
            "Answer once, from what you see.")


TOOL = {
    "name": "identify_thing",
    "description": (
        "The identifier — point your eye at something and tell sir what it is. "
        "Use when he says 'scan this', 'what is this thing?', 'read that', "
        "'how much is this worth' or holds something at the camera. "
        "angle='camera' looks at what he is holding up; 'screen' reads the "
        "display instead. mode: identify (default) | read | price."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "angle":   {"type": "STRING",
                        "description": "camera (default) | screen"},
            "mode":    {"type": "STRING",
                        "description": "identify (default) | read | price"},
            "question": {"type": "STRING",
                         "description": "Optional extra question about the object"},
        },
        "required": [],
    },
    "handler": identify,
}
