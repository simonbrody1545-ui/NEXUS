"""Vision — JARVIS's eyes: camera presence + object recognition.

"look through the camera" / "open your eyes"     → eye starts (DroidCam first)
"close your eyes" / "stop the camera"            → eye stops
"what am I holding" / "scan the object"          → one snapshot → Gemini names it
"what do you see" / "observe"                    → scene description
"""
from __future__ import annotations

_TOOL = "vision"


def run(parameters: dict, **_ctx) -> str:
    from core import vision_eye
    action = (parameters.get("action") or "").strip().lower()

    if action in ("start", "open", "on"):
        ok, name = vision_eye.request_start()
        if ok:
            return (f"Eyes open, sir — watching through {name}. "
                    "Show the camera your hand.")
        return f"I cannot open my eyes: {vision_eye.status().get('err', 'no camera')}"

    if action in ("stop", "close", "off"):
        vision_eye.request_stop()
        return "Eyes closed."

    if action in ("scan", "identify", "holding", "what_am_i_holding"):
        vision_eye.request_start()          # idempotent
        import time
        for _ in range(20):                 # up to 2 s for a frame
            if vision_eye.frame_age() < 1.0:
                break
            time.sleep(0.1)
        ans = vision_eye.get_eye().identify()
        if ans:
            return ans
        return ("I see nothing worth naming yet, sir — the camera shows no "
                "clear object. Give it a moment and ask again.")

    if action in ("observe", "describe", "what_do_you_see"):
        vision_eye.request_start()
        ans = vision_eye.get_eye().identify()
        return ans or "The camera shows me nothing I can name just now."

    if action == "status":
        st = vision_eye.status()
        if st.get("running"):
            return (f"Eyes open on {st.get('src_name')} — "
                    f"{st.get('hands', 0)} hand(s) in view.")
        return "My eyes are closed."

    return "Unknown vision action."


TOOL = {
    "name": "vision",
    "description": (
        "JARVIS's camera eyes. 'open your eyes'/'look through the camera' "
        "starts tracking (camera presence rendered live in the HUD, DroidCam "
        "used as webcam when present); 'close your eyes' stops it. 'what am I "
        "holding'/'scan the object' names what the camera sees; 'what do you "
        "see' describes the scene. Status on demand."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING",
                       "description": "start | stop | scan | observe | status"},
        },
        "required": ["action"],
    },
    "handler": run,
}
