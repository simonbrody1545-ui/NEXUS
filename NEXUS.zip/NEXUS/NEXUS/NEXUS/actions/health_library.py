"""
Stark Medical Bay — Disease Index.

A browsable holographic catalog of diseases/conditions (real AND fictional).
JARVIS fills the catalog from its own knowledge; the tool renders it as a
searchable card grid. Every card carries an OPEN IN MEDICAL BAY button that
redirects to a fully generated diagnostic page (the animated health display
from actions/health_advisor.py): supplies list, remedies with side effects,
risks if untreated, see-a-doctor flags.

Generated files live in state/health/:
  library.html      — the index (stable name, always the latest generation)
  diag_<slug>.html  — one diagnostic per condition, so redirects are instant

The diagnostic pages link back to library.html, so the two form a loop.
"""
from __future__ import annotations

import html
import json
import re
import time
from pathlib import Path

import webbrowser

from actions.health_advisor import build_html as _diag_html, OUT_DIR

LIB_PATH = OUT_DIR / "library.html"


def _esc(s) -> str:
    return html.escape(str(s or ""), quote=True)


def _slug(name: str) -> str:
    s = "".join(c if c.isalnum() else "_" for c in str(name).lower())
    s = re.sub(r"_+", "_", s).strip("_")[:48].strip("_")
    return s or "condition"


_SEV_COL = {"mild": "#37ffb5", "moderate": "#ffd23d",
            "serious": "#ff3d5a", "fictional": "#ff5ad6"}

_CATS = ("common", "chronic", "mental", "fictional")


def _norm(items: list | None) -> list[dict]:
    """Accept dicts or bare strings; always return list of dicts."""
    out = []
    for it in (items or []):
        if isinstance(it, str):
            it = {"name": it}
        if isinstance(it, dict) and it.get("name"):
            d = dict(it)
            d.setdefault("category", "common")
            d.setdefault("severity", "moderate")
            out.append(d)
    return out


def generate(diseases: list[dict]) -> dict:
    """Write library.html + one diagnostic page per condition. Returns paths."""
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    entries = []
    for d in diseases:
        slug = _slug(d["name"])
        diag_rel = f"diag_{slug}.html"
        # the diagnostic template keys off `condition`, the catalog uses `name`
        payload = dict(d)
        payload["condition"] = d["name"]
        (OUT_DIR / diag_rel).write_text(
            _diag_html(payload), encoding="utf-8")
        entries.append({
            "name": str(d["name"]),
            "slug": slug,
            "category": str(d.get("category", "common")).lower(),
            "severity": str(d.get("severity", "moderate")).lower(),
            "summary": str(d.get("summary", "")),
            "body_part": str(d.get("body_part", "systemic")),
            "recovery": str(d.get("recovery_days", "—")),
            "remedies": len(d.get("remedies") or []),
            "tags": [str(t).lower() for t in (d.get("tags") or [])],
        })

    lib = (OUT_DIR / "library.html")
    lib.write_text(_template(entries), encoding="utf-8")
    return {"library": lib, "count": len(entries)}


def handler(diseases: list | None = None, intro: str = "", **_) -> str:
    try:
        items = _norm(diseases) or _norm(DEFAULT_CATALOG)
        res = generate(items)
        from core.opera import open_path
        open_path(res['library'])
        return (f"Disease Index is on screen — {res['count']} conditions "
                f"catalogued. Click any card to be redirected into the Stark "
                f"Medical Bay for its full cure plan.")
    except Exception as e:
        return f"Disease Index failed to open: {e}"


TOOL = {
    "name": "health_library",
    "description": (
        "Opens the STARK MEDICAL BAY DISEASE INDEX — a searchable holographic "
        "catalog of diseases and how to fix them, with one-click redirect into "
        "the full animated diagnostic for each. Use when the user says things "
        "like 'show me all diseases', 'open the disease library', 'what "
        "illnesses can you show', 'medical index'. Calling it with no arguments "
        "opens the built-in library of 70 curable conditions (infections, "
        "deficiencies, chronic, mental health, dental, eyes, substance harm, "
        "fictional). Or fill `diseases` with your own curated selection for a "
        "themed index. Fictional diseases from games/films are welcome — mark "
        "category and severity 'fictional'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "diseases": {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
                "name":            {"type": "STRING"},
                "category":        {"type": "STRING", "description": "common | chronic | mental | fictional"},
                "severity":        {"type": "STRING", "description": "mild | moderate | serious | fictional"},
                "summary":         {"type": "STRING", "description": "One line about the condition"},
                "body_part":       {"type": "STRING"},
                "recovery_days":   {"type": "STRING"},
                "supplies":        {"type": "ARRAY", "items": {"type": "STRING"}},
                "remedies":        {"type": "ARRAY", "items": {"type": "OBJECT", "properties": {
                                        "name": {"type": "STRING"},
                                        "type": {"type": "STRING"},
                                        "how":  {"type": "STRING"},
                                        "side_effects": {"type": "ARRAY", "items": {"type": "STRING"}}}}},
                "risks_if_untreated": {"type": "ARRAY", "items": {"type": "STRING"}},
                "see_doctor_if":   {"type": "ARRAY", "items": {"type": "STRING"}},
                "tags":            {"type": "ARRAY", "items": {"type": "STRING"},
                                    "description": "extra search words, e.g. ['contagious','winter']"},
            }}},
            "intro": {"type": "STRING", "description": "Optional line shown under the title"},
        },
    },
    "handler": handler,
}


# ── default starter catalog — used when JARVIS passes nothing ────────────────
DEFAULT_CATALOG = [
    {"name": "Common Cold", "category": "common", "severity": "mild",
     "summary": "Viral upper-respiratory infection; sneezing, blocked nose, sore throat.",
     "body_part": "nose & throat", "recovery_days": "3–7 days", "tags": ["contagious", "cough"],
     "supplies": ["Tissues", "Thermometer", "Honey", "Ginger", "Lemons"],
     "remedies": [
         {"name": "Rest + fluids", "type": "habit", "how": "Sleep 8+ h; drink warm liquids all day.", "side_effects": []},
         {"name": "Honey-ginger tea", "type": "home", "how": "3× daily; soothes throat.", "side_effects": ["Heartburn in excess"]},
         {"name": "Paracetamol", "type": "medicine", "how": "500–1000 mg every 6 h for aches.", "side_effects": ["Liver strain if overdosed"]}],
     "risks_if_untreated": ["Sinusitis", "Ear infection", "Bronchitis (rare)"],
     "see_doctor_if": ["Fever > 39 °C for 3 days", "Breathing difficulty"]},
    {"name": "Influenza (Flu)", "category": "common", "severity": "moderate",
     "summary": "Respiratory virus with fever, chills, body aches and exhaustion.",
     "body_part": "respiratory", "recovery_days": "1–2 weeks", "tags": ["contagious", "fever", "winter"],
     "supplies": ["Thermometer", "Fluids", "Blankets", "Oseltamivir (if prescribed)"],
     "remedies": [
         {"name": "Bed rest", "type": "habit", "how": "Stay home 5–7 days; avoid exertion.", "side_effects": []},
         {"name": "Antivirals", "type": "medicine", "how": "Oseltamivir 75 mg 2× day, best within 48 h.", "side_effects": ["Nausea", "Dizziness"]}],
     "risks_if_untreated": ["Pneumonia", "Myocarditis", "Hospitalisation in high-risk groups"],
     "see_doctor_if": ["Chest pain", "Confusion", "Fever returning after improvement"]},
    {"name": "Migraine", "category": "chronic", "severity": "moderate",
     "summary": "Neurovascular headache, often one-sided, with light/sound sensitivity.",
     "body_part": "head", "recovery_days": "4–72 hours", "tags": ["headache", "light sensitivity"],
     "supplies": ["Cold pack", "Dark quiet room", "Ibuprofen", "Water"],
     "remedies": [
         {"name": "Dark-room rest", "type": "habit", "how": "No screens; sleep if possible.", "side_effects": []},
         {"name": "Ibuprofen", "type": "medicine", "how": "200–400 mg with food at first sign.", "side_effects": ["Stomach upset", "Rebound headache if overused"]}],
     "risks_if_untreated": ["Chronic daily headache", "Status migrainosus"],
     "see_doctor_if": ["'Worst headache of life'", "Fever + stiff neck", "Weakness or vision loss"]},
    {"name": "Food Poisoning", "category": "common", "severity": "moderate",
     "summary": "Bacterial/viral illness from contaminated food — cramps, vomiting, diarrhoea.",
     "body_part": "stomach", "recovery_days": "1–3 days", "tags": ["nausea", "vomiting"],
     "supplies": ["Oral rehydration salts", "Water", "Bananas", "Rice"],
     "remedies": [
         {"name": "ORP rehydration", "type": "food", "how": "Small sips every 5 min; replaces salts.", "side_effects": []},
         {"name": "BRAT diet", "type": "food", "how": "Bananas, rice, applesauce, toast until settled.", "side_effects": []}],
     "risks_if_untreated": ["Severe dehydration", "Kidney injury", "Septicaemia (rare)"],
     "see_doctor_if": ["Blood in stool", "Fever > 38.5 °C", "No urine 8+ h"]},
    {"name": "Insomnia", "category": "mental", "severity": "mild",
     "summary": "Persistent trouble falling or staying asleep.",
     "body_part": "brain", "recovery_days": "2–6 weeks with routine", "tags": ["sleep"],
     "supplies": ["Blackout curtains", "No screens rule", "Melatonin (optional)"],
     "remedies": [
         {"name": "Sleep hygiene", "type": "habit", "how": "Fixed wake time; no caffeine after 14:00; dim lights 1 h before.", "side_effects": []},
         {"name": "Melatonin", "type": "medicine", "how": "1–3 mg, 30–60 min before bed, short-term.", "side_effects": ["Vivid dreams", "Grogginess"]}],
     "risks_if_untreated": ["Daytime cognitive impairment", "Anxiety/depression risk", "Accident risk"],
     "see_doctor_if": ["Sleepiness while driving", "3+ nights weekly for months"]},
    {"name": "Anxiety Episode", "category": "mental", "severity": "moderate",
     "summary": "Acute worry/fear with racing heart, tension, shallow breathing.",
     "body_part": "mind", "recovery_days": "minutes to hours per episode", "tags": ["stress", "panic"],
     "supplies": ["Quiet space", "Water"],
     "remedies": [
         {"name": "Box breathing", "type": "habit", "how": "In 4 s — hold 4 s — out 4 s — hold 4 s; repeat 10×.", "side_effects": ["Lightheaded if rushed"]},
         {"name": "Grounding 5-4-3-2-1", "type": "home", "how": "Name 5 things you see, 4 feel, 3 hear, 2 smell, 1 taste.", "side_effects": []}],
     "risks_if_untreated": ["Panic disorder", "Avoidance patterns", "High blood pressure"],
     "see_doctor_if": ["Chest pain", "Thoughts of self-harm"]},
    {"name": "Dehydration", "category": "common", "severity": "moderate",
     "summary": "Body losing more fluid than it takes in — dizziness, dark urine, fatigue.",
     "body_part": "systemic", "recovery_days": "hours", "tags": ["heat", "thirst"],
     "supplies": ["Water", "Oral rehydration salts", "Shade"],
     "remedies": [
         {"name": "Electrolyte drink", "type": "food", "how": "500 ml over 1–2 h, then steady sips.", "side_effects": []},
         {"name": "Cool rest", "type": "habit", "how": "Sit in shade/AC until urine runs pale.", "side_effects": []}],
     "risks_if_untreated": ["Heatstroke", "Kidney failure", "Seizures"],
     "see_doctor_if": ["No urine 8+ h", "Rapid weak pulse", "Fainting"]},
    {"name": "Lower Back Pain", "category": "chronic", "severity": "mild",
     "summary": "Mechanical strain of lumbar muscles/discs; most cases self-resolve.",
     "body_part": "lower back", "recovery_days": "1–2 weeks", "tags": ["posture", "lifting"],
     "supplies": ["Heat pack", "Firm chair", "Ibuprofen"],
     "remedies": [
         {"name": "Keep moving", "type": "habit", "how": "Gentle walks; avoid bed-rest beyond 2 days.", "side_effects": []},
         {"name": "Heat therapy", "type": "home", "how": "15–20 min, 3× daily on the ache.", "side_effects": ["Skin redness"]}],
     "risks_if_untreated": ["Chronic pain loop", "Muscle deconditioning"],
     "see_doctor_if": ["Leg numbness/weakness", "Bladder changes", "After a fall"]},
    # ── substance harm profiles: what vape / alcohol / hookah / cigarettes do ──
    {"name": "Vaping (E-cigarette Harm)", "category": "chronic", "severity": "moderate",
     "summary": "Harm from regular vaping: nicotine addiction plus airway and cardiovascular irritation. Extreme use doubles the load.",
     "body_part": "lungs", "recovery_days": "weeks-months after quitting", "tags": ["vape", "nicotine", "smoking", "e-cigarette"],
     "supplies": ["Nicotine-replacement patches or gum", "Water", "Peppermint or sugar-free gum", "A quit date"],
     "remedies": [
         {"name": "Nicotine taper", "type": "medicine", "how": "Patch + gum stepped down over 8-12 weeks; doubles quit success.", "side_effects": ["Patch: skin irritation", "Gum: hiccups, jaw ache", "Vivid dreams"]},
         {"name": "Airway recovery", "type": "habit", "how": "Cardio 30 min 3x/wk + 2L water daily; cilia regrow, cough clears in 2-6 weeks.", "side_effects": ["Temporary productive cough as lungs clean out"]},
         {"name": "Trigger swap", "type": "habit", "how": "Replace vape breaks with a walk or gum; identify the 3 strongest triggers.", "side_effects": ["Irritability in week 1-2"]}],
     "risks_if_untreated": ["EVALI lung injury (extreme use)", "Chronic bronchitis symptoms", "Nicotine addiction deepens", "Raised heart rate & blood pressure", "Gateway to cigarettes"],
     "see_doctor_if": ["Chest pain or persistent wheeze", "Coughing blood", "Breathlessness at rest"]},
    {"name": "Alcohol Overuse", "category": "chronic", "severity": "serious",
     "summary": "Harm pattern from heavy drinking. Extreme amounts (bingeing daily) attack the liver, brain, stomach and heart.",
     "body_part": "liver", "recovery_days": "months; liver fat can reverse in 2-6 weeks abstinent", "tags": ["alcohol", "drinking", "binge", "hangover"],
     "supplies": ["Electrolyte drinks", "B-vitamin complex + thiamine", "Water", "Medical supervision for withdrawal"],
     "remedies": [
         {"name": "Structured reduction", "type": "habit", "how": "Cut 10% per week or set 2 alcohol-free days; track units (under 14/wk).", "side_effects": ["Mild anxiety, insomnia first 2 weeks"]},
         {"name": "Thiamine + B vitamins", "type": "medicine", "how": "Daily B1 while drinking heavily — protects the brain; doctor guidance for dosage.", "side_effects": ["Rare allergic rash"]},
         {"name": "Rehydration protocol", "type": "food", "how": "After drinking: 500ml electrolytes before bed, 500ml on waking.", "side_effects": []}],
     "risks_if_untreated": ["Fatty liver → hepatitis → cirrhosis", "Stomach ulcers & gastritis", "Irregular heartbeat (AFib)", "Brain shrinkage, memory loss (extreme)", "Dependency & withdrawal seizures (dangerous)", "Cancer risk (mouth, throat, liver)"],
     "see_doctor_if": ["Shaking, sweating, hallucinations when sober — withdrawal is medical", "Yellow skin/eyes", "Vomiting blood", "Severe abdominal pain"]},
    {"name": "Hookah / Shisha Harm", "category": "chronic", "severity": "moderate",
     "summary": "One hookah session = ~200 puffs and often more smoke than a pack of cigarettes. Charcoal CO adds blood-oxygen loss.",
     "body_part": "lungs", "recovery_days": "days-weeks after stopping", "tags": ["hookah", "shisha", "waterpipe", "nargile"],
     "supplies": ["Water", "Mouthwash (oral hygiene)", "Carbon-monoxide awareness"],
     "remedies": [
         {"name": "Session cap", "type": "habit", "how": "Limit to rare social use; never daily — addiction forms like cigarettes.", "side_effects": ["Mild cravings first 2 weeks"]},
         {"name": "Oral recovery", "type": "home", "how": "Salt-water rinses + hydration; mouth lining recovers in 1-2 weeks.", "side_effects": []},
         {"name": "Lung cleanup", "type": "food", "how": "Steam inhalation + cardio to clear tar deposits.", "side_effects": []}],
     "risks_if_untreated": ["Carbon-monoxide exposure (headache, dizziness)", "Lung cancer risk similar to cigarettes", "Herpes/tuberculosis transmission via shared mouthpiece", "Gum disease & oral lesions", "Nicotine addiction"],
     "see_doctor_if": ["Persistent dry cough", "Mouth sores over 2 weeks", "Dizziness during sessions"]},
    {"name": "Cigarette Smoking Harm", "category": "chronic", "severity": "serious",
     "summary": "Every cigarette damages lungs, heart, blood vessels and skin. Extreme amounts (20+ daily) multiply all risks.",
     "body_part": "lungs", "recovery_days": "20 min to 15 years depending on effect", "tags": ["smoking", "cigarettes", "tobacco", "nicotine"],
     "supplies": ["Nicotine replacement", "Quitline / support app", "Water", "Sunflower seeds or carrot sticks (oral fix)"],
     "remedies": [
         {"name": "Quit day + NRT", "type": "medicine", "how": "Pick a date; patch + lozenge combo from day one; 4x success vs willpower alone.", "side_effects": ["Skin irritation", "Insomnia if patch worn overnight"]},
         {"name": "Lung age reversal", "type": "habit", "how": "After quitting: 2 weeks breathing improves; 1 year heart-disease risk halves; 10 years lung-cancer risk halves.", "side_effects": ["Weight gain 2-4 kg common — plan snacks"]},
         {"name": "Deep breathing retrain", "type": "home", "how": "4-7-8 breathing whenever a craving hits (90 seconds).", "side_effects": ["Lightheaded if rushed"]}],
     "risks_if_untreated": ["Lung cancer (85% of cases are smokers)", "COPD — irreversible lung damage", "Heart attack & stroke", "Peripheral artery disease, amputation risk", "Tooth loss, gum disease", "Erectile dysfunction", "12 years average life lost (extreme use)"],
     "see_doctor_if": ["Coughing blood", "Chronic morning cough", "Chest tightness on exertion", "Any new hoarseness over 3 weeks"]},
    {"name": "Extreme Alcohol Binge", "category": "chronic", "severity": "serious",
     "summary": "Acute high-volume drinking sessions — poisoning level. The single most dangerous pattern for the heart and brain.",
     "body_part": "brain", "recovery_days": "48h-2 weeks per episode; brain fog clears in days", "tags": ["binge", "extreme", "drunk", "alcohol poisoning"],
     "supplies": ["Electrolytes", "Thiamine (B1)", "Supervision — never leave a sleeping drunk person alone"],
     "remedies": [
         {"name": "Stop-drinking protocol", "type": "habit", "how": "No more than 1 unit/hour; food before; water between drinks.", "side_effects": []},
         {"name": "Recovery day", "type": "food", "how": "Electrolytes + bland carbs + B vitamins; no 'hair of the dog' — it deepens the cycle.", "side_effects": []}],
     "risks_if_untreated": ["Alcohol poisoning — breathing can stop", "Cardiac arrhythmia ('holiday heart')", "Blackouts & memory gaps", "Aspiration pneumonia if vomiting while unconscious", "Pancreatitis (extremely painful, can be fatal)"],
     "see_doctor_if": ["Unconscious and cannot be woken — call emergency", "Slow/irregular breathing", "Seizures", "Cold clammy pale skin"]},
    # ═══ INFECTIONS — bacterial, viral, fungal, parasitic (curable) ═══
    {"name": "Strep Throat", "category": "infection", "severity": "moderate",
     "summary": "Streptococcus bacterial throat infection — painful swallowing, fever, white patches on tonsils.",
     "body_part": "throat", "recovery_days": "3-7 days with antibiotics", "tags": ["bacterial", "fever", "sore throat"],
     "supplies": ["Thermometer", "GP throat swab", "Amoxicillin (prescribed)", "Salt", "Honey"],
     "remedies": [
         {"name": "Antibiotic course", "type": "medicine", "how": "Amoxicillin or penicillin V for 10 full days — finish it even when you feel better at day 3.", "side_effects": ["Nausea", "Diarrhoea", "Rash if allergic"]},
         {"name": "Salt-water gargle", "type": "home", "how": "Half tsp salt in warm water, gargle 30 s, 3-4x daily.", "side_effects": []},
         {"name": "Paracetamol + rest", "type": "medicine", "how": "For fever and pain until the antibiotic takes hold.", "side_effects": []}],
     "risks_if_untreated": ["Rheumatic fever — permanent heart valve damage", "Kidney inflammation (post-strep glomerulonephritis)", "Peritonsillar abscess", "Spread to others"],
     "see_doctor_if": ["Trouble breathing or drooling", "No improvement after 3 days of antibiotics", "One-sided severe throat swelling"]},
    {"name": "Urinary Tract Infection", "category": "infection", "severity": "moderate",
     "summary": "Bacterial infection of the bladder — burning urination, urgency, cloudy urine.",
     "body_part": "kidneys", "recovery_days": "3-7 days with antibiotics", "tags": ["uti", "burning", "urine"],
     "supplies": ["GP urine test", "Nitrofurantoin (prescribed)", "Water 2-3 L", "Heating pad"],
     "remedies": [
         {"name": "Antibiotics", "type": "medicine", "how": "Nitrofurantoin or trimethoprim 3-7 days exactly as prescribed.", "side_effects": ["Nausea", "Urine discolouration"]},
         {"name": "Flush protocol", "type": "habit", "how": "2-3 L water daily, urinate every 3 h, never hold it.", "side_effects": []},
         {"name": "Warm compress", "type": "home", "how": "Over the lower belly for cramping.", "side_effects": []}],
     "risks_if_untreated": ["Kidney infection (pyelonephritis)", "Sepsis", "Recurrent infections", "In pregnancy: premature labour"],
     "see_doctor_if": ["Fever with back/flank pain", "Blood in urine", "Vomiting — kidney involvement"]},
    {"name": "Conjunctivitis", "category": "infection", "severity": "mild",
     "summary": "Pink eye — inflamed eye surface from bacteria, virus or allergy; red, gritty, sticky discharge.",
     "body_part": "eyes", "recovery_days": "1-2 weeks", "tags": ["pink eye", "eyes", "contagious"],
     "supplies": ["Clean cotton pads", "Lubricating drops", "Antibiotic drops if bacterial"],
     "remedies": [
         {"name": "Antibiotic drops", "type": "medicine", "how": "Chloramphenicol drops if bacterial, 4x daily 5-7 days.", "side_effects": ["Brief stinging", "Blurred vision for minutes"]},
         {"name": "Lid hygiene + compress", "type": "home", "how": "Clean lids with cooled boiled water, warm compress 5 min 2x daily; viral clears alone.", "side_effects": []},
         {"name": "Antihistamine drops", "type": "medicine", "how": "For allergic pink eye.", "side_effects": ["Mild drowsiness"]}],
     "risks_if_untreated": ["Corneal involvement (rare)", "Spreads to both eyes and family members"],
     "see_doctor_if": ["Eye pain, light sensitivity, vision change", "Newborn with sticky eye", "Not settling after 10 days"]},
    {"name": "Ear Infection", "category": "infection", "severity": "moderate",
     "summary": "Middle-ear infection (otitis media) — deep earache, muffled hearing, fever; common after colds.",
     "body_part": "throat", "recovery_days": "1-2 weeks", "tags": ["earache", "hearing", "children"],
     "supplies": ["Paracetamol/ibuprofen", "Warm compress", "GP review"],
     "remedies": [
         {"name": "Pain relief first", "type": "medicine", "how": "Paracetamol or ibuprofen regular — most ear infections clear without antibiotics.", "side_effects": ["Ibuprofen: stomach upset"]},
         {"name": "Warm compress", "type": "home", "how": "Over the affected ear, 15 min sessions.", "side_effects": []},
         {"name": "Antibiotics if needed", "type": "medicine", "how": "Amoxicillin when symptoms pass 48 h, under age 2, or both ears.", "side_effects": ["Diarrhoea", "Rash"]}],
     "risks_if_untreated": ["Ruptured eardrum (usually heals)", "Temporary hearing loss", "Mastoiditis (rare, serious)"],
     "see_doctor_if": ["Swelling or redness behind the ear", "High fever over 39 C", "Symptoms beyond 3 days or under 2 years old"]},
    {"name": "Sinusitis", "category": "infection", "severity": "moderate",
     "summary": "Inflamed, blocked sinuses after a cold — facial pressure, thick nasal discharge, headache bending forward.",
     "body_part": "head", "recovery_days": "2-3 weeks", "tags": ["sinus", "facial pain", "blocked nose"],
     "supplies": ["Saline rinse kit", "Steam bowl", "Steroid nasal spray"],
     "remedies": [
         {"name": "Saline irrigation", "type": "home", "how": "Neti pot or squeeze bottle 1-2x daily with sterile salt water.", "side_effects": ["Use sterile/boiled water only"]},
         {"name": "Steroid nasal spray", "type": "medicine", "how": "Fluticasone daily for 2-4 weeks reduces swelling.", "side_effects": ["Nose dryness", "Rare nosebleed"]},
         {"name": "Antibiotics (bacterial only)", "type": "medicine", "how": "Only if symptoms pass 10 days and worsen — most sinusitis is viral.", "side_effects": ["GI upset"]}],
     "risks_if_untreated": ["Chronic sinusitis", "Orbital (eye socket) spread — rare but serious"],
     "see_doctor_if": ["Swelling around the eye or vision change", "Severe one-sided pain", "High fever with symptoms"]},
    {"name": "Acute Bronchitis", "category": "infection", "severity": "mild",
     "summary": "Viral chest infection — nagging cough after a cold, chest soreness from coughing.",
     "body_part": "lungs", "recovery_days": "1-3 weeks", "tags": ["cough", "chest", "viral"],
     "supplies": ["Honey", "Fluids", "Humidifier or steam"],
     "remedies": [
         {"name": "Honey + fluids", "type": "home", "how": "Honey 1-2 tsp at night calms cough as well as most syrups (not under 1 yr).", "side_effects": []},
         {"name": "Steam inhalation", "type": "home", "how": "Warm steam 10 min to loosen mucus.", "side_effects": ["Burn risk with very hot water"]},
         {"name": "Bronchodilator if wheezing", "type": "medicine", "how": "Salbutamol inhaler when tight-chested.", "side_effects": ["Fine tremor", "Fast heartbeat"]}],
     "risks_if_untreated": ["Pneumonia (secondary bacterial)", "Post-viral cough for weeks"],
     "see_doctor_if": ["Cough over 3 weeks", "Coughing blood", "Fever above 38.5 C", "Breathlessness at rest"]},
    {"name": "Pneumonia", "category": "infection", "severity": "serious",
     "summary": "Infection filling the lung airspaces — fever, productive cough, fast breathing, chest pain. Always needs assessment.",
     "body_part": "lungs", "recovery_days": "1-3 weeks (fatigue may last longer)", "tags": ["chest", "fever", "emergency"],
     "supplies": ["Antibiotics (prescribed)", "Pulse oximeter", "Fluids", "Bed rest"],
     "remedies": [
         {"name": "Antibiotics", "type": "medicine", "how": "Amoxicillin or doxycycline 5-7 days; severe cases IV in hospital.", "side_effects": ["Nausea", "Diarrhoea"]},
         {"name": "Fever + fluids", "type": "medicine", "how": "Paracetamol for fever, 2 L+ fluids, deep-breathing exercises every hour awake.", "side_effects": []}],
     "risks_if_untreated": ["Sepsis", "Lung abscess", "Pleural effusion", "Death — pneumonia kills without treatment"],
     "see_doctor_if": ["ALWAYS — pneumonia needs a clinician", "Oxygen sat under 94%", "Blue lips, confusion — emergency now"], "_note": "always-assess"},
    {"name": "Chickenpox", "category": "infection", "severity": "moderate",
     "summary": "Varicella-zoster virus — itchy blister rash in crops with fever; very contagious.",
     "body_part": "systemic", "recovery_days": "1-2 weeks", "tags": ["rash", "itchy", "children", "contagious"],
     "supplies": ["Calamine lotion", "Antihistamine", "Paracetamol (never ibuprofen/aspirin here)", "Nail clippers"],
     "remedies": [
         {"name": "Itch control", "type": "medicine", "how": "Calamine on spots + sedating antihistamine at night; keep nails short.", "side_effects": ["Drowsiness"]},
         {"name": "Oat baths", "type": "home", "how": "Lukewarm colloidal oatmeal baths soothe the rash.", "side_effects": []}],
     "risks_if_untreated": ["Bacterial skin infection from scratching", "Pneumonia in adults", "Encephalitis (rare)", "Shingles decades later (virus stays dormant)"],
     "see_doctor_if": ["Spots turn red, hot, painful", "Breathless or persistent cough", "Stiff neck, drowsy, dehydrated"]},
    {"name": "Whooping Cough", "category": "infection", "severity": "serious",
     "summary": "Pertussis — violent coughing fits ending in a whoop or vomiting; dangerous for infants.",
     "body_part": "lungs", "recovery_days": "6-12 weeks", "tags": ["cough", "infants", "contagious"],
     "supplies": ["Macrolide antibiotic (prescribed)", "Humidifier", "Small frequent meals"],
     "remedies": [
         {"name": "Antibiotics early", "type": "medicine", "how": "Azithromycin/clarithromycin — shortens infectiousness if started early.", "side_effects": ["Stomach upset", "Diarrhoea"]},
         {"name": "Cough care", "type": "habit", "how": "Humidified air, small meals, no smoke exposure; infants usually need hospital.", "side_effects": []}],
     "risks_if_untreated": ["Pneumonia", "Seizures, brain injury in infants", "Cracked ribs in adults", "Infant death — babies under 6 months are most at risk"],
     "see_doctor_if": ["ANY suspected case in an infant — hospital", "Breathing pauses or turning blue", "Coughing blood"]},
    {"name": "Typhoid Fever", "category": "infection", "severity": "serious",
     "summary": "Salmonella typhi from contaminated food/water — stepwise fever, abdominal pain, rose spots.",
     "body_part": "systemic", "recovery_days": "2-4 weeks", "tags": ["travel", "fever", "water"],
     "supplies": ["Antibiotics (prescribed)", "Oral rehydration", "Paracetamol"],
     "remedies": [
         {"name": "Antibiotics", "type": "medicine", "how": "Azithromycin or ciprofloxacin 7-14 days per local resistance patterns.", "side_effects": ["Nausea", "Headache"]},
         {"name": "Rehydration + rest", "type": "food", "how": "ORS and light meals; fever may take days to settle on treatment.", "side_effects": []}],
     "risks_if_untreated": ["Intestinal perforation", "Sepsis", "Death in 10-30% untreated"],
     "see_doctor_if": ["ALWAYS — needs diagnosis and antibiotics", "Fever over 3 days after travel", "Severe abdominal pain (perforation)"]},
    {"name": "Malaria", "category": "infection", "severity": "serious",
     "summary": "Parasite from mosquito bites — cyclical fever, chills, sweats, anaemia. A medical emergency.",
     "body_part": "systemic", "recovery_days": "1-2 weeks of treatment", "tags": ["mosquito", "travel", "fever"],
     "supplies": ["Antimalarials (prescribed)", "Hospital care for falciparum", "Paracetamol"],
     "remedies": [
         {"name": "Antimalarial course", "type": "medicine", "how": "Artemisinin-combination therapy; falciparum malaria is hospital-treated.", "side_effects": ["Dizziness", "Nausea", "Vivid dreams"]}],
     "risks_if_untreated": ["Cerebral malaria", "Organ failure", "Death"],
     "see_doctor_if": ["ALWAYS — any fever after tropical travel is malaria until proven otherwise"]},
    {"name": "Dengue Fever", "category": "infection", "severity": "serious",
     "summary": "Mosquito-borne virus — high fever, severe headache, joint pain, rash. Supportive care only.",
     "body_part": "systemic", "recovery_days": "1-2 weeks", "tags": ["mosquito", "fever", "rash"],
     "supplies": ["Paracetamol ONLY (never aspirin/ibuprofen)", "Oral rehydration", "3 L+ water daily"],
     "remedies": [
         {"name": "Fluid loading", "type": "food", "how": "3 L+ daily through the fever — the critical treatment; ORS if not eating.", "side_effects": []},
         {"name": "Paracetamol only", "type": "medicine", "how": "For fever/pain. Aspirin and ibuprofen raise bleeding risk — avoid.", "side_effects": []}],
     "risks_if_untreated": ["Dengue haemorrhagic fever", "Plasma leakage and shock (days 3-7)"],
     "see_doctor_if": ["Bleeding gums or nose", "Severe abdominal pain", "Restlessness, cold clammy skin — shock, emergency"]},
    {"name": "Ringworm", "category": "infection", "severity": "mild",
     "summary": "Fungal skin infection — round scaly itchy ring-shaped patch. Not actually a worm.",
     "body_part": "systemic", "recovery_days": "2-4 weeks", "tags": ["fungal", "rash", "itchy", "contagious"],
     "supplies": ["Antifungal cream", "Own towel", "Laundry at 60 C"],
     "remedies": [
         {"name": "Antifungal cream", "type": "medicine", "how": "Clotrimazole or terbinafine, continue 1 week after the rash clears.", "side_effects": ["Local irritation"]},
         {"name": "Oral antifungal", "type": "medicine", "how": "If scalp or nails involved — creams do not reach them.", "side_effects": ["Stomach upset"]}],
     "risks_if_untreated": ["Spreads across body, to scalp/nails", "Passes to family and pets"],
     "see_doctor_if": ["Scalp or nails involved", "Spreading despite 2 weeks of cream"]},
    {"name": "Athlete's Foot", "category": "infection", "severity": "mild",
     "summary": "Fungal infection between the toes — peeling, itching, cracked skin.",
     "body_part": "foot", "recovery_days": "1-4 weeks", "tags": ["fungal", "feet", "gym"],
     "supplies": ["Antifungal cream or spray", "Breathable socks", "Flip-flops for shared showers"],
     "remedies": [
         {"name": "Antifungal course", "type": "medicine", "how": "Terbinafine or clotrimazole 1-2x daily; keep going 1 week after clear.", "side_effects": ["Mild irritation"]},
         {"name": "Dry-feet protocol", "type": "habit", "how": "Dry between toes, rotate shoes daily, cotton/synthetic blend socks.", "side_effects": []}],
     "risks_if_untreated": ["Nail infection (harder cure)", "Cracks letting in bacteria — cellulitis risk, especially diabetics"],
     "see_doctor_if": ["Spreading up the foot", "Weeping, hot, red (bacterial)", "Diabetic feet — always"], "_note": "diabetes-flag"},
    {"name": "Scabies", "category": "infection", "severity": "moderate",
     "summary": "Mites burrowing in skin — intense night itch, burrow lines between fingers, wrists, waist.",
     "body_part": "systemic", "recovery_days": "1-4 weeks (itch can linger)", "tags": ["mites", "itch", "contagious"],
     "supplies": ["Permethrin 5% cream", "Laundry at 60 C", "Antihistamine"],
     "remedies": [
         {"name": "Permethrin treatment", "type": "medicine", "how": "Whole body neck-down overnight, repeat after 7 days; treat the whole household the same night.", "side_effects": ["Skin stinging"]},
         {"name": "Environment purge", "type": "habit", "how": "Wash bedding/clothes at 60 C or bag them 72 h; vacuum upholstery.", "side_effects": []}],
     "risks_if_untreated": ["Crusted (Norwegian) scabies", "Secondary bacterial infection, impetigo"],
     "see_doctor_if": ["No better after 2 treatments", "Weeping or pus (infected) — needs antibiotics too"]},
    {"name": "Head Lice", "category": "infection", "severity": "mild",
     "summary": "Lice living on scalp hair — itching, nits glued to hair shafts. Annoying, not dangerous.",
     "body_part": "brain", "recovery_days": "1-2 weeks", "tags": ["nits", "scalp", "children"],
     "supplies": ["Lice detection comb", "Conditioner", "Dimeticone lotion (optional)"],
     "remedies": [
         {"name": "Wet combing", "type": "home", "how": "Conditioner + fine comb, every 3-4 days for 2 weeks; break the lifecycle.", "side_effects": []},
         {"name": "Dimeticone lotion", "type": "medicine", "how": "Suffocates lice; 2 applications 7 days apart.", "side_effects": ["Scalp irritation"]}],
     "risks_if_untreated": ["Nothing serious — social misery and scalp sores from scratching"],
     "see_doctor_if": ["Scalp infection from scratching (swollen glands, sores)"]},
    {"name": "Impetigo", "category": "infection", "severity": "mild",
     "summary": "Bacterial skin infection — golden-crusted sores around nose/mouth; spreads by touch.",
     "body_part": "systemic", "recovery_days": "1-2 weeks", "tags": ["sores", "bacterial", "children", "contagious"],
     "supplies": ["Mupirocin antibiotic cream", "Own towels", "Plasters"],
     "remedies": [
         {"name": "Antibiotic cream", "type": "medicine", "how": "Mupirocin 3x daily 5-7 days; oral antibiotics if widespread.", "side_effects": ["Skin irritation", "Oral: GI upset"]},
         {"name": "No-touch protocol", "type": "habit", "how": "Cover sores, no sharing towels, cut nails, wash hands; 48 h off school after starting treatment.", "side_effects": []}],
     "risks_if_untreated": ["Rapid spread", "Cellulitis", "Rare post-strep kidney inflammation"],
     "see_doctor_if": ["Large areas or fever", "No improvement in 1 week"]},
    {"name": "Yeast Infection (Candidiasis)", "category": "infection", "severity": "mild",
     "summary": "Candida overgrowth — oral thrush (white patches) or skin/genital yeast (itch, redness, discharge).",
     "body_part": "throat", "recovery_days": "1-2 weeks", "tags": ["fungal", "thrush", "itch"],
     "supplies": ["Antifungal (fluconazole or topical azole)", "Probiotic yoghurt", "Loose cotton clothing"],
     "remedies": [
         {"name": "Antifungal", "type": "medicine", "how": "Fluconazole single dose, or azole cream/pessaries 1-7 days per site.", "side_effects": ["Headache", "Nausea", "Local burning"]},
         {"name": "Trigger control", "type": "habit", "how": "Dry the area well, cut sugar binges, rinse after inhaled steroids (asthma users).", "side_effects": []}],
     "risks_if_untreated": ["Recurrent infections", "Systemic candidiasis (only if immunocompromised)"],
     "see_doctor_if": ["More than 4 per year", "Fever or immunosuppression", "Not clearing after treatment"]},
    {"name": "Cellulitis", "category": "infection", "severity": "serious",
     "summary": "Bacterial infection of skin and underlying tissue — hot, red, spreading, tender area, often on a leg.",
     "body_part": "foot", "recovery_days": "1-2 weeks", "tags": ["bacterial", "skin", "spreading redness"],
     "supplies": ["Oral antibiotics (prescribed)", "Pen to mark the red border", "Elevation"],
     "remedies": [
         {"name": "Antibiotics 7 days", "type": "medicine", "how": "Flucloxacillin or comparable — mark the red edge with a pen to track spread.", "side_effects": ["GI upset"]},
         {"name": "Elevation + rest", "type": "habit", "how": "Raise the limb above heart level; treat any athlete's foot entry wound.", "side_effects": []}],
     "risks_if_untreated": ["Sepsis", "Abscess", "Spread to lymph and blood", "Rare necrotising infection"],
     "see_doctor_if": ["Redness spreading fast (cm per hour)", "Fever, bullae, dark skin patches — emergency"], "_note": "emergency-flag"},
    {"name": "Boils & Abscesses", "category": "infection", "severity": "mild",
     "summary": "Deep staph infection of a hair follicle — painful red lump with a white core.",
     "body_part": "systemic", "recovery_days": "1-2 weeks", "tags": ["staph", "skin", "abscess"],
     "supplies": ["Warm compress", "Antiseptic", "Clean dressings"],
     "remedies": [
         {"name": "Draw it out", "type": "home", "how": "Warm moist compress 15-20 min, 4x daily until it drains itself. Never squeeze.", "side_effects": []},
         {"name": "Incision & drainage", "type": "tool", "how": "Large or painful boils need a clinician to lance — do not DIY.", "side_effects": []}],
     "risks_if_untreated": ["Spread as new boils", "Sepsis", "Face boils (danger triangle) can seed infection inward"],
     "see_doctor_if": ["Boil on the face or spine", "Fever or red streaks", "Recurring boils (screen for staph carriage)"]},
    {"name": "COVID-19", "category": "infection", "severity": "moderate",
     "summary": "SARS-CoV-2 — sore throat, cough, fever, fatigue; current variants usually milder but not harmless.",
     "body_part": "lungs", "recovery_days": "1-2 weeks (fatigue can linger)", "tags": ["virus", "fever", "cough"],
     "supplies": ["Pulse oximeter", "Paracetamol", "Fluids", "Lateral flow tests"],
     "remedies": [
         {"name": "Symptom care", "type": "medicine", "how": "Rest, fluids, paracetamol; isolate while infectious.", "side_effects": []},
         {"name": "Antiviral (high-risk)", "type": "medicine", "how": "Nirmatrelvir within 5 days of symptoms for high-risk patients.", "side_effects": ["Metallic taste", "Diarrhoea"]}],
     "risks_if_untreated": ["Long COVID (months of fatigue/fog)", "Pneumonia", "Blood clots"],
     "see_doctor_if": ["Oxygen sat under 94%", "Breathless at rest", "Chest pain, confusion — emergency"]},
    {"name": "Mononucleosis (Glandular Fever)", "category": "infection", "severity": "moderate",
     "summary": "EBV infection — heavy fatigue, big glands, sore throat, fever; the university-kissing-disease.",
     "body_part": "throat", "recovery_days": "2-6 weeks (fatigue may last months)", "tags": ["ebv", "fatigue", "glands"],
     "supplies": ["Paracetamol", "Fluids", "Patience"],
     "remedies": [
         {"name": "Staged rest", "type": "habit", "how": "Rest 2-4 weeks, then gradual return; no contact sports for 4+ weeks (spleen protection).", "side_effects": []},
         {"name": "Symptom relief", "type": "medicine", "how": "Paracetamol for throat/fever; antibiotics do nothing (viral) and amoxicillin causes a rash here.", "side_effects": []}],
     "risks_if_untreated": ["Spleen rupture (contact sport too early)", "Hepatitis", "Prolonged post-viral fatigue"],
     "see_doctor_if": ["Severe pain upper-left abdomen (spleen)", "Trouble breathing or swallowing"]},
    {"name": "Rabies Exposure", "category": "infection", "severity": "serious",
     "summary": "Virus from mammal bites/scratches — curable ONLY if treated before symptoms. After onset it is fatal.",
     "body_part": "brain", "recovery_days": "vaccine course 2-4 weeks", "tags": ["bite", "vaccine", "emergency", "travel"],
     "supplies": ["Soap and water (immediately)", "Rabies vaccine course", "HRIG immunoglobulin"],
     "remedies": [
         {"name": "Wound wash NOW", "type": "home", "how": "Scrub under running water with soap for 15 minutes, then antiseptic — this alone removes most virus.", "side_effects": []},
         {"name": "PEP vaccine course", "type": "medicine", "how": "Immunoglobulin + vaccine on days 0, 3, 7, 14 — seek same day, do not wait.", "side_effects": ["Sore arm", "Headache", "Nausea"]}],
     "risks_if_untreated": ["Once symptoms begin, rabies is virtually 100% fatal — there is no cure after onset"],
     "see_doctor_if": ["ALWAYS — any bite/scratch/lick on broken skin from a mammal in an endemic area is same-day emergency"], "_note": "emergency-flag"},
    {"name": "Tetanus Exposure", "category": "infection", "severity": "serious",
     "summary": "Clostridium from dirt in wounds — stiffness and spasms. Fully preventable with vaccination.",
     "body_part": "systemic", "recovery_days": "weeks of supportive care", "tags": ["wound", "vaccine", "rust", "emergency"],
     "supplies": ["Tetanus booster", "TIG immunoglobulin (dirty wounds)", "Wound cleaning kit"],
     "remedies": [
         {"name": "Booster vaccine", "type": "medicine", "how": "Booster if last dose over 5 years ago; TIG added for deep/dirty wounds if under-vaccinated.", "side_effects": ["Sore arm", "Mild fever"]},
         {"name": "Wound care", "type": "home", "how": "Thorough cleaning and debridement of the wound itself.", "side_effects": []}],
     "risks_if_untreated": ["Lockjaw, muscle spasms", "Breathing paralysis", "Death in ~10% of symptomatic cases"],
     "see_doctor_if": ["ALWAYS for deep/dirty wounds without a booster in 5 years"], "_note": "emergency-flag"},
    {"name": "Intestinal Worms", "category": "infection", "severity": "mild",
     "summary": "Roundworm, threadworm or hookworm — itching (anal, at night), tummy ache, sometimes visible worms.",
     "body_part": "gut", "recovery_days": "1 day dose, repeat after 2 weeks", "tags": ["parasite", "itching", "children"],
     "supplies": ["Mebendazole/albendazole", "Morning shower (not bath)", "Nail brush"],
     "remedies": [
         {"name": "Deworming dose", "type": "medicine", "how": "Mebendazole single dose (threadworm) or 3-day course (roundworm); repeat at 2 weeks.", "side_effects": ["Mild stomach upset"]},
         {"name": "Household protocol", "type": "habit", "how": "Treat everyone, wash at 60 C, morning shower to remove eggs, short nails.", "side_effects": []}],
     "risks_if_untreated": ["Anaemia (hookworm)", "Malnutrition in children", "Intestinal blockage (very heavy loads)"],
     "see_doctor_if": ["Severe abdominal pain or vomiting", "Signs of anaemia"]},
    {"name": "Giardiasis", "category": "infection", "severity": "moderate",
     "summary": "Giardia parasite from untreated water — foul-smelling greasy stools, bloating, cramps, burps.",
     "body_part": "gut", "recovery_days": "1-2 weeks", "tags": ["parasite", "water", "diarrhoea"],
     "supplies": ["Metronidazole/tinidazole (prescribed)", "Oral rehydration"],
     "remedies": [
         {"name": "Antiparasitic course", "type": "medicine", "how": "Tinidazole single dose or metronidazole 3x daily for 5-7 days.", "side_effects": ["Metallic taste", "Nausea", "NO alcohol during and 48 h after"]},
         {"name": "Gut reset", "type": "food", "how": "Avoid lactose 2-4 weeks after — the gut lining recovers slowly.", "side_effects": []}],
     "risks_if_untreated": ["Chronic malabsorption and weight loss", "New lactose intolerance"],
     "see_doctor_if": ["Blood in stool", "Fever", "Dehydration, symptoms over 1 week"]},
    {"name": "Cholera", "category": "infection", "severity": "serious",
     "summary": "Vibrio from contaminated water — rapid 'rice-water' diarrhoea draining litres a day. Rehydration is the cure.",
     "body_part": "gut", "recovery_days": "days with treatment", "tags": ["water", "outbreak", "dehydration", "emergency"],
     "supplies": ["Oral rehydration salts (bulk)", "IV fluids (severe)", "Doxycycline"],
     "remedies": [
         {"name": "Aggressive rehydration", "type": "food", "how": "The actual cure: ORS by the litre; severe cases need IV fluids fast.", "side_effects": []},
         {"name": "Antibiotic assist", "type": "medicine", "how": "Doxycycline shortens the illness and shedding.", "side_effects": ["GI upset"]}],
     "risks_if_untreated": ["Death within hours from dehydration and shock"],
     "see_doctor_if": ["ALWAYS — profuse watery diarrhoea after endemic travel is an emergency"], "_note": "emergency-flag"},

    # ═══ DEFICIENCIES — replace what the body is missing ═══
    {"name": "Iron-Deficiency Anaemia", "category": "deficiency", "severity": "moderate",
     "summary": "Low iron means low haemoglobin — fatigue, pallor, breathlessness on stairs, brittle nails, pale inner eyelids.",
     "body_part": "systemic", "recovery_days": "2-3 months to rebuild stores", "tags": ["anaemia", "tired", "iron"],
     "supplies": ["Ferrous sulfate tablets", "Vitamin C (orange juice)", "Blood test (full blood count + ferritin)"],
     "remedies": [
         {"name": "Iron course", "type": "medicine", "how": "Ferrous sulfate 200 mg once daily (alternate days absorbs nearly as well with fewer side effects) with vitamin C, away from tea/coffee.", "side_effects": ["Black stools (normal)", "Constipation", "Nausea"]},
         {"name": "Find the leak", "type": "tool", "how": "Heavy periods and gut bleeding are the usual causes — treating the source IS the cure.", "side_effects": []},
         {"name": "Iron foods", "type": "food", "how": "Red meat, liver, lentils, spinach, fortified cereal — daily.", "side_effects": []}],
     "risks_if_untreated": ["Heart strain and fast heartbeat", "Pregnancy complications", "Cognitive fog, fainting"],
     "see_doctor_if": ["Chest pain or fainting", "Haemoglobin not rising after 4 weeks", "Any adult with unexplained iron loss needs investigation"]},
    {"name": "Vitamin D Deficiency", "category": "deficiency", "severity": "mild",
     "summary": "The indoor-lifestyle deficiency — aching muscles, bone pain, low mood, frequent infections.",
     "body_part": "spine", "recovery_days": "6-12 weeks", "tags": ["sunlight", "bones", "mood", "tired"],
     "supplies": ["Vitamin D3 tablets", "Blood test (25-OH vitamin D)"],
     "remedies": [
         {"name": "D3 supplement", "type": "medicine", "how": "1000-4000 IU daily with a meal containing fat; high-dose loading if severely low.", "side_effects": ["Rare: too much raises calcium"]},
         {"name": "Sunlight + food", "type": "habit", "how": "15-30 min midday sun on forearms; oily fish, egg yolks, fortified milk.", "side_effects": []}],
     "risks_if_untreated": ["Osteoporosis and fractures", "Rickets in children", "Muscle weakness, falls in elderly", "Low mood"],
     "see_doctor_if": ["Bone pain or deformity in a child", "Symptoms not lifting after 3 months"]},
    {"name": "Vitamin B12 Deficiency", "category": "deficiency", "severity": "moderate",
     "summary": "Needed for nerves and blood — tingling hands/feet, fatigue, sore tongue, memory fog. Vegans and over-50s at risk.",
     "body_part": "brain", "recovery_days": "weeks to months", "tags": ["nerve", "vegan", "tingling", "tired"],
     "supplies": ["B12 injections or high-dose oral", "Blood test (B12 + intrinsic factor)"],
     "remedies": [
         {"name": "B12 replacement", "type": "medicine", "how": "Injections if absorption is broken (pernicious anaemia); 1 mg daily oral otherwise.", "side_effects": ["Injection site soreness", "Acne-like rash"]},
         {"name": "Dietary B12", "type": "food", "how": "Meat, fish, eggs, dairy, fortified nutritional yeast — essential reading for vegans.", "side_effects": []}],
     "risks_if_untreated": ["Permanent nerve damage", "Memory loss", "Severe anaemia"],
     "see_doctor_if": ["Tingling, numbness or balance problems — urgent before nerve damage becomes permanent"]},
    {"name": "Iodine Deficiency", "category": "deficiency", "severity": "mild",
     "summary": "Thyroid can't make hormone — neck swelling (goitre), fatigue, weight gain, feeling cold.",
     "body_part": "throat", "recovery_days": "months", "tags": ["thyroid", "goitre", "salt"],
     "supplies": ["Iodised salt", "Seaweed, fish, dairy"],
     "remedies": [
         {"name": "Iodine in diet", "type": "food", "how": "Switch to iodised salt, add fish/dairy/seaweed; supplements only in pregnancy if advised.", "side_effects": ["Excess iodine itself disrupts thyroid"]}],
     "risks_if_untreated": ["Hypothyroidism", "Persistent goitre", "Cretinism if severe in pregnancy"],
     "see_doctor_if": ["Visible neck swelling", "Pregnancy or breastfeeding"]},
    {"name": "Scurvy", "category": "deficiency", "severity": "serious",
     "summary": "Vitamin C zero for months — bleeding gums, corkscrew hairs, wounds reopening, bruises. Pirate-tier rare, but real.",
     "body_part": "systemic", "recovery_days": "1-2 weeks", "tags": ["vitamin c", "gums", "sailor"],
     "supplies": ["Vitamin C tablets", "Citrus, peppers, kiwi, berries"],
     "remedies": [
         {"name": "Vitamin C reload", "type": "medicine", "how": "1-2 g daily for 2-3 days, then 500 mg until clear, then normal intake.", "side_effects": ["Loose stools at high doses"]}],
     "risks_if_untreated": ["Tooth loss", "Deep bleeding into joints", "Death (yes, really)"],
     "see_doctor_if": ["Bleeding gums with poor diet", "Wounds not healing"]},

    # ═══ CHRONIC — manageable, and some fully reversible ═══
    {"name": "Type 2 Diabetes", "category": "chronic", "severity": "serious",
     "summary": "Insulin resistance — thirst, frequent urination, fatigue, blurred vision. Remission is genuinely possible with weight loss.",
     "body_part": "systemic", "recovery_days": "lifelong; remission in months", "tags": ["sugar", "insulin", "diet"],
     "supplies": ["Glucometer", "Metformin (prescribed)", "Blood tests (HbA1c)"],
     "remedies": [
         {"name": "Metformin", "type": "medicine", "how": "First-line; with meals.", "side_effects": ["Stomach upset (settle with food)", "Long-term B12 drain"]},
         {"name": "Remission protocol", "type": "habit", "how": "Losing 10-15 kg early after diagnosis puts nearly half into remission (DiRECT trial: 46%). Low-refined-carb eating, 150 min/week exercise.", "side_effects": []},
         {"name": "Monitoring", "type": "tool", "how": "HbA1c every 3-6 months; annual eye and foot checks.", "side_effects": []}],
     "risks_if_untreated": ["Nerve damage, kidney failure, blindness", "Amputation", "Heart attack and stroke", "DKA — vomiting, fruity breath = emergency"],
     "see_doctor_if": ["ALWAYS — needs diagnosis and a care plan", "Vomiting with fruity breath", "Non-healing foot wound"], "_note": "always-assess"},
    {"name": "High Blood Pressure", "category": "chronic", "severity": "moderate",
     "summary": "The silent one — no symptoms until it breaks something. Numbers above 140/90 on repeated reads need action.",
     "body_part": "heart", "recovery_days": "lifelong managed; lifestyle works in 3 months", "tags": ["hypertension", "bp", "stroke risk"],
     "supplies": ["Home BP monitor", "Medication if prescribed"],
     "remedies": [
         {"name": "Lifestyle first", "type": "habit", "how": "Salt under 5 g/day, 30 min brisk walk 5x/week, 5 kg weight loss, alcohol down — drops 10-20 systolic combined.", "side_effects": []},
         {"name": "Medication", "type": "medicine", "how": "ACE inhibitor/ARB or amlodipine per clinician.", "side_effects": ["ACE dry cough", "Amlodipine ankle swelling"]}],
     "risks_if_untreated": ["Stroke", "Heart attack", "Kidney failure", "Aneurysm"],
     "see_doctor_if": ["Readings over 180/120", "Headache with blurred vision — emergency"]},
    {"name": "High Cholesterol", "category": "chronic", "severity": "mild",
     "summary": "Fatty deposits narrowing arteries over decades — invisible until the heart or brain pays.",
     "body_part": "heart", "recovery_days": "3-6 months to shift", "tags": ["statin", "heart", "diet"],
     "supplies": ["Lipid blood test", "Oats, oily fish, nuts"],
     "remedies": [
         {"name": "Statins if high-risk", "type": "medicine", "how": "Atorvastatin per clinician — the evidence for secondary prevention is overwhelming.", "side_effects": ["Muscle aches", "Liver enzyme drift"]},
         {"name": "Diet rebuild", "type": "food", "how": "Oats/psyllium daily, oily fish 2x/week, swap saturated fat for olive oil and nuts; cut trans fats entirely.", "side_effects": []}],
     "risks_if_untreated": ["Atherosclerosis — heart attack, stroke", "Peripheral artery disease"],
     "see_doctor_if": ["Family history of early heart disease", "Chest tightness on exertion — same-day"]},
    {"name": "Hypothyroidism", "category": "chronic", "severity": "moderate",
     "summary": "Underactive thyroid — cold, tired, constipated, gaining weight, thinning hair. One tablet fixes it.",
     "body_part": "throat", "recovery_days": "4-6 weeks to feel right", "tags": ["thyroid", "tired", "cold"],
     "supplies": ["Levothyroxine (prescribed)", "Thyroid blood tests"],
     "remedies": [
         {"name": "Levothyroxine daily", "type": "medicine", "how": "Empty stomach, 30+ min before food; calcium/iron 4 h apart.", "side_effects": ["Overdose feels like: palpitations, insomnia, heat"]},
         {"name": "Retest cycle", "type": "tool", "how": "TSH retest 6-8 weeks after any dose change.", "side_effects": []}],
     "risks_if_untreated": ["High cholesterol", "Depression", "Goitre", "Myxoedema coma (extreme)"],
     "see_doctor_if": ["ALWAYS — needs blood confirmation", "Pregnancy — dose must be adjusted early"]},
    {"name": "GERD (Acid Reflux)", "category": "chronic", "severity": "mild",
     "summary": "Stomach acid climbing the oesophagus — burning chest, sour taste, worse lying down.",
     "body_part": "stomach", "recovery_days": "4-8 weeks", "tags": ["heartburn", "acid", "reflux"],
     "supplies": ["Omeprazole (PPI)", "Bed blocks to raise the head", "Trigger diary"],
     "remedies": [
         {"name": "PPI course", "type": "medicine", "how": "Omeprazole 20 mg mornings, 4-8 weeks.", "side_effects": ["Headache", "Long-term: B12 and magnesium drift"]},
         {"name": "Mechanical fixes", "type": "habit", "how": "No food 3 h before bed, raise bed head 15 cm, left-side sleeping, 5-10% weight loss if applicable.", "side_effects": []},
         {"name": "Trigger audit", "type": "food", "how": "Track and cut your personal triggers — usually coffee, alcohol, fat, late meals.", "side_effects": []}],
     "risks_if_untreated": ["Oesophagitis and ulcers", "Barrett's oesophagus (pre-cancerous)", "Stricture, tooth enamel loss"],
     "see_doctor_if": ["Difficulty swallowing", "Unintentional weight loss", "Vomiting blood or black stools"]},
    {"name": "Irritable Bowel Syndrome", "category": "chronic", "severity": "mild",
     "summary": "Gut-brain misfiring — cramps, bloating, alternating bowel habits, no structural damage.",
     "body_part": "gut", "recovery_days": "ongoing; diet helps in 4-6 weeks", "tags": ["ibs", "bloating", "cramps"],
     "supplies": ["Low-FODMAP guide", "Peppermint oil capsules", "Soluble fibre (ispaghula)"],
     "remedies": [
         {"name": "Low-FODMAP trial", "type": "food", "how": "4-6 weeks elimination, then structured reintroduction — best with a dietitian.", "side_effects": []},
         {"name": "Peppermint oil", "type": "medicine", "how": "1 capsule 3x daily before meals relaxes gut spasm.", "side_effects": ["Heartburn"]},
         {"name": "Soluble fibre + stress work", "type": "habit", "how": "Ispaghula husk daily; CBT and gut-directed hypnotherapy have real evidence here.", "side_effects": ["Gas the first week"]}],
     "risks_if_untreated": ["Nothing structural — quality of life only"],
     "see_doctor_if": ["Blood in stool, night symptoms, weight loss — those are NOT IBS, get checked"]},
    {"name": "Constipation", "category": "common", "severity": "mild",
     "summary": "Hard, infrequent stools — straining, bloating, that unfinished feeling.",
     "body_part": "gut", "recovery_days": "days", "tags": ["bowel", "fibre", "straining"],
     "supplies": ["Ispaghula husk", "Water 2 L", "Senna (short-term only)"],
     "remedies": [
         {"name": "Fibre + water", "type": "food", "how": "25-30 g fibre daily INCREASED SLOWLY with 2 L water — fibre without water backfires.", "side_effects": []},
         {"name": "Toilet routine", "type": "habit", "how": "Sit 15-20 min after breakfast, feet on a low stool, phone down.", "side_effects": []},
         {"name": "Stimulant laxative", "type": "medicine", "how": "Senna at night for short rescue only.", "side_effects": ["Cramps", "Dependency beyond 1 week"]}],
     "risks_if_untreated": ["Haemorrhoids", "Anal fissure", "Faecal impaction"],
     "see_doctor_if": ["No relief after 1 week", "Vomiting or severe pain", "Blood in stool"]},
    {"name": "Haemorrhoids", "category": "common", "severity": "mild",
     "summary": "Swollen anal cushions — bright red blood on paper, itching, a tender lump.",
     "body_part": "gut", "recovery_days": "1-2 weeks", "tags": ["piles", "bleeding", "straining"],
     "supplies": ["Fibre supplement", "Sitz bath basin", "Topical lidocaine/HC (short)"],
     "remedies": [
         {"name": "Soften the stool", "type": "food", "how": "Fibre + water so nothing strains; this is 80% of the treatment.", "side_effects": []},
         {"name": "Sitz baths", "type": "home", "how": "Warm water 15 min, 2-3x daily, dry gently.", "side_effects": []},
         {"name": "Topical relief", "type": "medicine", "how": "Lidocaine/short hydrocortisone for flares.", "side_effects": ["Skin thinning beyond 1 week"]}],
     "risks_if_untreated": ["Chronic blood loss anaemia", "Thrombosed pile (very painful)", "Masking bowel disease"],
     "see_doctor_if": ["ANY rectal bleeding deserves one proper look, especially over 45", "Dark blood mixed in stool"]},
    {"name": "Kidney Stones", "category": "chronic", "severity": "serious",
     "summary": "Crystals lodging in the ureter — waves of agonising flank-to-groin pain, blood in urine, nausea.",
     "body_part": "kidneys", "recovery_days": "days-2 weeks to pass", "tags": ["stones", "flank pain", "colic"],
     "supplies": ["Water 3 L", "Strainer cup", "NSAID pain relief", "Stone analysis"],
     "remedies": [
         {"name": "Pain + flush", "type": "medicine", "how": "NSAIDs (diclofenac) beat opioids for renal colic; tamsulosin helps pass the stone; strain urine to catch it.", "side_effects": ["NSAID: stomach/kidney caution", "Tamsulosin: dizziness"]},
         {"name": "Prevention", "type": "habit", "how": "3 L water daily; cut salt; normal calcium (low calcium RAISES stone risk); stone-type-specific diet after analysis.", "side_effects": []},
         {"name": "Procedures", "type": "tool", "how": "Lithotripsy or ureteroscopy for stones too big to pass.", "side_effects": []}],
     "risks_if_untreated": ["Hydronephrosis — backed-up kidney", "Infection behind the blockage", "Kidney damage", "50% recurrence"],
     "see_doctor_if": ["Fever WITH stone pain = obstructed infected kidney, emergency", "Uncontrolled vomiting", "Single kidney"], "_note": "emergency-flag"},
    {"name": "Gout", "category": "chronic", "severity": "moderate",
     "summary": "Urate crystals in a joint — the big toe waking you like it's broken, hot and screaming to a feather's touch.",
     "body_part": "foot", "recovery_days": "days for an attack", "tags": ["uric acid", "big toe", "beer"],
     "supplies": ["NSAIDs or colchicine", "Allopurinol (between attacks)", "Water"],
     "remedies": [
         {"name": "Attack control", "type": "medicine", "how": "NSAID or colchicine at the first twinge; ice and elevate.", "side_effects": ["Colchicine: GI cramps"]},
         {"name": "Urate lowering", "type": "medicine", "how": "Allopurinol DAILY between attacks (never start during one); target blood urate under 360.", "side_effects": ["Rash — stop and call"]},
         {"name": "Diet trim", "type": "food", "how": "Cut beer, shellfish, organ meats, sugary drinks; cherry consumption has modest evidence; water 2-3 L.", "side_effects": []}],
     "risks_if_untreated": ["Joint destruction", "Tophi — crystal lumps", "Kidney stones and kidney disease"],
     "see_doctor_if": ["First attack needs a proper diagnosis", "Fever over the joint — septic arthritis mimics gout"]},
    {"name": "Allergic Rhinitis", "category": "common", "severity": "mild",
     "summary": "Hay fever — sneezing, streaming nose and itchy eyes from pollen, dust or pets.",
     "body_part": "throat", "recovery_days": "season-long managed", "tags": ["hay fever", "pollen", "sneeze", "allergy"],
     "supplies": ["Non-drowsy antihistamine", "Steroid nasal spray", "Shower after outdoors"],
     "remedies": [
         {"name": "Antihistamine", "type": "medicine", "how": "Loratadine/cetirizine daily through the season.", "side_effects": ["Some drowsiness (cetirizine)"]},
         {"name": "Steroid nasal spray", "type": "medicine", "how": "Fluticasone daily — start 2 weeks before season; the most effective single treatment.", "side_effects": ["Nose dryness"]},
         {"name": "Pollen defence", "type": "habit", "how": "Shower and change after coming in, windows shut on high-pollen days, sunglasses out.", "side_effects": []}],
     "risks_if_untreated": ["Sinusitis", "Poor sleep", "Asthma flare trigger"],
     "see_doctor_if": ["Wheeze or chest tightness alongside (asthma)"]},
    {"name": "Asthma", "category": "chronic", "severity": "moderate",
     "summary": "Twitchy airways — wheeze, chest tightness, night cough. Controlled, it should never limit you.",
     "body_part": "lungs", "recovery_days": "lifelong managed", "tags": ["wheeze", "inhaler", "breathless"],
     "supplies": ["Reliever inhaler (salbutamol)", "Preventer inhaler (steroid)", "Spacer", "Written action plan"],
     "remedies": [
         {"name": "Preventer daily", "type": "medicine", "how": "Steroid inhaler EVERY day even when well — this is what prevents attacks.", "side_effects": ["Oral thrush — rinse mouth after"]},
         {"name": "Reliever as needed", "type": "medicine", "how": "Salbutamol for symptoms; more than 3x/week means under-controlled.", "side_effects": ["Tremor", "Fast heartbeat"]},
         {"name": "Trigger audit", "type": "habit", "how": "Dust mite covers, pet rules, smoke-free home, flu vaccination.", "side_effects": []}],
     "risks_if_untreated": ["Fatal attacks", "Airway remodelling", "Reliever over-reliance masks decline"],
     "see_doctor_if": ["Attack not relieved by inhaler — emergency", "Reliever needed 3+ times a week", "Night waking breathless"], "_note": "emergency-flag"},
    {"name": "Eczema", "category": "chronic", "severity": "mild",
     "summary": "Leaky skin barrier — dry, itchy, inflamed patches in the creases. Moisturising IS the treatment.",
     "body_part": "systemic", "recovery_days": "flares 1-2 weeks", "tags": ["dermatitis", "itchy", "dry skin"],
     "supplies": ["Emollient (large tubs)", "Hydrocortisone 1% for flares", "Soap substitute"],
     "remedies": [
         {"name": "Emollients 3x daily", "type": "medicine", "how": "The cornerstone — generous, every day, even when clear.", "side_effects": []},
         {"name": "Steroid for flares", "type": "medicine", "how": "Hydrocortisone 1% thin layer 5-7 days on flares.", "side_effects": ["Skin thinning with overuse"]},
         {"name": "Trigger hygiene", "type": "habit", "how": "Lukewarm showers, soap-free wash, cotton clothes, fragrance-free everything.", "side_effects": []}],
     "risks_if_untreated": ["Infected eczema (weeping, golden crust)", "Sleep loss", "Asthma/hay fever link (atopic march)"],
     "see_doctor_if": ["Weeping or crusted skin (infection)", "Not sleeping", "Widespread flare"]},
    {"name": "Acne", "category": "common", "severity": "mild",
     "summary": "Blocked, inflamed follicles — blackheads, whiteheads, papules. Treatable; scarring is optional.",
     "body_part": "systemic", "recovery_days": "6-12 weeks to clear", "tags": ["pimples", "skin", "teen"],
     "supplies": ["Benzoyl peroxide 2.5%", "Adapalene gel", "Non-comedogenic moisturiser"],
     "remedies": [
         {"name": "Benzoyl peroxide", "type": "medicine", "how": "Thin layer nightly; kills the bacteria and unblocks pores.", "side_effects": ["Bleaches fabrics", "Dryness"]},
         {"name": "Adapalene (retinoid)", "type": "medicine", "how": "Nightly pea-size for the whole face; works on comedones.", "side_effects": ["Peeling", "Sun sensitivity"]},
         {"name": "Oral options", "type": "medicine", "how": "Doxycycline for moderate (GI upset, sun); isotretinoin for severe — highly effective, closely monitored.", "side_effects": ["See prescriber"]}],
     "risks_if_untreated": ["Permanent scarring", "Post-inflammatory dark marks", "Self-esteem hit"],
     "see_doctor_if": ["Nodulocystic or scarring acne — refer early, scarring is forever"]},

    # ═══ MENTAL HEALTH — treatable, and the treatments work ═══
    {"name": "Depression", "category": "mental", "severity": "serious",
     "summary": "Persistent low mood, anhedonia, sleep and appetite change — an illness, not a character flaw. Treatments work.",
     "body_part": "brain", "recovery_days": "6-12 weeks to respond", "tags": ["low", "sad", "anhedonia"],
     "supplies": ["Therapy access (CBT)", "SSRI if indicated", "Sleep regularity"],
     "remedies": [
         {"name": "Therapy", "type": "habit", "how": "CBT matches medication for mild-moderate depression and protects longer.", "side_effects": []},
         {"name": "SSRI", "type": "medicine", "how": "Sertraline/fluoxetine if moderate-severe; effect starts at 2-4 weeks; never stop abruptly.", "side_effects": ["Nausea first 1-2 weeks", "Sexual side effects"]},
         {"name": "Behavioural activation", "type": "habit", "how": "Schedule small rewarding actions BEFORE motivation returns; 3x/week exercise has real effect size.", "side_effects": []}],
     "risks_if_untreated": ["Worsening, substance use", "Job/relationship loss", "Suicide"],
     "see_doctor_if": ["Thoughts of self-harm — NOW, same day", "No improvement after 6 weeks of treatment", "Cannot function"], "_note": "always-assess"},
    {"name": "Generalised Anxiety", "category": "mental", "severity": "moderate",
     "summary": "Constant worry the mind can't switch off — tension, racing heart, worst-case loops.",
     "body_part": "brain", "recovery_days": "4-8 weeks", "tags": ["worry", "stress", "anxiety"],
     "supplies": ["Therapy access (CBT)", "Caffeine audit", "Breathing practice"],
     "remedies": [
         {"name": "CBT", "type": "habit", "how": "Gold standard — rewires the worry loops with practice.", "side_effects": []},
         {"name": "Caffeine cut", "type": "food", "how": "Caffeine mimics and amplifies anxiety — halve it for 2 weeks and compare.", "side_effects": ["Withdrawal headache for days 1-3"]},
         {"name": "SSRI if needed", "type": "medicine", "how": "Sertraline etc. for persistent symptoms.", "side_effects": ["Initial jitteriness"]}],
     "risks_if_untreated": ["High blood pressure", "Insomnia", "Panic disorder, depression"],
     "see_doctor_if": ["First-time chest pain", "Cannot work or leave home"]},
    {"name": "Caffeine Dependence", "category": "mental", "severity": "mild",
     "summary": "Needing coffee to feel baseline — headaches without it, 3 pm crashes, sleep that doesn't refresh.",
     "body_part": "brain", "recovery_days": "1-2 weeks to withdraw", "tags": ["coffee", "energy", "sleep"],
     "supplies": ["Decaf", "Water", "Sleep schedule"],
     "remedies": [
         {"name": "Taper, not cold turkey", "type": "habit", "how": "Cut 25% per week — quitting outright guarantees 3 days of withdrawal headache.", "side_effects": ["Brief headache, grumpiness"]},
         {"name": "Half-caff bridge", "type": "food", "how": "Half regular, half decaf, shift the ratio weekly.", "side_effects": []}],
     "risks_if_untreated": ["Anxiety, reflux, raised BP", "Sleep debt compounding"],
     "see_doctor_if": ["Palpitations or chest flutters"]},

    # ═══ DENTAL & EYES — small things that get expensive ═══
    {"name": "Tooth Decay", "category": "common", "severity": "moderate",
     "summary": "Sugar-loving bacteria dissolving enamel — sensitivity, then holes, then abscesses.",
     "body_part": "throat", "recovery_days": "one filling visit", "tags": ["cavity", "teeth", "sugar"],
     "supplies": ["Dentist appointment", "Fluoride toothpaste 1450+ ppm", "Interdental brushes"],
     "remedies": [
         {"name": "Filling", "type": "tool", "how": "The actual cure — decay does not reverse once cavitied.", "side_effects": []},
         {"name": "Sugar frequency rule", "type": "food", "how": "Frequency beats quantity: sipping sugary drinks all day never lets enamel recover. Keep sugar to meals.", "side_effects": []},
         {"name": "Fluoride discipline", "type": "habit", "how": "Brush 2 min, 2x daily; spit, don't rinse; floss/interdental daily.", "side_effects": []}],
     "risks_if_untreated": ["Root canal or extraction", "Dental abscess — can spread to the face", "Cost escalates 10x"],
     "see_doctor_if": ["Facial swelling or fever with toothache = abscess, urgent", "Pain waking you at night"]},
    {"name": "Gingivitis", "category": "common", "severity": "mild",
     "summary": "Gum inflammation from plaque — red, puffy gums that bleed when brushed. Reversible.",
     "body_part": "throat", "recovery_days": "1-2 weeks", "tags": ["gums", "bleeding", "plaque"],
     "supplies": ["Interdental brushes", "Dental cleaning", "Chlorhexidine wash (short)"],
     "remedies": [
         {"name": "Brushing + interdental", "type": "habit", "how": "2 min 2x daily PLUS between teeth daily — bleeding gums improve in 1-2 weeks; bleeding is a reason to keep going, not stop.", "side_effects": []},
         {"name": "Professional clean", "type": "tool", "how": "Removes hardened plaque you cannot brush off.", "side_effects": []}],
     "risks_if_untreated": ["Periodontitis — permanent bone loss, loose teeth", "Links to heart disease and diabetes"],
     "see_doctor_if": ["Loose teeth, pus, receding gums — that's periodontitis"]},
    {"name": "Dry Eyes", "category": "common", "severity": "mild",
     "summary": "Tear film failing — gritty, tired, red eyes, worse with screens.",
     "body_part": "eyes", "recovery_days": "ongoing managed", "tags": ["screens", "gritty", "eyes"],
     "supplies": ["Preservative-free artificial tears", "Humidifier", "Warm compress"],
     "remedies": [
         {"name": "Artificial tears", "type": "medicine", "how": "Preservative-free drops 3-6x daily.", "side_effects": []},
         {"name": "20-20-20 rule", "type": "habit", "how": "Every 20 min, look 20 feet away for 20 s; blink fully.", "side_effects": []},
         {"name": "Lid warming", "type": "home", "how": "Warm compress 5 min daily for oil-gland function.", "side_effects": []}],
     "risks_if_untreated": ["Corneal surface damage", "Eye infections"],
     "see_doctor_if": ["Pain, light sensitivity, vision change"]},
    {"name": "Stye", "category": "common", "severity": "mild",
     "summary": "Blocked eyelid gland — tender red lump on the lid edge.",
     "body_part": "eyes", "recovery_days": "1-2 weeks", "tags": ["eyelid", "lump"],
     "supplies": ["Warm compress", "Clean cloth", "Lid wipes"],
     "remedies": [
         {"name": "Warm compress 4x daily", "type": "home", "how": "10 min, massage gently toward the lid edge. Most drain themselves.", "side_effects": []},
         {"name": "Do not squeeze", "type": "habit", "how": "Squeezing spreads infection; keep makeup/lens hygiene tight.", "side_effects": []}],
     "risks_if_untreated": ["Chalazion (hard lump)", "Lid cellulitis (rare)"],
     "see_doctor_if": ["Spreading redness to the whole lid or eye — needs antibiotics"]},
    {"name": "Motion Sickness", "category": "common", "severity": "mild",
     "summary": "Inner-ear/eye conflict — nausea, cold sweat, queasy misery on transport.",
     "body_part": "stomach", "recovery_days": "minutes after stopping", "tags": ["travel", "nausea", "car"],
     "supplies": ["Ginger", "Meclizine/dimenhydrinate", "Front seat / window"],
     "remedies": [
         {"name": "Horizon lock", "type": "habit", "how": "Look at the horizon, drive or ride front, no reading in cars.", "side_effects": []},
         {"name": "Antihistamine pre-dose", "type": "medicine", "how": "Dimenhydrinate 30-60 min BEFORE travel.", "side_effects": ["Drowsiness"]},
         {"name": "Ginger", "type": "food", "how": "Ginger tea/capsules — decent evidence for nausea.", "side_effects": []}],
     "risks_if_untreated": ["Dehydration from vomiting (rare)"],
     "see_doctor_if": ["Vomiting over 24 h", "New motion sickness as an adult — worth a check"]},
    {"name": "Sunburn", "category": "common", "severity": "mild",
     "summary": "UV radiation burn — red, hot, painful skin, peeling days later.",
     "body_part": "systemic", "recovery_days": "3-7 days", "tags": ["sun", "burn", "peeling"],
     "supplies": ["Aloe vera", "NSAID", "Water", "SPF 50 for after"],
     "remedies": [
         {"name": "Cool + aloe", "type": "home", "how": "Cool showers, aloe vera gel, loose clothing.", "side_effects": []},
         {"name": "NSAID early", "type": "medicine", "how": "Ibuprofen in the first 24 h cuts the inflammation response.", "side_effects": ["Stomach upset"]},
         {"name": "Hydrate", "type": "food", "how": "Sunburn pulls fluid to the skin — drink extra.", "side_effects": []}],
     "risks_if_untreated": ["Cumulative skin cancer risk", "Photoaging", "Blister infection"],
     "see_doctor_if": ["Blisters over a large area", "Fever, chills, confusion (sunstroke)"]},
    {"name": "Medigel Deficiency", "category": "fictional", "severity": "fictional",
     "summary": "Chronic lack of medi-gel — the universal galaxy-standard healing gel. Symptoms: unresolved plot wounds.",
     "body_part": "whole body", "recovery_days": "1 supply run", "tags": ["mass effect", "healing"],
     "supplies": ["Credits", "Nearest ter­minal", "Normandy infirmary access"],
     "remedies": [
         {"name": "Medigel application", "type": "fictional", "how": "Apply generously to wound; medi-gel does the rest.", "side_effects": ["Mild euphoria", "Blue glow"]}],
     "risks_if_untreated": ["Mission failure", "Dramatic slow-motion collapse"],
     "see_doctor_if": ["You are not actually in a video game"]},
    {"name": "Dark Zone Infection", "category": "fictional", "severity": "fictional",
     "summary": "Airborne VIRUS variant from the Dark Zone — green poison fog not included.",
     "body_part": "lungs", "recovery_days": "3 antivirus extractions", "tags": ["the division", "virus"],
     "supplies": ["Antivirus doses", "Mask filter", "Extraction flare"],
     "remedies": [
         {"name": "Antivirus booster", "type": "fictional", "how": "Inject every 60 s of exposure; craft from receptors.", "side_effects": ["Vision static"]}],
     "risks_if_untreated": ["Turn hostile — permanently", "Loss of loot"],
     "see_doctor_if": ["Real-world fever — see a real doctor, agent"]},
]


# ── page template (plain string + __TOKENS__, same style as the medical bay) ─
def _template(entries: list[dict]) -> str:
    cards_js = json.dumps(entries, ensure_ascii=False).replace("</", "<\\/")
    stamp = _esc(time.strftime("%d %b %Y · %H:%M"))
    return _LIB_TPL.replace("__CARDS__", cards_js).replace("__STAMP__", stamp) \
                   .replace("__COUNT__", str(len(entries)))


_LIB_TPL = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>STARK MEDICAL BAY · DISEASE INDEX</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#00070c; color:#aef4ff; min-height:100vh;
    font-family:"Consolas","Cascadia Mono",monospace; padding:22px 28px 52px;
    overflow-y:auto; }
  ::-webkit-scrollbar { width:8px; }
  ::-webkit-scrollbar-thumb { background:rgba(0,212,255,.35); border-radius:4px; }
  ::-webkit-scrollbar-track { background:rgba(0,20,30,.4); }
  #stars { position:fixed; inset:0; z-index:0; }
  .scanlines { position:fixed; inset:0; z-index:5; pointer-events:none; opacity:.5;
    background:repeating-linear-gradient(0deg, rgba(0,229,255,.028) 0 1px, transparent 1px 3px); }
  .vignette { position:fixed; inset:0; z-index:5; pointer-events:none;
    background:radial-gradient(ellipse at center, transparent 55%, rgba(0,4,8,.78) 100%); }
  .wrap { position:relative; z-index:2; max-width:1500px; margin:0 auto; }

  header { display:flex; justify-content:space-between; align-items:flex-end; gap:16px;
    border-bottom:1px solid rgba(0,212,255,.28); padding-bottom:12px; }
  .kicker { font-size:11px; letter-spacing:.35em; color:#5fd6e8; }
  h1 { font-size:clamp(20px,3vw,32px); letter-spacing:.14em; color:#00e5ff; margin-top:6px;
    text-shadow:0 0 18px rgba(0,212,255,.55); }
  .h-right { text-align:right; font-size:11px; color:#4cc3d6; letter-spacing:.12em; line-height:1.8; }

  .bar { display:flex; gap:12px; margin:16px 0 6px; flex-wrap:wrap; align-items:center; }
  #q { flex:1; min-width:260px; background:rgba(0,16,26,.8); border:1px solid rgba(0,212,255,.4);
    color:#eafcff; font:inherit; font-size:13px; letter-spacing:.08em; padding:10px 14px; outline:none; }
  #q:focus { border-color:#00e5ff; box-shadow:0 0 14px rgba(0,212,255,.25); }
  .chip { font-size:10.5px; letter-spacing:.22em; padding:9px 14px; cursor:pointer; user-select:none;
    border:1px solid rgba(0,212,255,.35); color:#7fdcec; background:rgba(0,16,26,.6); }
  .chip.on { color:#000; background:#00e5ff; border-color:#00e5ff; font-weight:bold;
    box-shadow:0 0 16px rgba(0,212,255,.5); }

  #grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(320px,1fr)); gap:14px; margin-top:14px; }
  .card { border:1px solid rgba(0,212,255,.28); background:rgba(0,16,26,.66);
    box-shadow:inset 0 0 24px rgba(0,212,255,.04); padding:14px 16px; cursor:pointer;
    position:relative; overflow:hidden; opacity:0; transform:translateY(14px);
    transition:transform .18s, box-shadow .18s, border-color .18s; }
  .card.in { animation:cardIn .45s cubic-bezier(.2,.8,.2,1) forwards; }
  @keyframes cardIn { to { opacity:1; transform:none; } }
  .card:hover { transform:translateY(-3px); border-color:#00e5ff;
    box-shadow:0 0 22px rgba(0,212,255,.22), inset 0 0 24px rgba(0,212,255,.07); }
  .card::before { content:""; position:absolute; top:0; left:0; width:22px; height:22px;
    border-top:2px solid #00e5ff; border-left:2px solid #00e5ff; opacity:.7; }
  .c-top { display:flex; align-items:baseline; gap:8px; }
  .c-name { font-size:14.5px; color:#eafcff; letter-spacing:.06em; }
  .c-sev { margin-left:auto; font-size:9px; letter-spacing:.2em; padding:2px 8px; border:1px solid; }
  .c-sum { font-size:12px; color:#8fdcec; line-height:1.55; margin-top:8px; min-height:34px; }
  .c-meta { display:flex; gap:14px; font-size:10px; letter-spacing:.14em; color:#4cc3d6; margin-top:8px; flex-wrap:wrap; }
  .c-go { margin-top:10px; font-size:10.5px; letter-spacing:.24em; color:#ff6a3d; }
  .card:hover .c-go { text-shadow:0 0 10px rgba(255,106,61,.8); }
  .none { color:#4cc3d6; padding:30px 0; text-align:center; letter-spacing:.2em; display:none; }

  footer { position:fixed; left:0; right:0; bottom:0; z-index:6; display:flex; justify-content:space-between;
    padding:7px 28px; font-size:10px; letter-spacing:.22em; color:#3fa9bc;
    border-top:1px solid rgba(0,212,255,.18); background:rgba(0,8,12,.8); }
  footer .warn { color:#ff8d9f; }
</style>
</head>
<body>
<canvas id="stars"></canvas>
<div class="scanlines"></div><div class="vignette"></div>
<div class="wrap">
  <header>
    <div>
      <div class="kicker">STARK MEDICAL BAY · KNOWLEDGE CORE</div>
      <h1>DISEASE INDEX</h1>
    </div>
    <div class="h-right">
      ENTRIES: __COUNT__<br>INDEX SYNC: __STAMP__<br>
      SELECT A CONDITION → REDIRECT TO MEDICAL BAY
    </div>
  </header>

  <div class="bar">
    <input id="q" type="text" placeholder="▸ SEARCH CONDITION, SYMPTOM, TAG…" autofocus>
    <span class="chip on" data-c="all">ALL</span>
    <span class="chip" data-c="infection">INFECTIONS</span>
    <span class="chip" data-c="common">COMMON</span>
    <span class="chip" data-c="chronic">CHRONIC</span>
    <span class="chip" data-c="deficiency">DEFICIENCY</span>
    <span class="chip" data-c="mental">MENTAL</span>
    <span class="chip" data-c="fictional">FICTIONAL</span>
  </div>

  <div id="grid"></div>
  <div class="none" id="empty">▸ NO CONDITIONS MATCH — TRY ANOTHER SEARCH</div>
</div>
<footer>
  <span>MEDICAL BAY ARCHIVE · STARK INDUSTRIES</span>
  <span class="warn">▸ EDUCATIONAL DISPLAY — NOT MEDICAL ADVICE.</span>
  <span id="clock"></span>
</footer>

<script>
const CARDS = __CARDS__;
const SEV = {mild:"#37ffb5", moderate:"#ffd23d", serious:"#ff3d5a", fictional:"#ff5ad6"};
const SEVL = {mild:"LOW", moderate:"ELEVATED", serious:"HIGH", fictional:"ANOMALOUS"};

const grid = document.getElementById('grid');
const empty = document.getElementById('empty');
let cat = 'all', query = '';

function render () {
  grid.innerHTML = '';
  const list = CARDS.filter(c => {
    if (cat !== 'all' && c.category !== cat) return false;
    if (!query) return true;
    const hay = (c.name + ' ' + c.summary + ' ' + c.tags.join(' ') + ' ' + c.body_part).toLowerCase();
    return hay.includes(query);
  });
  empty.style.display = list.length ? 'none' : 'block';
  list.forEach((c, i) => {
    const el = document.createElement('div');
    el.className = 'card';
    const col = SEV[c.severity] || SEV.moderate;
    el.innerHTML =
      '<div class="c-top"><span class="c-name"></span>' +
      '<span class="c-sev" style="color:' + col + ';border-color:' + col + ';">' +
      (SEVL[c.severity] || c.severity.toUpperCase()) + ' · ' + c.category.toUpperCase() + '</span></div>' +
      '<div class="c-sum"></div>' +
      '<div class="c-meta"><span>▸ ' + c.body_part.toUpperCase() + '</span>' +
      '<span>⏱ ' + c.recovery + '</span><span>✚ ' + c.remedies + ' REMEDIES</span></div>' +
      '<div class="c-go">▸ OPEN IN MEDICAL BAY ▸</div>';
    el.querySelector('.c-name').textContent = c.name;
    el.querySelector('.c-sum').textContent = c.summary;
    el.onclick = () => { location.href = 'diag_' + c.slug + '.html'; };
    grid.appendChild(el);
    setTimeout(() => el.classList.add('in'), 40 + i * 55);
  });
}

document.getElementById('q').addEventListener('input', e => {
  query = e.target.value.trim().toLowerCase(); render();
});
document.querySelectorAll('.chip').forEach(ch => ch.onclick = () => {
  document.querySelectorAll('.chip').forEach(x => x.classList.remove('on'));
  ch.classList.add('on'); cat = ch.dataset.c; render();
});
render();

/* starfield */
(function () {
  const c = document.getElementById('stars'), x = c.getContext('2d');
  let W, H, pts = [];
  function size () {
    W = c.width = innerWidth; H = c.height = innerHeight;
    pts = Array.from({length: 90}, () => ({
      x: Math.random() * W, y: Math.random() * H,
      s: Math.random() * 1.6 + .4, v: Math.random() * .25 + .05,
      tw: Math.random() * Math.PI * 2 }));
  }
  addEventListener('resize', size); size();
  // 30 fps cap + hidden-tab pause — a drifting starfield needs no more.
  let lastStar = 0, sT = 0;
  (function draw (t) {
    requestAnimationFrame(draw);
    t = t || performance.now();
    if (document.hidden) return;
    if (t - lastStar < 33) return;
    lastStar = t; sT += 33;
    x.clearRect(0, 0, W, H);
    for (const p of pts) {
      p.y -= p.v; if (p.y < -4) { p.y = H + 4; p.x = Math.random() * W; }
      x.fillStyle = 'rgba(0,212,255,' + (.25 + .55 * Math.abs(Math.sin(sT / 900 + p.tw))).toFixed(3) + ')';
      x.fillRect(p.x, p.y, p.s, p.s);
    }
  })(0);
})();

setInterval(() => {
  document.getElementById('clock').textContent =
    new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'});
}, 1000);
</script>
</body>
</html>
"""


if __name__ == "__main__":
    handler()
