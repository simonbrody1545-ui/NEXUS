"""
self_improve — JARVIS improves his own code.

Flow (safety-first):
  1. READ the target module from actions/ (or core/, plugins/ — allowlist).
  2. ASK the second brain (Groq/OpenAI/Anthropic via plugins.second_brain)
     for a focused improvement patch, given the file's source.
  3. EXTRACT the first ```python block from the reply.
  4. SANDBOX: write it to a temp copy, py_compile it, import it — must be
     identical-tool-surface (TOOL name kept for actions) and compile clean.
  5. APPLY only if the sandbox passes: back up the original to .bak first.
  6. report — the change lands on disk next restart of that module's loader.

Destructive ops (delete/redo) are refused. mode=list shows improvable files.
mode=rollback restores the most recent .bak for a file.
"""
from __future__ import annotations

import importlib.util
import py_compile
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
SCAN_DIRS = ("actions", "core", "plugins")          # the improvable surface
BLOCK_SUFFIX = (".py",)
DENY = ("main.py", "ui.py", "main_bridge.py",       # live-session criticals
        "config", "state", "memory", "dashboard")
MAX_SRC = 24_000          # chars of source sent to the AI
_bak_ts: dict[str, str] = {}


def _candidate_files() -> list[Path]:
    out: list[Path] = []
    for d in SCAN_DIRS:
        p = BASE / d
        if not p.is_dir():
            continue
        for f in sorted(p.glob("*.py")):
            if f.name.startswith("_") or f.name in DENY:
                continue
            out.append(f)
    return out


def _sandbox_ok(code: str) -> tuple[bool, str]:
    """Compile + import a proposed module in isolation. Returns (ok, msg)."""
    try:
        with tempfile.TemporaryDirectory() as td:
            f = Path(td) / "candidate.py"
            f.write_text(code, encoding="utf-8")
            py_compile.compile(str(f), doraise=True)
            spec = importlib.util.spec_from_file_location(
                f"_si_candidate_{int(time.time())}", str(f))
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return True, "sandbox import clean"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"[:200]


def _ai_patch(src: str, goal: str) -> str:
    """Ask the second brain for a full improved module. Returns raw reply."""
    try:
        from plugins.second_brain import _execute_second_brain
    except Exception as e:
        return f"second brain unavailable: {e}"
    prompt = (
        "You are improving JARVIS's own Python module. Improve clarity, "
        "robustness and performance while PRESERVING every public name, "
        "behaviour and TOOL contract exactly. Do not rename anything, do not "
        "remove features, do not change print/log strings' meaning. "
        f"GOAL: {goal}\n\n"
        "Reply with the complete improved file in ONE ```python code block, "
        "nothing else.\n\nCURRENT SOURCE:\n```python\n"
        + src[:MAX_SRC] + "\n```")
    reply, _prov, _model = _execute_second_brain(prompt)
    return reply or ""


def _extract_code(reply: str) -> str:
    m = re.search(r"```python\s*(.+?)```", reply, re.S | re.I)
    if m:
        return m.group(1).strip() + "\n"
    m = re.search(r"```\s*(.+?)```", reply, re.S)
    return (m.group(1).strip() + "\n") if m else ""


def self_improve(params: dict = None, **_ctx) -> str:
    p = params or {}
    mode = str(p.get("mode") or "improve").lower().strip()
    target = str(p.get("target") or "").strip()
    goal = str(p.get("goal") or "general robustness and clarity").strip()

    if mode == "list":
        files = _candidate_files()
        return ("Improvable modules (pass target=<name>.py):\n"
                + "\n".join(f"- {f.parent.name}/{f.name}" for f in files[:40])
                + f"\n({len(files)} total; criticals excluded)")

    if not target:
        return "Give me a target file, e.g. target=web_forge.py (mode=list to see all)."
    target = Path(target).name                      # no traversal
    if target in DENY:
        return f"Refused: {target} is mission-critical and stays out of my reach."

    path = None
    for d in SCAN_DIRS:
        cand = BASE / d / target
        if cand.is_file():
            path = cand
            break
    if path is None:
        return f"Unknown target: {target} — mode=list shows what I can touch."

    if mode == "rollback":
        bak = path.with_suffix(path.suffix + ".bak")
        if not bak.is_file():
            return f"No backup exists for {target} — nothing to roll back."
        shutil.copy2(bak, path)
        return f"Rolled back {target} to its last backup."

    src = path.read_text(encoding="utf-8", errors="replace")
    reply = _ai_patch(src, goal)
    if not reply:
        return "The second brain returned nothing — no patch made."
    code = _extract_code(reply)
    if not code or len(code) < len(src) * 0.3:
        return ("The proposed patch does not look like a full module — "
                "refusing to apply an incomplete file.")

    ok, msg = _sandbox_ok(code)
    if not ok:
        return (f"Patch FAILED the sandbox ({msg}) — your live file is "
                "untouched. Try a narrower goal.")

    # keep the TOOL contract when improving an action/plugin module
    if "TOOL = {" in src and "TOOL = {" not in code:
        return "Patch dropped the TOOL contract — refusing to apply."

    bak = path.with_suffix(path.suffix + ".bak")
    shutil.copy2(path, bak)
    path.write_text(code, encoding="utf-8")
    _bak_ts[str(path)] = str(int(time.time()))
    return (f"Improved {path.parent.name}/{target}: sandbox-verified ({msg}), "
            f"backup at {bak.name}. It takes effect next time that module "
            f"loads — say 'rollback {target}' to revert.")


TOOL = {
    "name": "self_improve",
    "description": (
        "Improve your own code. Use when sir says 'improve your code', "
        "'optimize yourself', 'make yourself better' or asks what you can "
        "improve. Modes: list (show improvable modules), improve (default — "
        "analyze target with the second brain, sandbox-verify the patch, then "
        "apply with a backup), rollback (restore target's .bak). Mission-"
        "critical files are refused; every patch must pass a sandbox import "
        "or it is never applied."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "mode":   {"type": "STRING",
                       "description": "list | improve (default) | rollback"},
            "target": {"type": "STRING",
                       "description": "File to improve, e.g. 'web_forge.py'"},
            "goal":   {"type": "STRING",
                       "description": "What to improve: robustness, speed, clarity…"},
        },
        "required": [],
    },
    "handler": self_improve,
}
