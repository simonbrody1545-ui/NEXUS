"""Process manager — see what is running, end what must not be.

"what's using my cpu" → top processes by CPU/RAM, honest names.
"end the process 4124" / "kill chrome" → termination behind the on-screen
confirmation gate (core.confirm) — ending a process can lose unsaved work,
so the user confirms exactly which name dies.
"""
from __future__ import annotations


def run(parameters: dict, **_ctx) -> str:
    action = (parameters.get("action") or "list").strip().lower()

    if action == "list":
        import psutil
        rows = []
        for pr in psutil.process_iter(["pid", "name", "cpu_percent",
                                       "memory_percent"]):
            try:
                rows.append((pr.info["cpu_percent"] or 0.0,
                             pr.info["memory_percent"] or 0.0,
                             pr.info["pid"], pr.info["name"] or "?"))
            except Exception:
                continue
        rows.sort(reverse=True)
        top = rows[:8]
        lines = [f"{p:>6}  {c:4.0f}% cpu {m:4.1f}% mem  {n[:36]}"
                 for c, m, p, n in top]
        return "Top processes:\n" + "\n".join(lines)

    if action in ("kill", "end", "terminate"):
        target = (parameters.get("target") or "").strip()
        if not target:
            return "I need a PID or an exact process name, sir."
        import psutil
        victims = []
        if target.isdigit():
            victims = [p for p in [psutil.Process(int(target))]
                       if p.is_running()] if _exists(target) else []
        else:
            for pr in psutil.process_iter(["name"]):
                try:
                    if (pr.info["name"] or "").lower() == target.lower():
                        victims.append(pr)
                except Exception:
                    continue
        if not victims:
            return f"No process called '{target}' is running."

        def _do() -> str:
            done, failed = 0, 0
            for pr in victims:
                try:
                    pr.terminate()
                    done += 1
                except Exception:
                    failed += 1
            return (f"Terminated {done} process(es)"
                    + (f", {failed} refused" if failed else "") + ".")

        from core import confirm
        return confirm.request(
            f"kill-process-{target}",
            f"END PROCESS — {target}",
            ("This force-closes: "
             + ", ".join(f"{p.pid} {p.info.get('name', '?')}" for p in victims[:4])
             + ". Unsaved work in it is lost."),
            _do,
        )

    return "Unknown action — use list or kill."


def _exists(pid: str) -> bool:
    try:
        import psutil
        psutil.Process(int(pid))
        return True
    except Exception:
        return False


TOOL = {
    "name": "process_manager",
    "description": (
        "List the heaviest running processes (cpu/ram) or end one. 'what is "
        "using my cpu', 'end process 4124', 'kill chrome'. Killing goes "
        "through the on-screen confirmation — never claim it is done."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING", "description": "list | kill"},
            "target": {"type": "STRING",
                       "description": "PID or exact process name (kill only)."},
        },
        "required": [],
    },
    "handler": run,
}
