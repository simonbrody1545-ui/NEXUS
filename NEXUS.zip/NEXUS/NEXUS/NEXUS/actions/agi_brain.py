"""A.G.I. brain tool — the model's handle on its literal thinking storage.

Follows the action_loader contract: a single module-level TOOL whose handler is
invoked with only the parameters it declares. Returns readable strings — they
go straight back to the model as the tool response.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core import agi_brain as brain   # noqa: E402


def _fmt_recall(mem: list) -> str:
    if not mem:
        return "Brain recall: nothing matched. (Store it with action=remember if it matters.)"
    lines = [f"- {m.get('text')}" for m in mem]
    return f"Brain recall ({len(mem)}):\n" + "\n".join(lines)


def agi_brain(parameters: dict = None, **_ctx) -> str:
    """Handler — the loader passes the model's arguments as ``parameters``.
    action: think | remember | recall | status."""
    p = parameters or {}
    a = str(p.get("action") or "").strip().lower()
    text = str(p.get("text") or "")
    query = str(p.get("query") or "")
    tags = str(p.get("tags") or "")
    limit = p.get("limit") or 8

    if a == "think":
        r = brain.think(text)
        return ("Thought stored in the brain." if r.get("ok")
                else f"Think failed: {r.get('error', 'unknown')}")

    if a == "remember":
        tag_list = [t.strip() for t in tags.split(",") if t.strip()]
        r = brain.remember(text, tags=tag_list)
        if not r.get("ok"):
            return f"Remember failed: {r.get('error', 'unknown')}"
        if r.get("deduped"):
            return f"Already in the brain — refreshed: {r.get('text')}"
        return f"Remembered for good: {r.get('text')}"

    if a == "recall":
        return _fmt_recall(brain.recall(query, limit=limit))

    if a == "status":
        s = brain.status()
        return (f"Brain: {s['memories']} durable memories, "
                f"{s['thoughts']} logged thoughts ({s['dir']}).")

    return "agi_brain: unknown action — use think | remember | recall | status."


TOOL = {
    "name": "agi_brain",
    "description": (
        "Your persistent brain — literal thinking storage that survives "
        "restarts. Use action=remember to store durable facts about the user "
        "and his world (preferences, projects, people, promises). Use "
        "action=think to record private reasoning, plans and observations. "
        "Use action=recall to search your memories BEFORE answering anything "
        "about past interactions. Use action=status to see how much you hold."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "think | remember | recall | status",
            },
            "text": {
                "type": "STRING",
                "description": "The thought (action=think) or durable fact (action=remember)",
            },
            "query": {
                "type": "STRING",
                "description": "What to search the brain for (action=recall)",
            },
            "tags": {
                "type": "STRING",
                "description": "Optional comma-separated tags for action=remember (e.g. 'sir, project, preference')",
            },
            "limit": {
                "type": "INTEGER",
                "description": "Max results for action=recall (default 8)",
            },
        },
        "required": ["action"],
    },
    "handler": agi_brain,
}
