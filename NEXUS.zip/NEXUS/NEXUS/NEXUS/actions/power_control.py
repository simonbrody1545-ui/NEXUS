"""Power control — sleep, hibernate, battery report, screen lock.

"put the pc to sleep" → real OS sleep (rundll32 on Windows, pmset/-.  Reversible
by the user pressing the power button — which is why this needs no gate.
"how much battery" → instant, honest readout incl. whether it's charging.
"""
from __future__ import annotations

import platform

_OS = platform.system()


def _battery_line() -> str | None:
    try:
        import psutil
        b = psutil.sensors_battery()
        if b is None:
            return None
        pct = round(b.percent)
        state = "charging" if b.power_plugged else "on battery"
        eta = ""
        if not b.power_plugged and b.secsleft and 0 < b.secsleft < 86400:
            h, m = divmod(int(b.secsleft) // 60, 60)
            eta = f", about {h}h {m:02d}m left"
        return f"{pct} per cent, {state}{eta}"
    except Exception:
        return None


def run(parameters: dict, **_ctx) -> str:
    action = (parameters.get("action") or "status").strip().lower()

    if action in ("battery", "status"):
        line = _battery_line()
        if line:
            return f"Battery is at {line}."
        return ("This machine reports no battery — it runs on mains power. "
                "Desktop, or a battery the system refuses to describe.")

    if action == "sleep":
        try:
            if _OS == "Windows":
                import subprocess
                subprocess.Popen(["rundll32.exe", "powrprof.dll,SetSuspendState",
                                  "0,1,0"], creationflags=0x08000000)
            elif _OS == "Darwin":
                import subprocess
                subprocess.Popen(["pmset", "sleepnow"])
            else:
                import subprocess
                for cmd in (["systemctl", "suspend"], ["loginctl", "suspend"]):
                    if subprocess.run(cmd, capture_output=True).returncode == 0:
                        break
            return ("Sleeping now. Press the power button when you need me "
                    "again, sir.")
        except Exception as e:
            return f"Sleep failed: {e}"

    if action == "hibernate":
        try:
            if _OS == "Windows":
                import subprocess
                r = subprocess.run(["shutdown", "/h"], capture_output=True)
                if r.returncode != 0:
                    return ("Hibernate is not enabled on this machine "
                            "(powercfg /hibernate on, run once as admin).")
                return "Hibernating. Everything will be here when you return."
            return "Hibernation is a Windows trick on this platform, sir."
        except Exception as e:
            return f"Hibernate failed: {e}"

    if action == "lock":
        try:
            if _OS == "Windows":
                import ctypes
                ctypes.windll.user32.LockWorkStation()
                return "Locked, sir."
            import subprocess
            for cmd in (["gnome-screensaver-command", "-l"],
                        ["loginctl", "lock-session"],
                        ["pmset", "displaysleepnow"]):
                if subprocess.run(cmd, capture_output=True).returncode == 0:
                    return "Locked, sir."
            return "Lock unavailable on this platform."
        except Exception as e:
            return f"Lock failed: {e}"

    return f"Unknown power action '{action}' — use status, sleep, hibernate or lock."


TOOL = {
    "name": "power_control",
    "description": (
        "Battery report, and power actions: 'how much battery', 'put the pc "
        "to sleep', 'hibernate', 'lock the screen'. Sleep/hibernate/lock act "
        "immediately (reversible by the user); restart/shutdown live in "
        "computer_settings behind the confirmation gate instead."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING",
                       "description": "status | sleep | hibernate | lock"},
        },
        "required": [],
    },
    "handler": run,
}
