"""
Nexus link registry — voice-manage what orbits the NEXUS grid.

The graph server owns state/nexus_links.json; these tools edit it through the
same file (or the server's HTTP API when it is up), so a node added by voice
appears the next time the graph is built, and 'spread your roots' shows it.
"""
from __future__ import annotations

import json
import re
import urllib.request
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
LINKS_PATH = BASE_DIR / "state" / "nexus_links.json"
NEXUS_API = "http://127.0.0.1:5000"

_KINDS = ("web", "ai", "dashboard", "forge", "service")


def _slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", str(name).strip().lower()).strip("-")
    return s or "node"


def _post(route: str, body: dict) -> dict | None:
    try:
        req = urllib.request.Request(
            NEXUS_API + route, data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json"})
        return json.loads(urllib.request.urlopen(req, timeout=2).read())
    except Exception:
        return None


def _read_links() -> list[dict]:
    try:
        raw = json.loads(LINKS_PATH.read_text(encoding="utf-8"))
        return raw if isinstance(raw, list) else []
    except Exception:
        return []


def _write_links(links: list[dict]) -> None:
    try:
        LINKS_PATH.parent.mkdir(parents=True, exist_ok=True)
        LINKS_PATH.write_text(json.dumps(links, indent=2), encoding="utf-8")
    except OSError:
        pass


def add_website(parameters=None, **_) -> str:
    p = parameters or {}
    name = str(p.get("name") or "").strip()
    url  = str(p.get("url") or "").strip()
    kind = str(p.get("kind") or "web").strip().lower()
    if not name or not url:
        return "I need both a name and an address to bind a link."
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "https://" + url
    if kind not in _KINDS:
        kind = "web"
    body = {"name": name, "url": url, "kind": kind}
    via_api = _post("/api/link/add", body)
    if not (via_api and via_api.get("ok")):
        links = [l for l in _read_links() if l.get("id") != _slug(name)]
        links.append({"id": _slug(name), "name": name, "url": url, "kind": kind,
                      "added_at": __import__("time").time()})
        _write_links(links)
    return (f"'{name}' is bound into the Nexus ({kind}). Say 'spread your roots' "
            f"and it will be in orbit, sir.")


def remove_website(parameters=None, **_) -> str:
    name = str((parameters or {}).get("name") or "").strip()
    if not name:
        return "Which node should I sever?"
    via_api = _post("/api/link/remove", {"name": name})
    if via_api and via_api.get("ok"):
        return f"'{name}' severed from the Nexus, sir."
    links = _read_links()
    kept = [l for l in links if l.get("id") != _slug(name)]
    if len(kept) == len(links):
        known = ", ".join(sorted(l.get("name", "?") for l in links)[:12]) or "none"
        return f"No node named '{name}'. Currently bound: {known}."
    _write_links(kept)
    return f"'{name}' severed from the Nexus, sir."


def list_websites(parameters=None, **_) -> str:
    links = _read_links()
    if not links:
        return "The Nexus is empty — name a site and I will bind it."
    rows = [f"• {l.get('name','?')} — {l.get('url','')} ({l.get('kind','web')})"
            for l in links]
    return f"{len(links)} link(s) on the Nexus:\n" + "\n".join(rows)


def manage_nexus(parameters=None, **_) -> str:
    action = str((parameters or {}).get("action") or "list").strip().lower()
    if action in ("add", "connect", "track"):
        return add_website(parameters)
    if action in ("remove", "sever", "disconnect"):
        return remove_website(parameters)
    return list_websites(parameters)


TOOL = {
    "name": "manage_nexus",
    "description": (
        "Add, remove, or list the nodes of the NEXUS grid — the orbital map of "
        "every website, AI service and dashboard JARVIS is connected to (say "
        "'spread your roots' to see it). action='add' when the user says 'add my "
        "website to the nexus' / 'connect myshop.com' / 'track this site'. "
        "action='remove' when they say 'remove my website from the nexus' / "
        "'disconnect that site'. action='list' when they ask 'what's on my "
        "nexus', 'what are you connected to'."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {"type": "STRING",
                       "description": "add | remove | list"},
            "name":   {"type": "STRING",
                       "description": "Display name (e.g. 'My Business Site') — required for add/remove"},
            "url":    {"type": "STRING",
                       "description": "Address (e.g. myshop.com — https:// added automatically) — required for add"},
            "kind":   {"type": "STRING",
                       "description": "web | ai | dashboard | service. Default: web"},
        },
        "required": ["action"],
    },
    "handler": manage_nexus,
}
