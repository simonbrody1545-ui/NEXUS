"""IP trace — a public-records lookup, nothing more.

"trace 8.8.8.8" / "track this ip 1.2.3.4" → city/region/country/ISP/timezone
the way any lookup site shows it. Uses the free ip-api.com endpoint (no key,
45 req/min). It answers from public routing records — it does NOT access any
device, and it cannot see a person. Precision is deliberately city-level:
that is what the data offers, and street-level would be a lie anyway.
A bare "trace" with no argument reports THIS machine's public IP's record.
"""
from __future__ import annotations

import json
import socket
import urllib.request

_API = "http://ip-api.com/json/{q}?fields=status,message,country,regionName,city,zip,lat,lon,timezone,isp,org,as,query"


def _lookup(query: str) -> dict:
    url = _API.format(q=query)
    req = urllib.request.Request(url, headers={"User-Agent": "JARVIS/1.0"})
    with urllib.request.urlopen(req, timeout=8) as r:
        return json.loads(r.read().decode("utf-8"))


def _fmt(d: dict) -> str:
    if d.get("status") != "success":
        return f"Lookup failed: {d.get('message', 'unknown reason')}"
    bits = [d.get("query", "?")]
    loc = ", ".join(x for x in (d.get("city"), d.get("regionName"),
                                d.get("country")) if x)
    if loc:
        bits.append(loc)
    if d.get("isp"):
        bits.append(f"ISP {d['isp']}")
    if d.get("org") and d.get("org") != d.get("isp"):
        bits.append(f"org {d['org']}")
    if d.get("timezone"):
        bits.append(d["timezone"])
    return " — ".join(bits)


def run(parameters: dict, **_ctx) -> str:
    q = (parameters.get("ip") or parameters.get("query") or "").strip()
    if not q:
        # No target given: this machine's public address, same public record.
        try:
            q = json.loads(urllib.request.urlopen(
                "https://api.ipify.org", timeout=6).read().decode()) or ""
        except Exception:
            return ("I need an address to trace, sir — give me the IP, "
                    "or a domain name and I will resolve it first.")
    if not q.replace(".", "").replace(":", "").isalnum() and " " not in q:
        # A domain name — resolve it, then trace where it points.
        try:
            q = socket.gethostbyname(q)
        except Exception as e:
            return f"Could not resolve that name: {e}"
    try:
        return _fmt(_lookup(q))
    except Exception as e:
        return f"Trace unavailable right now: {e}"


TOOL = {
    "name": "ip_trace",
    "description": (
        "Trace an IP address or domain: city/region/country, ISP, timezone — "
        "from public routing records. 'trace 8.8.8.8', 'where is this ip "
        "1.2.3.4', or no argument = this machine's own public IP. City-level "
        "precision only; it never accesses any device or person."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "ip": {"type": "STRING",
                   "description": "IPv4/IPv6 address or domain. Empty = own public IP."},
        },
        "required": [],
    },
    "handler": run,
}
