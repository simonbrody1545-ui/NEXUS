"""JARVIS's own storage — a private vault the assistant reads and writes itself.

Everything lands under  state/storage/  (created on first use). JARVIS can
stash notes, research dumps, formulas, checkpoints — and read them back by
name or list what it has. Files are plain text so the user can inspect them
too; this is transparency, not hiding.

Actions: save | read | list | delete | append
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
ROOT     = BASE_DIR / "state" / "storage"


def _resolve(filename: str) -> Path | None:
    """Flat names only, inside the vault — no escapes."""
    f = (filename or "").strip().replace("\\", "/").split("/")[-1]
    if not f or f in (".", ".."):
        return None
    return ROOT / f


def run(parameters: dict = None, response=None, player=None, **_) -> str:
    params = parameters or {}
    action = (params.get("action") or "").lower().strip() or "save"
    fname  = (params.get("filename") or params.get("name") or "").strip()

    try:
        if action == "save":
            p = _resolve(fname)
            if p is None:
                return "Give the file a name, sir — e.g. 'web-fluid-research.md'."
            content = params.get("content") or ""
            ROOT.mkdir(parents=True, exist_ok=True)
            header = "" if p.exists() else (
                f"# saved by JARVIS — {datetime.now():%Y-%m-%d %H:%M}\n\n")
            p.write_text(header + content, encoding="utf-8")
            return f"Stored {len(content)} characters in storage as '{p.name}'."

        if action == "append":
            p = _resolve(fname)
            if p is None:
                return "Name the file to append to, sir."
            ROOT.mkdir(parents=True, exist_ok=True)
            with open(p, "a", encoding="utf-8") as fh:
                fh.write(("\n" if p.exists() and p.stat().st_size else "")
                         + (params.get("content") or ""))
            return f"Appended to '{p.name}' — now {p.stat().st_size} bytes."

        if action == "read":
            p = _resolve(fname)
            if p is None or not p.exists():
                return f"Nothing called '{fname}' in storage."
            text = p.read_text(encoding="utf-8", errors="replace")
            if len(text) > 6000:
                text = text[:6000] + f"\n… ({len(text)} chars total, truncated)"
            return f"Contents of {p.name}:\n{text}"

        if action == "list":
            if not ROOT.exists():
                return "Storage is empty — nothing saved yet."
            files = sorted(ROOT.iterdir(), key=lambda x: x.stat().st_mtime,
                           reverse=True)
            files = [f for f in files if f.is_file()]
            if not files:
                return "Storage is empty — nothing saved yet."
            lines = [f"  📄 {f.name}  ({f.stat().st_size} B)" for f in files[:15]]
            return f"{len(files)} file(s) in storage:\n" + "\n".join(lines)

        if action == "delete":
            p = _resolve(fname)
            if p is None or not p.exists():
                return f"Nothing called '{fname}' to delete."
            p.unlink()
            return f"Deleted '{p.name}' from storage."

        return f"Unknown storage action '{action}' (save | read | list | delete | append)."
    except Exception as e:
        return f"Storage error: {e}"


TOOL = {
    "name": "own_storage",
    "description": (
        "JARVIS's private storage vault — save notes, research, formulas or any "
        "text for later ('save that in storage as web-fluid-notes'), read a file "
        "back ('read my web-fluid notes'), append, list everything stored, or "
        "delete. Persists across restarts under state/storage/."),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action":   {"type": "STRING",
                         "description": "save | read | append | list | delete"},
            "filename": {"type": "STRING", "description": "File name in the vault"},
            "content":  {"type": "STRING",
                         "description": "Text content (save/append)"},
        },
        "required": [],
    },
    "handler": run,
}
