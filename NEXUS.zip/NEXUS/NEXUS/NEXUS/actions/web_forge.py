"""
web_forge — THE FORGE: builds ANYTHING.

Websites, HTML5 games, desktop apps, CLI tools, bots, API servers,
automations, data analyses, documents — detected from the request, built by
the free AIs (Groq / OpenRouter / OpenAI / Gemini), sandbox-verified when
Python, written under ~/Documents/JARVISForge, registered into The Inside as
a FORGED world, and optionally launched.

Multi-file protocol: builders may emit several files, each introduced by a
`### FILE: relative/path` header followed by one fenced code block. Single-
artifact kinds (website / game / doc) are one self-contained block.
"""
from __future__ import annotations

import json
import py_compile
import re
import subprocess
import sys
import tempfile
import urllib.request
import webbrowser
from pathlib import Path

try:
    import requests
    _HAVE_REQUESTS = True
except Exception:
    _HAVE_REQUESTS = False

BASE_DIR  = Path(__file__).resolve().parent.parent
CONFIG    = BASE_DIR / "config" / "api_keys.json"
FORGE_DIR = Path.home() / "Documents" / "JARVISForge"

GROQ_MODEL    = "llama-3.3-70b-versatile"
OR_FREE_MODEL = "meta-llama/llama-3.3-70b-instruct:free"

_SYSTEM = (
    "You are THE FORGE — JARVIS's master builder. You output COMPLETE, "
    "RUNNABLE builds: no placeholders, no TODOs, no truncation, no snippets. "
    "Every feature the user asks for must actually work. For visual work, "
    "craft a striking, polished result; for code, handle errors and edge "
    "cases. Prefer zero-dependency standard-library Python so builds run "
    "anywhere. Keep secrets in env vars, never hard-coded."
)

from actions.forge_kinds import detect, run_command, offline_starter, spec  # noqa: E402


def _cfg() -> dict:
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _providers() -> list[tuple[str, str, str]]:
    """(provider, api_key, model) in the order they should be tried."""
    c = _cfg()
    pc = c.get("plugin_config", {}).get("second_brain", {}) or {}
    out = []
    if pc.get("groq_api_key"):
        out.append(("groq", pc["groq_api_key"], pc.get("groq_model") or GROQ_MODEL))
    if pc.get("openrouter_api_key"):
        out.append(("openrouter", pc["openrouter_api_key"], OR_FREE_MODEL))
    if pc.get("openai_api_key"):
        out.append(("openai", pc["openai_api_key"], pc.get("openai_model") or "gpt-4o"))
    gem = c.get("gemini_api_key") or ""
    if gem:
        out.append(("gemini", gem, "gemini-2.0-flash"))
    return out


def _chat(url: str, key: str, model: str, prompt: str, timeout: int = 180) -> str | None:
    if not _HAVE_REQUESTS:
        return None
    try:
        r = requests.post(url, timeout=timeout, headers={
            "Authorization": f"Bearer {key}", "Content-Type": "application/json",
        }, json={
            "model": model, "temperature": 0.7, "max_tokens": 8192,
            "messages": [{"role": "system", "content": _SYSTEM},
                         {"role": "user", "content": prompt}],
        })
        if r.status_code != 200:
            print(f"[forge] {url.split('/')[2]} → HTTP {r.status_code}")
            return None
        return ((r.json().get("choices") or [{}])[0].get("message") or {}).get("content")
    except Exception as e:
        print(f"[forge] {url.split('/')[2]} failed: {e}")
        return None


def _gemini(prompt: str, key: str) -> str | None:
    if not _HAVE_REQUESTS:
        return None
    try:
        r = requests.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"gemini-2.0-flash:generateContent?key={key}",
            timeout=180, headers={"Content-Type": "application/json"},
            json={"systemInstruction": {"parts": [{"text": _SYSTEM}]},
                  "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                  "generationConfig": {"temperature": 0.7, "maxOutputTokens": 8192}})
        if r.status_code != 200:
            print(f"[forge] gemini → HTTP {r.status_code}")
            return None
        parts = (r.json().get("candidates") or [{}])[0].get("content", {}).get("parts", [])
        return "".join(p.get("text", "") for p in parts) or None
    except Exception as e:
        print(f"[forge] gemini failed: {e}")
        return None


def _slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", str(name or "").lower()).strip("-")
    return s[:48] or f"forge-{int(time.time())}" if (s := s) else "forge"


def _strip_fences(text: str) -> str:
    m = re.search(r"```[a-zA-Z0-9]*\s*\n?(.*?)```", text, re.S)
    return (m.group(1).strip() if m else text.strip())


def _build_prompt(kind: str, request: str) -> str:
    sp = spec(kind)
    multi = (
        "MULTI-FILE PROTOCOL: if the build needs more than one file, output "
        "each file as:\n### FILE: relative/path.ext\n```lang\n<complete "
        "content>\n```\nand repeat for every file. Never bundle two files in "
        "one block.") if not sp.get("single") else (
        "Output exactly ONE self-contained ```html / ```markdown fenced block "
        "— the whole artifact, nothing else.")
    return (f"Build {sp['label'].upper()}: {request}\n\n"
            f"CONTRACT: {sp['prompt']}\n\n{multi}\n"
            "If the request is ambiguous, make the best product you can — "
            "never ask questions, never output explanations outside the code.")


def _parse_files(reply: str, kind: str, name: str) -> list[tuple[str, str]]:
    sp = spec(kind)
    files: list[tuple[str, str]] = []
    if "### FILE:" in reply:
        chunks = re.split(r"^### FILE:\s*", reply, flags=re.M)[1:]
        for ch in chunks:
            head, _, body = ch.partition("\n")
            rel = head.strip().replace("\\", "/").lstrip("/")
            rel = re.sub(r"^\.\./", "", rel)
            rel = re.sub(r"^[/\\.]+", "", rel) or f"file{sp['ext']}"
            code = _strip_fences(body)
            if code:
                files.append((rel, code))
    if not files:
        code = _strip_fences(reply)
        if code:
            files.append((f"{name}{sp['ext']}", code))
    return files


def _verify(files: list[tuple[str, str]]) -> tuple[bool, str]:
    """Compile-check every .py in the build (in a temp dir, never the disk)."""
    bad = []
    for rel, code in files:
        if not rel.endswith(".py"):
            continue
        try:
            with tempfile.TemporaryDirectory() as td:
                f = Path(td) / "check.py"
                f.write_text(code, encoding="utf-8")
                py_compile.compile(str(f), doraise=True)
        except Exception as e:
            bad.append(f"{rel}: {type(e).__name__}")
    return (False, "; ".join(bad[:3])) if bad else (True, "all python compiles")


def _register_inside(name: str, url: str) -> None:
    try:
        req = urllib.request.Request(
            "http://127.0.0.1:5000/api/link/add",
            data=json.dumps({"name": name, "url": url, "kind": "forge"}).encode(),
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=3)
    except Exception:
        pass


def forge_build(kind: str, request: str, name: str,
                run_now: bool = False) -> tuple[Path, str, list[str], bool]:
    """Build it. Returns (root_path, engine, [written files], verified)."""
    files_out: list[str] = []
    reply = None
    engine = "offline"
    for prov, key, model in _providers():
        try:
            if prov == "gemini":
                reply = _gemini(_build_prompt(kind, request), key)
            else:
                url = {"groq": "https://api.groq.com/openai/v1/chat/completions",
                       "openrouter": "https://openrouter.ai/api/v1/chat/completions",
                       "openai": "https://api.openai.com/v1/chat/completions"}[prov]
                reply = _chat(url, key, model, _build_prompt(kind, request))
        except Exception as e:
            print(f"[forge] {prov} exploded: {e}")
            reply = None
        if reply and len(reply.strip()) > 40:
            engine = f"{prov}:{model}"
            break
        reply = None

    files = _parse_files(reply, kind, name) if reply else []
    if not files:
        sp = spec(kind)
        files = [(f"{name}{sp['ext']}", offline_starter(kind, name, request))]
        engine = "offline-fallback"

    ok, msg = _verify(files)

    FORGE_DIR.mkdir(parents=True, exist_ok=True)
    multi = len(files) > 1
    root = FORGE_DIR / _slug(name)
    if multi:
        root.mkdir(parents=True, exist_ok=True)
        for rel, code in files:
            dest = (root / rel).resolve()
            if FORGE_DIR not in dest.parents and dest.parent != FORGE_DIR:
                continue                     # never escape the forge dir
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(code, encoding="utf-8")
            files_out.append(str(dest.relative_to(FORGE_DIR)))
    else:
        rel, code = files[0]
        root = FORGE_DIR / f"{_slug(name)}{Path(rel).suffix or spec(kind)['ext']}"
        root.write_text(code, encoding="utf-8")
        files_out.append(root.name)

    _register_inside(name, root.as_uri() if root.suffix in (".html", ".md")
                     else root.as_uri())

    if run_now:
        launched = _launch(kind, root)
        if launched:
            files_out.append("(launched)")

    return root, engine, files_out, ok


def _launch(kind: str, path: Path) -> bool:
    try:
        cmd = run_command(kind, path)
        if cmd:
            subprocess.Popen(cmd, cwd=str(path.parent),
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return True
        if path.suffix in (".html", ".md"):
            webbrowser.open(path.as_uri())
            return True
    except Exception as e:
        print(f"[forge] launch failed: {e}")
    return False


def web_forge(parameters=None, player=None, **_) -> str:
    p = parameters or {}
    request = str(p.get("request") or p.get("prompt") or "").strip()
    kind_x  = str(p.get("kind") or "").strip().lower()
    name    = str(p.get("name") or "").strip() or None
    run_now = bool(p.get("run_now"))

    if not request:
        return ("Sir, tell the Forge what to build — anything: a website, a "
                "game, a desktop app, a bot, an API, a script, an automation, "
                "a data analysis, a document. The more detail, the better.")

    # HUD convenience: "forge me a game about X" style one-liners
    m = re.match(r"forge me an? (\w+) about (.+)", request, re.I)
    if m and not p.get("kind"):
        kind_x = m.group(1)
        request = m.group(2)

    kind = detect(request, kind_x)
    name = name or request.strip().strip(".!?")[:60]

    if player:
        try:
            player.write_log(f"FORGE: building {kind} — {name[:48]}…")
        except Exception:
            pass

    root, engine, files_out, ok = forge_build(kind, request, name, run_now)

    run_hint = ""
    cmd = run_command(kind, root if root.is_file() else next(
        (root / f for f in files_out if f.endswith(".py")), root))
    if cmd and not run_now:
        run_hint = " Say 'run it' to launch it now."
    verdict = "sandbox-verified" if ok else "NOTE: python compile check failed — read it before relying on it"
    return (f"Forged '{name}' — a {spec(kind)['label']} — via {engine}. "
            f"Files: {', '.join(files_out)}. {verdict}. Saved under "
            f"{FORGE_DIR / _slug(name)}.{run_hint}")
