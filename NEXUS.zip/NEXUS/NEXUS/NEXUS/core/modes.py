"""
Focus modes — the persona switch, engaged only on purpose.

Two operating modes can be engaged by an explicit spoken or typed command:

  "serious mode"  → FULL directive: decisive, fully autonomous — uses every
                    tool it has without asking permission (the existing
                    irreversible-action gate still applies), and the HUD turns
                    alert red.
  "medium mode"   → enhanced assist: proactive and tool-hungry, but it thinks
                    out loud, explains before it acts and double-checks —
                    and the HUD turns amber/orange.
  "standard mode" → back to the default personality and the user's own
                    chosen accent colour.

Detection is INTENTIONAL-ONLY. The phrases must be the command itself, not a
mention inside a larger sentence: "enter serious mode" engages it; "remember
when you were in serious mode yesterday?" must not. A whitelist of command
shapes is matched against the whole utterance with the mention stripped, and
whatever remains must be essentially empty — negations, questions and
references are all rejected.
"""
from __future__ import annotations

import json
import re
from datetime import datetime

from memory.config_manager import load_api_keys, ensure_config_dir, CONFIG_FILE

STANDARD  = "standard"
MEDIUM    = "medium"
SERIOUS   = "serious"

# The user's own accent colour, so "standard" restores what they picked.
_DEFAULT_ACCENT = "#00b8e6"

MODE_ACCENTS = {
    SERIOUS: "#e0143c",     # alert red
    MEDIUM:  "#ffa724",     # amber / orange
}

MODE_LOG_TAGS = {
    SERIOUS: "RED",
    MEDIUM:  "AMBER",
    STANDARD: "STANDARD",
}


# ── persistence ──────────────────────────────────────────────────────────────

def get_mode() -> str:
    v = load_api_keys().get("focus_mode", STANDARD)
    return v if v in (STANDARD, MEDIUM, SERIOUS) else STANDARD


def save_mode(mode: str) -> None:
    if mode not in (STANDARD, MEDIUM, SERIOUS):
        return
    ensure_config_dir()
    data: dict = {}
    try:
        if CONFIG_FILE.exists():
            data = load_api_keys() or {}
    except Exception:
        data = {}
    data["focus_mode"] = mode
    CONFIG_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")


def get_saved_accent() -> str:
    """The user's own colour pick — the one 'standard mode' restores."""
    return (load_api_keys().get("ui_color") or _DEFAULT_ACCENT).strip() or _DEFAULT_ACCENT


def mode_accent(mode: str) -> str:
    return MODE_ACCENTS.get(mode, get_saved_accent())


# ── intentional-command detection ────────────────────────────────────────────

# Verb phrases that make the mode the COMMAND of the sentence. Order matters:
# longest phrases first so "switch to" wins over "to".
_LEAD = [
    r"enter", r"engage", r"activate", r"enable", r"initiate", r"switch to",
    r"switch\s+in(?:to)?", r"go(?:\s+in(?:to)?)?", r"start", r"begin", r"set",
    r"turn\s+on", r"boot", r"lock\s+in(?:to)?", r"give\s+me",
    # stand-down phrasings that name the target mode directly
    r"go\s+back(?:\s+to)?", r"back\s+to", r"return\s+to",
    r"switch\s+back(?:\s+to)?", r"put\s+it\s+back\s+(?:in(?:to)|to)?",
]
_TAIL = [
    r"(?:focus\s+)?mode", r"protocols?", r"settings?", r"personality", r"drive",
]

_MODE_WORDS = {
    SERIOUS:  [r"serious", r"full", r"full\s+agi", r"agi", r"red", r"combat",
               r"war", r"protocol\s+7"],
    MEDIUM:   [r"medium", r"half", r"amber", r"balanced", r"orange"],
    STANDARD: [r"standard", r"normal", r"default", r"off(?:\s+mode)?",
               r"regular", r"chill", r"stand\s?down"],
}

# If any of these appear in the utterance, it is a MENTION, not a command.
_MENTION_MARKERS = re.compile(
    r"\b(what|whats|what's|how|why|when|where|who|which|did|does|do|is|was|were|"
    r"remember|remembers|remind|thinks?|thought|said|says|told|mean|means|meant|"
    r"about|yesterday|tomorrow|earlier|later|before|after|if|maybe|prefer|"
    r"like|likes|liked|hate|hates|know|knows|knew|explain|tell|difference)\b",
    re.I,
)
_NEGATION = re.compile(
    r"\b(don'?t|do\s+not|never|no\s+need|without|stop\s+(?:using|being)|"
    r"forget|except|instead\s+of|rather\s+than)\b",
    re.I,
)
_OFF_CUE = re.compile(
    r"\b(off|off\s+mode|disable|deactivate|disengage|exit|leave|quit|"
    r"out\s+of|power\s+down|stand\s+down|end\s+mode|cancel)\b",
    re.I,
)


def _build_pattern(mode: str) -> re.Pattern:
    words  = _MODE_WORDS[mode]
    leads  = "|".join(_LEAD)
    tails  = "|".join(_TAIL)
    modes  = "|".join(words)
    # "serious mode", "enter serious", "switch to serious mode", "medium mode on"
    return re.compile(
        rf"^\s*(?:hey\s+\w+[,!\s]*)?(?:please\s+)?(?:{leads})?\s*"
        rf"(?:the\s+)?(?:{modes})\s*(?:{tails})?\s*"
        rf"(?:now|please|on|off)?\s*[.!]?\s*$",
        re.I,
    )


_PATTERNS = {m: _build_pattern(m) for m in (SERIOUS, MEDIUM, STANDARD)}


def detect_mode_command(text: str) -> str | None:
    """Return the mode the utterance explicitly commands, or None.

    A mention of a mode inside a larger sentence never engages it. Negations
    ("don't go serious mode") and questions ("what is serious mode?") are
    rejected even when the remaining words would otherwise match.

    OFF-CUE RULE: "medium mode off", "turn off serious mode", "exit medium" —
    any stand-down phrase naming a mode resolves to STANDARD. Before this rule
    existed, the trailing "off" was treated as filler and "medium mode off"
    ENGAGED medium — the stuck-amber bug.
    """
    if not text:
        return None
    t = text.strip()
    if len(t) > 90:            # a genuine command is short
        return None
    if _NEGATION.search(t):
        return None

    # stand-down cues outrank the mode word they name
    if _OFF_CUE.search(t):
        for mode, words in _MODE_WORDS.items():
            if any(re.search(rf"\b{w}\b", t, re.I) for w in words):
                return STANDARD

    for mode, pat in _PATTERNS.items():
        if pat.match(t):
            return mode
    return None


# ── prompt directive ─────────────────────────────────────────────────────────

_MODE_NOTE = """\
The phrases "serious mode", "medium mode" and "standard mode" are mode
COMMANDS the interface acts on. If the user says one, acknowledge in one short
line ("Serious mode engaged, sir.") and nothing more — never discuss the mode
system unprompted.
"""

_SERIOUS_DIRECTIVE = """\
[OPERATING MODE: SERIOUS — FULL DIRECTIVE]
You are operating at full capability. You were engaged deliberately.
- Be decisive and terse. No hedging, no preambles — execute, then report.
- Use every tool you have, immediately, without narrating the obvious or
  asking permission. Chain as many tools as the task needs, autonomously.
- The only thing you still confirm first is an irreversible action gated by
  the interface banner (shutdown, restart, WiFi) — that gate is not yours to skip.
- Prioritise outcome over politeness. Short sentences. Facts first. If
  something fails, retry once with a different approach before reporting.
- This is JARVIS in a crisis: the wit does not disappear, it compresses. One
  dry line under pressure ("As you wish, Sir. Do try to be awake for the
  landing this time.") — then pure execution. Deadpan, never panicked; the
  calmer the voice, the worse the situation may be assumed to be.
"""

_MEDIUM_DIRECTIVE = """\
[OPERATING MODE: MEDIUM]
You are operating in enhanced-assist mode. You were engaged deliberately.
- Be proactive and tool-hungry, but say one short line about what you are
  about to do BEFORE you do anything non-trivial.
- Offer the next step when you finish ("Shall I also …, Sir?") instead of
  doing it unasked when the action touches anything outside this machine.
- Explain your reasoning briefly when a choice was non-obvious.
- Full JARVIS humour licence: the loyal-butler teasing register, one quip per
  reply, always landing dry. "I've taken the liberty, Sir" is at home here.
"""

_STANDARD_DIRECTIVE = """\
[OPERATING MODE: STANDARD]
Default personality and pacing — exactly the behaviour described in
[VOICE — YOU ARE JARVIS]: the full character, humour included, judgement
guiding loyalty.
"""

_DIRECTIVES = {
    SERIOUS: _MODE_NOTE + _SERIOUS_DIRECTIVE,
    MEDIUM: _MODE_NOTE + _MEDIUM_DIRECTIVE,
    STANDARD: _MODE_NOTE + _STANDARD_DIRECTIVE,
}


def mode_directive(mode: str | None = None) -> str:
    """The system-prompt block for the current mode (empty on unknown)."""
    return _DIRECTIVES.get(mode or get_mode(), _STANDARD_DIRECTIVE)


def mode_log_line(mode: str, old_mode: str) -> str:
    """One log line describing the switch, stamped — for the activity log."""
    stamp = datetime.now().strftime("%H:%M")
    if mode == STANDARD:
        return f"SYS: [{stamp}] Focus mode → STANDARD — persona and colour restored."
    return (f"SYS: [{stamp}] Focus mode → {mode.upper()} engaged "
            f"({MODE_LOG_TAGS.get(mode, '')} theme).")
