"""Double-clap wake — clap twice, JARVIS wakes.

Runs on the raw mic blocks inside the asleep-gate (no camera, no extra
thread): each 64 ms block's RMS is compared against a slow noise-floor
estimate, and a CLAP is

  • a spike well above the floor (x8, and above an absolute bar), AND
  • an impulse: the energy collapses again within ~2 blocks.

The decay test is what separates a clap from speech — a syllable sustains,
a clap is over almost as soon as it started. Two claps inside the window
(0.2–1.5 s apart) fire on_detect once, then a 3 s cooldown and a reset keep
applause from waking the house repeatedly.

The noise floor tracks the room's quiet level with a slow EMA that only
learns from below-threshold blocks, so one loud clap can never raise the
bar above the next clap.
"""
from __future__ import annotations

import time

import numpy as np

_ABS_FLOOR = 400.0      # RMS below which the block is room-silence
_FLOOR_RATIO = 8.0      # a clap is at least 8x the room floor
_DECAY = 0.5            # energy must fall to this fraction within 2 blocks
_GAP_MIN = 0.20         # s between the two claps
_GAP_MAX = 1.50
_COOLDOWN = 3.0


class ClapWake:
    """Stateful but threadless: feed() does all the work, on the mic thread.
    The per-block cost is one RMS over 1024 samples — microseconds."""

    def __init__(self, on_detect, logger=print):
        self._on_detect = on_detect
        self._logger = logger
        self._floor = 60.0          # EMA of the quiet level
        self._first_at = 0.0        # monotonic time of the first clap
        self._armed = False
        self._last_fire = 0.0

    def reset(self) -> None:
        self._armed = False
        self._first_at = 0.0

    def feed(self, frame_int16) -> None:
        try:
            x = (frame_int16[:, 0] if getattr(frame_int16, "ndim", 1) > 1
                 else frame_int16).astype(np.float32)
            if x.size == 0:
                return
            rms = float(np.sqrt(np.mean(x * x)))
        except Exception:
            return

        now = time.monotonic()
        spike = rms > max(_ABS_FLOOR, self._floor * _FLOOR_RATIO)

        if not spike:
            # the floor only learns from quiet-ish blocks, so claps never
            # teach it to ignore themselves
            if rms < _ABS_FLOOR:
                self._floor = 0.97 * self._floor + 0.03 * max(rms, 5.0)
            self._decayed(rms)
            return

        # impulsive? compare the NEXT blocks' decay in _decayed()
        self._pending = rms
        self._pending_at = now
        self._decayed(rms, spike_now=True)

    def _decayed(self, rms: float, spike_now: bool = False) -> None:
        pend = getattr(self, "_pending", 0.0)
        pat = getattr(self, "_pending_at", 0.0)
        if pend <= 0.0:
            if spike_now:
                self._pending, self._pending_at = rms, time.monotonic()
            return
        if not spike_now and time.monotonic() - pat < 0.13:
            return                       # still inside the impulse window
        if rms <= pend * _DECAY or spike_now:
            self._pending = 0.0
            self._clap(spike_now and pat or pat)
        else:
            self._pending = 0.0          # sustained energy — speech, not a clap

    def _clap(self, _t: float) -> None:
        now = time.monotonic()
        if now - self._last_fire < _COOLDOWN:
            self.reset()
            return
        if not self._armed:
            self._armed = True
            self._first_at = now
            return
        gap = now - self._first_at
        self.reset()
        if _GAP_MIN <= gap <= _GAP_MAX:
            self._last_fire = now
            try:
                self._on_detect()
            except Exception as e:
                self._logger(f"ClapWake: on_detect error — {e}")
        # gap outside the window: this clap becomes a fresh first clap
        else:
            self._armed = True
            self._first_at = now
