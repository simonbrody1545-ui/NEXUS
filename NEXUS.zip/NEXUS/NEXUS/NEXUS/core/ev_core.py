"""
E.V. CORE — Central nervous system (v0.1) for the Mark-LV suite.

Three responsibilities live here today, each designed to grow:

  • SharedState    — the Memory Layer: a thread-safe key/value store with a
                     pub/sub bus. Qt-free and import-safe from anywhere, so
                     every future E.V. module (ev_hud, edith_radar,
                     lens_scanner…) reads and writes system-wide metrics
                     through this one object instead of private globals.
  • Trigger parser — a global string parser that catches the exact phrase
                     "spread ur roots" / "spread your roots" from ANY text
                     surface (dashboard chat log, terminal prompt, voice
                     transcript, wake-word plugin) and fires the executor.
  • Executor       — an asynchronous bootstrap that launches the
                     constellation graph server (dashboard/graph_server.py)
                     on port 5000 if it is not already running, waits for the
                     port to answer, then force-opens Opera (with an honest
                     system-default fallback) at the dashboard URL — all off
                     the caller's thread, never blocking tracking feeds.

Design rules inherited from the Mark-LV codebase:
  • no import ever raises at module load (lazy, guarded imports only),
  • background work on daemon threads / asyncio tasks, never inline,
  • degrade loudly-but-honestly instead of crashing.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

# ── paths ─────────────────────────────────────────────────────────────────────
def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR      = get_base_dir()
GRAPH_SERVER  = BASE_DIR / "dashboard" / "graph_server.py"
GRAPH_LOG     = BASE_DIR / "state" / "graph_server.log"
GRAPH_PORT    = 5000
GRAPH_URL     = f"http://localhost:{GRAPH_PORT}"

CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0   # win32 only

# ── the triggers ──────────────────────────────────────────────────────────
# 1) "spread ur roots"   → open/refresh the NEXUS grid and say "Done, sir."
# 2) "add this to roots"  → bind what is on the clipboard (a URL, or any
#    "name url" line) into the brain as a node, then confirm.
TRIGGER_PHRASES = ("spread ur roots", "spread your roots")
_TRIGGER_RE = re.compile(
    r"\b(?:" + "|".join(re.escape(p) for p in TRIGGER_PHRASES) + r")\b",
    re.IGNORECASE,
)
_ADD_RE = re.compile(
    r"\badd\s+(?:(?:this|that|it|the\s+site|the\s+page)\s+)?"
    r"(?:to|into|on)\s+(?:my\s+|the\s+)?"
    r"(?:roots|root\s+system|nexus|brain|grid|inside)\b",
    re.IGNORECASE,
)
_COOLDOWN = 3.0          # seconds — a doubled transcript must not fire twice

_URL_RE = re.compile(r"https?://\S+|\b(?:[a-z0-9-]+\.)+[a-z]{2,}(?:/\S*)?", re.IGNORECASE)

_MASTER_HOOK_BANNER = (
    "======================================================",
    "[E.D.I.T.H. CORE]: MASTER HOOK ACCEPTED -> SPREADING ROOTS",
    "LAUNCHING INTERACTIVE NEXUS GRID IN OPERA...",
    f"LOCAL HOST LINK: {GRAPH_URL}",
    "======================================================",
)

# Set by the assistant host (main.py) at boot: one-arg callable used to speak
# the confirmation line out loud. Left unset, spread_roots stays silent —
# the module works standalone too.
_say_hook = None


def set_speaker(fn) -> None:
    """Register the spoken-confirmation channel (JARVIS's voice)."""
    global _say_hook
    _say_hook = fn


def _say_done(text: str = "Done, sir.") -> None:
    if _say_hook is None:
        return
    try:
        _say_hook(text)
    except Exception:
        pass


# ── "add this to roots" — clipboard → NEXUS node ─────────────────────────
def _clipboard_text() -> str:
    try:
        import pyperclip
        return (pyperclip.paste() or "").strip()
    except Exception:
        return ""


def _title_from_url(url: str) -> str:
    host = re.sub(r"^https?://", "", url, flags=re.IGNORECASE).split("/")[0]
    host = host.replace("www.", "")
    base = host.split(".")[0] if "." in host else host
    return (base or "New Link").replace("-", " ").replace("_", " ").title()


def _add_to_brain() -> bool:
    """Bind the clipboard's URL (or 'Name | url' line) into the NEXUS.
    Returns True when something was actually added."""
    text = _clipboard_text()
    if not text:
        _log("[E.D.I.T.H. CORE]: Nothing on the clipboard to bind, sir.")
        _say_done("The clipboard is empty, sir — copy the site first.")
        return False
    m = _URL_RE.search(text)
    if not m:
        _log(f"[E.D.I.T.H. CORE]: No address found on the clipboard: {text[:60]}")
        _say_done("I could not find an address on the clipboard, sir.")
        return False
    url = m.group(0).rstrip(".,;)")
    name = ""
    if "|" in text:
        name = text.split("|")[0].strip()
    if not name:
        name = _title_from_url(url)
    body = json.dumps({"name": name, "url": url, "kind": "web"}).encode()
    try:
        req = urllib.request.Request(
            f"{GRAPH_URL}/api/link/add", data=body,
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as r:
            ok = json.loads(r.read()).get("ok", False)
    except Exception:
        ok = False
    if not ok:                                   # nexus down — write the file directly
        try:
            from pathlib import Path
            path = Path(__file__).resolve().parent.parent / "state" / "nexus_links.json"
            import json as _json
            links = _json.loads(path.read_text(encoding="utf-8")) if path.exists() else []
            links = [l for l in links if l.get("id") != re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")]
            links.append({"id": re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-"),
                          "name": name, "url": url if "://" in url else "https://" + url,
                          "kind": "web", "added_at": time.time()})
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(_json.dumps(links, indent=2), encoding="utf-8")
            ok = True
        except Exception as exc:
            _log(f"[E.D.I.T.H. CORE]: Could not write the brain registry: {exc}")
            return False
    _log(f"[E.D.I.T.H. CORE]: Bound into the brain — {name} ({url})")
    _say_done(f"Bound into the brain, sir. Say spread your roots to see it in orbit.")
    return True


# ══════════════════════════════════════════════════════════════════════════════
# Memory Layer — SharedState
# ══════════════════════════════════════════════════════════════════════════════
class SharedState:
    """Thread-safe system-wide key/value store + pub/sub bus.

    `set/get` hold one RLock; `publish` snapshots and fans out to every
    subscriber synchronously — subscribers must be cheap (they run on the
    publisher's thread) or they should schedule their own work.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._data: dict = {}
        self._subs: list = []

    # -- key/value ------------------------------------------------------------
    def set(self, key: str, value) -> None:
        with self._lock:
            self._data[key] = value

    def get(self, key: str, default=None):
        with self._lock:
            return self._data.get(key, default)

    def snapshot(self) -> dict:
        with self._lock:
            return dict(self._data)

    # -- pub/sub ----------------------------------------------------------------
    def subscribe(self, callback) -> None:
        """callback(topic: str, payload) — called from the publisher's thread."""
        with self._lock:
            self._subs.append(callback)

    def publish(self, topic: str, payload) -> None:
        with self._lock:
            subs = list(self._subs)
        for cb in subs:
            try:
                cb(topic, payload)
            except Exception:
                pass


state = SharedState()          # the Memory Layer singleton


def _log(line: str) -> None:
    """Terminal console + Memory Layer, everywhere, always."""
    print(line, flush=True)
    state.publish("ev.log", {"ts": time.time(), "line": line})


# ══════════════════════════════════════════════════════════════════════════════
# Opera targeting — probe, register, open
# ══════════════════════════════════════════════════════════════════════════════
def find_opera() -> str | None:
    """Locate an Opera executable across platforms. Returns a path or None."""
    candidates: list[str] = []

    if os.name == "nt":
        la = os.environ.get("LOCALAPPDATA", "")
        pf = os.environ.get("PROGRAMFILES", r"C:\Program Files")
        pf86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
        for base in filter(None, (la, pf, pf86)):
            candidates += [
                rf"{base}\Programs\Opera GX\opera.exe",
                rf"{base}\Programs\Opera\launcher.exe",
                rf"{base}\Opera\launcher.exe",
                rf"{base}\Opera\opera.exe",
            ]
        candidates.append("opera")                       # PATH fallback
    elif sys.platform == "darwin":
        candidates += [
            "/Applications/Opera.app/Contents/MacOS/Opera",
            "/Applications/Opera GX.app/Contents/MacOS/Opera GX",
        ]
    else:
        candidates += ["opera", "opera-beta", "opera-developer"]

    for cand in candidates:
        if Path(cand).is_file():
            return cand
        on_path = shutil.which(cand)
        if on_path:
            return on_path
    return None


def open_in_opera(url: str) -> bool:
    """Force-register Opera and open `url` in it. False → caller falls back."""
    exe = find_opera()
    if not exe:
        return False
    try:
        webbrowser.register("opera", None, webbrowser.BackgroundBrowser(exe))
        return bool(webbrowser.get("opera").open(url))
    except Exception as exc:
        _log(f"[E.D.I.T.H. CORE]: Opera registration failed ({exc}) — falling back.")
        return False


# ══════════════════════════════════════════════════════════════════════════════
# Async bootstrap — spawn the graph server, wait for the port, open the browser
# ══════════════════════════════════════════════════════════════════════════════
def _port_open(host: str = "127.0.0.1", port: int = GRAPH_PORT, timeout: float = 0.4) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _spawn_graph_server() -> bool:
    """Launch dashboard/graph_server.py as a detached background process."""
    if not GRAPH_SERVER.exists():
        _log(f"[E.D.I.T.H. CORE]: Graph server module not found: {GRAPH_SERVER}")
        _log("[E.D.I.T.H. CORE]: Nexus build pending — try again after it lands.")
        return False
    # A server bound to the port but running the OLD dashboard build would
    # serve a stale grid forever. Restart it so the NEXUS always comes up.
    if _port_open():
        _log("[E.D.I.T.H. CORE]: Old graph server holding port 5000 — recycling...")
        try:
            out = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Get-NetTCPConnection -LocalPort 5000 -State Listen | "
                 "Select-Object -First 1 -ExpandProperty OwningProcess | "
                 "ForEach-Object { Stop-Process -Id $_ -Force }"],
                capture_output=True, timeout=8, **({"creationflags": CREATE_NO_WINDOW} if os.name == "nt" else {}))
            time.sleep(1.2)
            if _port_open():
                _log(f"[E.D.I.T.H. CORE]: Port recycle failed (rc={out.returncode}) — serving existing instance.")
        except FileNotFoundError:
            _log("[E.D.I.T.H. CORE]: powershell unavailable — serving existing instance.")
        except Exception:
            pass
    try:
        GRAPH_LOG.parent.mkdir(parents=True, exist_ok=True)
        log_fh = open(GRAPH_LOG, "ab")
        kwargs: dict = {}
        if os.name == "nt":
            kwargs["creationflags"] = CREATE_NO_WINDOW
        subprocess.Popen(
            [sys.executable, str(GRAPH_SERVER)],
            cwd=str(BASE_DIR),
            stdout=log_fh,
            stderr=subprocess.STDOUT,
            **kwargs,
        )
        return True
    except Exception as exc:
        _log(f"[E.D.I.T.H. CORE]: Graph server spawn failed: {exc}")
        return False


async def _wait_port_ready(timeout: float = 12.0) -> bool:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            _r, _w = await asyncio.open_connection("127.0.0.1", GRAPH_PORT)
            _w.close()
            return True
        except OSError:
            await asyncio.sleep(0.3)
    return False


async def spread_roots() -> None:
    """The full 'spread ur roots' execution loop. Never blocks the caller."""
    for line in _MASTER_HOOK_BANNER:                 # exact mandated banner
        _log(line)

    state.set("roots_firing", True)
    try:
        if not _port_open():
            _log("[E.D.I.T.H. CORE]: Spawning constellation graph server...")
            if _spawn_graph_server():
                if await _wait_port_ready():
                    _log(f"[E.D.I.T.H. CORE]: Constellation graph online at {GRAPH_URL}")
                else:
                    _log("[E.D.I.T.H. CORE]: Graph server did not answer port 5000 in time.")
                    return
        else:
            _log("[E.D.I.T.H. CORE]: Graph server already live — re-linking viewport.")

        if await asyncio.to_thread(open_in_opera, GRAPH_URL):
            _log("[E.D.I.T.H. CORE]: Opera gateway engaged. Roots spreading...")
        else:
            await asyncio.to_thread(webbrowser.open, GRAPH_URL)
            _log("[E.D.I.T.H. CORE]: Opera not located — system default browser engaged.")

        state.set("graph_url", GRAPH_URL)
        state.publish("ev.roots", {"url": GRAPH_URL, "ts": time.time()})
        _say_done()                                 # “Done, sir.” — confirmation line
    finally:
        state.set("roots_firing", False)


# ══════════════════════════════════════════════════════════════════════════════
# Global parser entry point
# ══════════════════════════════════════════════════════════════════════════════
_last_fire = 0.0
_fire_lock = threading.Lock()
_inflight = False


def matches(text: str) -> bool:
    """Exact-phrase test (word-bounded, case-insensitive, whitespace-normalized,
    no fuzzy near-misses)."""
    if not text:
        return False
    normalized = " ".join(str(text).split())   # collapse runs of whitespace
    return bool(_TRIGGER_RE.search(normalized) or _ADD_RE.search(normalized))


def parse_command(text: str) -> bool:
    """Feed ANY user text surface through here. True == trigger consumed.

    Safe to call from sync code, async coroutines, any thread. Firing never
    blocks: the bootstrap runs as an asyncio task on a running loop, or on a
    daemon thread when there is none.
    """
    global _last_fire, _inflight
    if not matches(text):
        return False

    # "add this to roots" fires synchronously-and-quickly on its own thread:
    # clipboard read + one local HTTP write. No cooldown sharing with the
    # spread-roots bootstrap — they are different commands.
    if _ADD_RE.search(" ".join(str(text).split())) and not _TRIGGER_RE.search(
            " ".join(str(text).split())):
        threading.Thread(target=_add_to_brain, daemon=True,
                         name="ev-add-to-brain").start()
        return True

    now = time.monotonic()
    with _fire_lock:
        if _inflight or (now - _last_fire) < _COOLDOWN:
            return True                              # consumed, not re-fired
        _last_fire = now
        _inflight = True

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None:
        async def _run():
            global _inflight
            try:
                await spread_roots()
            finally:
                _inflight = False
        loop.create_task(_run())
    else:
        def _thread_run():
            global _inflight
            try:
                asyncio.run(spread_roots())
            finally:
                _inflight = False
        threading.Thread(target=_thread_run, daemon=True, name="ev-spread-roots").start()
    return True


# ══════════════════════════════════════════════════════════════════════════════
# Introspection for the graph server / future E.V. modules
# ══════════════════════════════════════════════════════════════════════════════
def status() -> dict:
    return {
        "module": "ev_core",
        "version": "0.1",
        "triggers": list(TRIGGER_PHRASES),
        "graph_url": state.get("graph_url"),
        "graph_port": GRAPH_PORT,
        "roots_firing": bool(state.get("roots_firing")),
    }


if __name__ == "__main__":
    # Manual test: python core/ev_core.py
    asyncio.run(spread_roots())
