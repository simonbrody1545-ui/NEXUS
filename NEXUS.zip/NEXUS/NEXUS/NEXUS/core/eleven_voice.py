"""ElevenLabs voice — JARVIS's spoken replies through an ElevenLabs voice.

The user brings an API key (and optionally a voice id); JARVIS speaks with it
instead of the Gemini Live voice. Design notes:

- The Live session still generates the words (transcript arrives via
  output_transcription). When ElevenLabs is enabled, the session's AUDIO is
  discarded and each completed reply is re-synthesised here, then fed to the
  speaker as PCM — same queue, same waveform/mouth animation, same interrupt
  path. The reply therefore stays lip-synced; only the timbre changes.
- PCM output (pcm_44100) is requested so the samples can be sliced exactly
  like the Live audio — no mp3 decode step, no extra dependency.
- Short transcript chunks arrive during speech; synthesis starts only at
  turn_complete so the whole sentence has its real intonation.
"""

from __future__ import annotations

import json
import re
import threading
import urllib.request
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_FILE = BASE_DIR / "config" / "api_keys.json"

_API = "https://api.elevenlabs.io/v1"

# A sensible default: a calm British male from the community library. The user
# can override with their own voice id in config — anything they paste wins.
DEFAULT_VOICE_ID = "pNInz6obpgDQGcFmaJgB"   # "Adam" — deep, measured, neutral
MODEL_ID = "eleven_turbo_v2_5"              # fast + low latency, fine quality


# ── config ───────────────────────────────────────────────────────────────────

def cfg() -> dict:
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8")).get(
            "elevenlabs", {}) or {}
    except Exception:
        return {}


def api_key() -> str:
    return str(cfg().get("api_key") or "").strip()


def voice_id() -> str:
    v = str(cfg().get("voice_id") or "").strip()
    return v or DEFAULT_VOICE_ID


# Set the first time a synthesis fails (bad key, expired, no permission).
# From then on the session plays Gemini's own voice instead — the model's
# audio stops being discarded, so the user hears SOMETHING rather than
# silence. Cleared by disable_fail_state() when the key changes.
_failed = False


def mark_failed() -> None:
    global _failed
    if not _failed:
        print("[ElevenLabs] ❌ synthesis failed — falling back to the Gemini "
              "voice for the rest of this session")
    _failed = True


def is_failed() -> bool:
    return _failed


def clear_fail() -> None:
    global _failed
    _failed = False


def enabled() -> bool:
    """On only when a key exists, the user hasn't turned it off, and the
    service hasn't proven itself broken this session."""
    if _failed:
        return False
    c = cfg()
    return bool(str(c.get("api_key") or "").strip()) and c.get("enabled", True)


def save(api_key: str = "", voice_id: str = "", enabled: bool | None = None) -> None:
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    e = data.get("elevenlabs") or {}
    if api_key.strip():
        e["api_key"] = api_key.strip()
    if voice_id.strip():
        e["voice_id"] = voice_id.strip()
    if enabled is not None:
        e["enabled"] = bool(enabled)
    data["elevenlabs"] = e
    CONFIG_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")


# ── speech hygiene ───────────────────────────────────────────────────────────

_MD = re.compile(r"[*_`#>|]|\[|\]|\(|\)|:+|\bhttps?://\S+")


def clean_for_speech(text: str) -> str:
    """Strip everything that reads badly aloud: markdown, urls, code ticks."""
    t = _MD.sub(" ", text or "")
    t = re.sub(r"\s{2,}", " ", t).strip()
    # ElevenLabs reads at the punctuation; cap the blast radius of one turn.
    return t[:1200]


# ── synthesis ────────────────────────────────────────────────────────────────

class Voice:
    """One synth call per reply. Thread-safe: the receive loop awaits it."""

    def __init__(self):
        self._sem = threading.Semaphore(1)

    def synth_pcm(self, text: str, timeout: float = 20.0) -> bytes:
        """text → 44.1 kHz 16-bit mono PCM bytes. Raises on failure."""
        text = clean_for_speech(text)
        if not text:
            return b""
        key = api_key()
        if not key:
            raise RuntimeError("no ElevenLabs api_key configured")
        url = (f"{_API}/text-to-speech/{voice_id()}"
               f"?output_format=pcm_44100")
        body = json.dumps({
            "text": text,
            "model_id": MODEL_ID,
            "voice_settings": {
                "stability": 0.55,          # calm, no wobble
                "similarity_boost": 0.8,
                "style": 0.15,              # a hint of delivery, not acted
                "use_speaker_boost": True,
            },
        }).encode("utf-8")
        req = urllib.request.Request(
            url, data=body, method="POST",
            headers={"xi-api-key": key, "Content-Type": "application/json",
                     "Accept": "audio/raw"},
        )
        with self._sem:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()

    def list_voices(self) -> list[dict]:
        key = api_key()
        if not key:
            return []
        req = urllib.request.Request(
            f"{_API}/voices", headers={"xi-api-key": key})
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode("utf-8"))
            return [{"id": v["voice_id"], "name": v.get("name", "?")}
                    for v in (data.get("voices") or [])]
        except Exception:
            return []


_voice: Voice | None = None
_voice_lock = threading.Lock()


def get_voice() -> Voice:
    global _voice
    with _voice_lock:
        if _voice is None:
            _voice = Voice()
        return _voice


# ── playback glue ────────────────────────────────────────────────────────────

def speak_into_queue(text: str, audio_in_queue, speak_fn=None) -> int:
    """Synthesise and hand the reply to the speaker queue as 32 ms slices.

    Returns bytes queued (0 = nothing — either disabled or failed). Runs in
    the executor; the receive loop awaits it, so the Live session's own audio
    for that turn should have been muted at the session level.
    """
    if not enabled():
        return 0
    try:
        pcm = get_voice().synth_pcm(text)
    except Exception as e:
        print(f"[ElevenLabs] ⚠️ synth failed: {e}")
        mark_failed()          # next turns play Gemini's audio natively
        return 0
    if not pcm:
        return 0
    # 44100 Hz × 2 bytes × 0.032 s ≈ 2822 bytes per slice — same interrupt
    # responsiveness the Live path has (~30 ms granularity).
    SLICE = 2822
    for i in range(0, len(pcm), SLICE):
        audio_in_queue.put(pcm[i:i + SLICE])
    return len(pcm)
