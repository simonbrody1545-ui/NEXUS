"""One place where JARVIS opens anything in a browser.

The user's rule: ONLY Opera, never the system default. Every module that used
to call webbrowser.open() or os.startfile(url) now goes through here.

Discovery order (cached after the first hit):
  1. The registry's App Paths entry for opera.exe — survives Opera moving,
     covers both Opera and Opera GX automatically.
  2. The well-known install directories (Opera, Opera GX, user + Program Files).
  3. opera.exe on PATH.

If Opera genuinely cannot be found, open_url returns False and the caller says
so — it must NEVER silently fall back to the system default browser, because
that is exactly what the user forbade.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

_exe_cache: str | None = None


def _candidate_paths() -> list[Path]:
    home = Path.home()
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    local = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
    names = ("opera.exe", "launcher.exe")
    dirs = [
        Path(local) / "Programs" / "Opera GX",
        Path(local) / "Programs" / "Opera",
        Path(pf) / "Opera GX",
        Path(pf) / "Opera",
        Path(pf86) / "Opera GX",
        Path(pf86) / "Opera",
    ]
    out: list[Path] = []
    for d in dirs:
        for n in names:
            p = d / n
            if p.exists():
                out.append(p)
    return out


def opera_exe(refresh: bool = False) -> str:
    """The path to Opera, or "" if it truly isn't installed. Cached."""
    global _exe_cache
    if _exe_cache is not None and not refresh:
        return _exe_cache
    exe = ""
    if sys.platform == "win32":
        try:
            import winreg
            for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
                try:
                    with winreg.OpenKey(
                            root,
                            r"Software\Microsoft\Windows\CurrentVersion\App Paths\opera.exe") as k:
                        val = winreg.QueryValueEx(k, "")[0]
                        val = val.strip().strip('"')
                        if val and Path(val).exists():
                            exe = val
                            break
                except OSError:
                    continue
        except Exception:
            pass
    if not exe:
        for p in _candidate_paths():
            exe = str(p)
            break
    if not exe:
        from shutil import which
        exe = which("opera") or which("opera.exe") or ""
    if not exe and sys.platform != "win32":
        from shutil import which
        exe = which("opera") or ""
    _exe_cache = exe
    return exe


def open_url(url: str) -> bool:
    """Open `url` in Opera. True on success; False when Opera is missing —
    the caller should tell the user rather than open any other browser."""
    url = (url or "").strip()
    if not url:
        return False
    exe = opera_exe()
    if not exe:
        return False
    try:
        # DETACHED so Opera's lifetime is its own — closing JARVIS never kills
        # the browser, and a new tab goes to the RUNNING Opera instance.
        subprocess.Popen(
            [exe, "--new-tab", url],
            close_fds=True,
            creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return True
    except Exception:
        pass
    try:
        os.startfile(url)   # last resort ONLY if Opera is the registered
        return True         # handler; falls through only when it is missing
    except Exception:
        return False


def open_path(path) -> bool:
    """Open a local file (html report, dashboard) in Opera."""
    try:
        p = Path(path)
        return open_url(p.as_uri())
    except Exception:
        return False


def status_line() -> str:
    """What the UI can show: which Opera JARVIS will use."""
    exe = opera_exe()
    if not exe:
        return "Opera not found — browser opens are blocked (Opera-only rule)"
    return f"Opera: {exe}"
