"""
A.G.I. BRAIN — literal thinking storage for J.A.R.V.I.S.

Not a metaphor: a real, on-disk store he owns and uses every turn.

  state/brain/memory.json    durable memories (facts about sir, projects, world)
  state/brain/thoughts.jsonl private thinking log (his own reasoning, plans)

The model reaches it through the `agi_brain` action tool (actions/agi_brain.py):
  think    — append a private thought
  remember — store a durable fact (deduped, recency/count scored)
  recall   — search memory (word hits + tag hits + recency + repetition)
  status   — how much the brain holds

`context_lines()` is injected into the session's system instruction every
rebuild, so what the brain holds is literally in his head at each connect.

Thread-safe, atomic writes, never raises past the API boundary callers rely on
(context_lines swallows everything — the session must not die over cosmetics).
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

BASE_DIR      = Path(__file__).resolve().parent.parent
BRAIN_DIR     = BASE_DIR / "state" / "brain"
MEMORY_FILE   = BRAIN_DIR / "memory.json"
THOUGHTS_FILE = BRAIN_DIR / "thoughts.jsonl"

_LOCK         = threading.Lock()
_MEM_LIMIT    = 500        # durable memories kept
_THOUGHT_TAIL = 400        # thought lines kept in the hot log


def _now() -> float:
    return time.time()


def _load_memory() -> list:
    try:
        data = json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _save_memory(items: list) -> None:
    BRAIN_DIR.mkdir(parents=True, exist_ok=True)
    tmp = MEMORY_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(items[-_MEM_LIMIT:], indent=2, ensure_ascii=False),
                   encoding="utf-8")
    tmp.replace(MEMORY_FILE)


def _norm(s: str) -> str:
    return " ".join(str(s or "").lower().split())


# ── write paths ───────────────────────────────────────────────────────────────
def remember(text: str, kind: str = "fact", tags: list | None = None) -> dict:
    """Store a durable memory. Same text twice → refresh + count, no dupes."""
    text = str(text or "").strip()
    if not text:
        return {"ok": False, "error": "empty text"}
    with _LOCK:
        mem = _load_memory()
        key = _norm(text)
        for m in mem:
            if _norm(m.get("text", "")) == key:
                m["ts"] = _now()
                m["count"] = int(m.get("count", 1)) + 1
                if tags:
                    merged = list(dict.fromkeys(
                        [str(t) for t in (m.get("tags") or [])] + [str(t) for t in tags]))
                    m["tags"] = merged[:8]
                _save_memory(mem)
                return {"ok": True, "deduped": True, "id": m.get("id"),
                        "text": m.get("text")}
        entry = {"id": f"m{int(_now() * 1000)}", "text": text[:2000],
                 "kind": str(kind or "fact")[:24],
                 "tags": [str(t).lower() for t in (tags or [])][:8],
                 "ts": _now(), "count": 1}
        mem.append(entry)
        _save_memory(mem)
    return {"ok": True, "id": entry["id"], "text": entry["text"]}


def think(text: str) -> dict:
    """Append a private thought to the thinking log."""
    text = str(text or "").strip()
    if not text:
        return {"ok": False, "error": "empty text"}
    BRAIN_DIR.mkdir(parents=True, exist_ok=True)
    line = json.dumps({"ts": _now(), "thought": text[:2000]}, ensure_ascii=False)
    with _LOCK:
        with THOUGHTS_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
        try:
            lines = THOUGHTS_FILE.read_text(encoding="utf-8").splitlines()
            if len(lines) > _THOUGHT_TAIL:
                THOUGHTS_FILE.write_text(
                    "\n".join(lines[-_THOUGHT_TAIL:]) + "\n", encoding="utf-8")
        except Exception:
            pass
    return {"ok": True}


# ── read paths ────────────────────────────────────────────────────────────────
def recall(query: str = "", limit: int = 8) -> list:
    """Score memories: phrase hit, word hits, tag hits, recency, repetition."""
    limit = max(1, min(int(limit or 8), 25))
    q = _norm(query)
    with _LOCK:
        mem = _load_memory()
    now = _now()
    words = [w for w in q.split() if w]

    def score(m: dict) -> float:
        t = str(m.get("text", "")).lower()
        s = 0.0
        if not q:
            s += 0.5                                   # bare listing → recency order
        else:
            if q in t:
                s += 3.0
            if words:
                s += 1.2 * sum(1 for w in words if w in t) / len(words)
            s += sum(0.6 for tag in (m.get("tags") or [])
                     if _norm(tag) and _norm(tag) in q)
        age_days = max(0.0, (now - float(m.get("ts", now))) / 86400)
        s += max(0.0, 1.0 - age_days / 30.0)           # fades over a month
        s += 0.1 * min(5, int(m.get("count", 1)) - 1)  # repeated = important
        return s

    ranked = sorted(mem, key=score, reverse=True)
    return [m for m in ranked[:limit] if score(m) > 0.15 or not q]


def recent_thoughts(n: int = 5) -> list:
    """The last n private thoughts, oldest → newest."""
    try:
        lines = THOUGHTS_FILE.read_text(encoding="utf-8").splitlines()[-max(1, int(n)):]
        out = []
        for l in lines:
            if l.strip():
                out.append(str(json.loads(l).get("thought", "")))
        return out
    except Exception:
        return []


def status() -> dict:
    with _LOCK:
        mem = _load_memory()
    n_thoughts = 0
    try:
        n_thoughts = sum(1 for l in
                         THOUGHTS_FILE.read_text(encoding="utf-8").splitlines()
                         if l.strip())
    except Exception:
        pass
    return {"memories": len(mem), "thoughts": n_thoughts, "dir": str(BRAIN_DIR)}


def context_lines() -> str:
    """What the brain holds right now — injected into the system instruction."""
    try:
        mem = recall("", limit=10)
        th = recent_thoughts(4)
        if not mem and not th:
            return ""
        out = ["PERSISTENT BRAIN (your own durable storage — survives restarts):"]
        if mem:
            out.append("MEMORIES (most relevant):")
            out += [f"- {m.get('text')}" for m in mem[:10]]
        else:
            out.append("MEMORIES: none yet — remember() facts worth keeping.")
        if th:
            out.append("RECENT THOUGHTS: " + " | ".join(th[-3:]))
        out.append("Use the agi_brain tool: remember for durable facts about sir "
                   "and his world; think for private reasoning; recall to search "
                   "memory before answering anything about the past.")
        return "\n".join(out)
    except Exception:
        return ""
