"""The vault door — JARVIS's boot security.

First launch walks the user through choosing a password and CONFIRMING it a
second time (a typo in a password nobody can reset is a locked-out machine,
so the two-entry rule is not optional). From then on every boot demands the
password before the main window is usable.

What is stored:
  config/security.json —
    password_hash : PBKDF2-SHA256 (200k iterations, 16-byte salt)
    salt          : hex
    question      : recovery question
    answer_hash   : same PBKDF2 scheme
    authorized    : [{name, added}] — roster of people allowed at this screen
    created       : ISO date

A wrong attempt sleeps progressively (0.3 s → 2 s → 6 s) so brute force gets
nowhere fast, and every attempt is logged to state/logs/security.log.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
import time
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
SEC_FILE = BASE_DIR / "config" / "security.json"
LOG_FILE = BASE_DIR / "state" / "logs" / "security.log"

_PBKDF2_ITERS = 200_000

# ── storage ──────────────────────────────────────────────────────────────────

def _read() -> dict:
    try:
        return json.loads(SEC_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write(data: dict) -> None:
    SEC_FILE.parent.mkdir(parents=True, exist_ok=True)
    SEC_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")


def _log(line: str) -> None:
    try:
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {line}\n")
    except Exception:
        pass


def is_setup() -> bool:
    """True once a password exists — the lock screen replaces setup."""
    d = _read()
    return bool(d.get("password_hash") and d.get("salt"))


# ── hashing ──────────────────────────────────────────────────────────────────

def _hash(password: str, salt: bytes) -> str:
    return hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, _PBKDF2_ITERS).hex()


def _verify(password: str, salt_hex: str, want: str) -> bool:
    try:
        return hmac.compare_digest(_hash(password, bytes.fromhex(salt_hex)), want)
    except Exception:
        return False


# ── setup (password + confirm + recovery question) ──────────────────────────

MIN_LEN = 4     # spoken passwords are usually short; 4 is the floor

class SetupError(ValueError):
    """Rejected at setup — carries the reason for the UI to show."""


def setup(password: str, confirm: str, question: str = "", answer: str = "") -> None:
    """Create the vault. The password MUST be typed twice and the two entries
    must match — this is the only moment a mistake is recoverable."""
    p = (password or "").strip()
    c = (confirm or "").strip()
    if len(p) < MIN_LEN:
        raise SetupError(f"Password needs at least {MIN_LEN} characters.")
    if p != c:
        raise SetupError("The two entries don't match — type it again, both boxes.")
    if is_setup():
        raise SetupError("A password already exists. Verify first to change it.")

    salt = secrets.token_bytes(16)
    data = {
        "password_hash": _hash(p, salt),
        "salt":          salt.hex(),
        "question":      (question or "").strip(),
        "answer_hash":   _hash((answer or "").strip().lower(),
                               salt) if (answer or "").strip() else "",
        "authorized":    [],
        "created":       datetime.now().isoformat(timespec="seconds"),
    }
    _write(data)
    _log("VAULT CREATED — password set, double-confirmed")
    if answer.strip():
        add_authorized("commander")     # the person who set it up


def verify(password: str) -> bool:
    """Check a login attempt. Adds a small delay on failure — cheap, and it
    makes hammering the box pointless."""
    d = _read()
    ok = bool(d) and _verify((password or "").strip(),
                             d.get("salt", ""), d.get("password_hash", ""))
    if ok:
        _log("login OK")
    else:
        fails = int(d.get("_fails", 0)) + 1
        d["_fails"] = fails
        _write(d)
        _log(f"login FAILED (#{fails})")
        time.sleep(min(0.3 * (2 ** (fails - 1)), 6.0))
    return ok


def reset_with_recovery(answer: str, new_password: str, confirm: str) -> bool:
    """Forgotten password → the recovery question. Correct answer re-keys the
    vault (and the roster survives)."""
    d = _read()
    a = (answer or "").strip().lower()
    if not d or not d.get("answer_hash") or not _verify(a, d.get("salt", ""),
                                                        d["answer_hash"]):
        _log("recovery attempt — wrong answer")
        time.sleep(1.5)
        return False
    p, c = (new_password or "").strip(), (confirm or "").strip()
    if len(p) < MIN_LEN or p != c:
        return False
    salt = secrets.token_bytes(16)
    d["password_hash"] = _hash(p, salt)
    d["salt"] = salt.hex()
    d.pop("_fails", None)
    _write(d)
    _log("vault re-keyed via recovery answer")
    return True


# ── authorized users ─────────────────────────────────────────────────────────

def add_authorized(name: str) -> None:
    d = _read()
    roster = d.get("authorized") or []
    n = (name or "").strip()
    if n and not any(r.get("name", "").lower() == n.lower() for r in roster):
        roster.append({"name": n,
                       "added": datetime.now().strftime("%Y-%m-%d")})
        d["authorized"] = roster
        _write(d)
        _log(f"authorized user added: {n}")


def remove_authorized(name: str) -> bool:
    d = _read()
    roster = d.get("authorized") or []
    keep = [r for r in roster
            if r.get("name", "").lower() != (name or "").strip().lower()]
    if len(keep) == len(roster):
        return False
    d["authorized"] = keep
    _write(d)
    _log(f"authorized user removed: {name}")
    return True


def authorized_users() -> list[dict]:
    return list(_read().get("authorized") or [])


def change_password(old: str, new: str, confirm: str) -> bool:
    d = _read()
    if not d or not _verify((old or "").strip(), d.get("salt", ""),
                            d.get("password_hash", "")):
        time.sleep(1.0)
        return False
    p, c = (new or "").strip(), (confirm or "").strip()
    if len(p) < MIN_LEN or p != c:
        return False
    salt = secrets.token_bytes(16)
    d["password_hash"] = _hash(p, salt)
    d["salt"] = salt.hex()
    d.pop("_fails", None)
    _write(d)
    _log("password changed (verified)")
    return True


def strength(pw: str) -> str:
    """A one-word read for the setup screen: weak / okay / strong."""
    p = pw or ""
    score = 0
    if len(p) >= MIN_LEN: score += 1
    if len(p) >= 8:       score += 1
    if re.search(r"\d", p):    score += 1
    if re.search(r"[A-Za-z]", p) and re.search(r"[^A-Za-z0-9]", p): score += 1
    return ("weak", "weak", "okay", "okay", "strong")[min(score, 4)]
