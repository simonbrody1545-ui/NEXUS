from __future__ import annotations

import hashlib
import json
import math
import platform
import random
import sys
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any

from PyQt6.QtCore import (
    QEvent, QLineF, QObject, QPointF, QRectF, QSize, Qt, QTimer, QUrl, pyqtSignal,
)
from PyQt6.QtGui import (
    QBrush, QColor, QCloseEvent, QConicalGradient, QDragEnterEvent, QDropEvent,
    QFont, QKeySequence, QLinearGradient, QPainter, QPainterPath, QPen,
    QPixmap, QPolygonF, QRadialGradient, QShortcut,
)
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QFrame, QHBoxLayout, QInputDialog,
    QLabel, QLineEdit, QMainWindow, QProgressBar, QPushButton, QTextEdit,
    QVBoxLayout, QWidget,
)

import psutil

if platform.system() == "Windows":
    _WIN_HIDE: dict = {"creationflags": 0x08000000}   # CREATE_NO_WINDOW
else:
    _WIN_HIDE: dict = {}

BASE_DIR   = Path(__file__).resolve().parent
CONFIG_DIR = BASE_DIR / "config"
API_FILE   = CONFIG_DIR / "api_keys.json"
STATE_DIR  = BASE_DIR / "state"
NEXUS_FILE = STATE_DIR / "nexus_links.json"


def _read_full_config() -> dict:
    """Read api_keys.json config dict. Returns {} on any error."""
    try:
        return json.loads(API_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


# Single source of truth for the release name — the window title, the header
# badge and the readme must never disagree again.
APP_VERSION  = "MARK LIV"
APP_PROTOCOL = APP_VERSION.split()[-1]

_DEFAULT_W, _DEFAULT_H = 1220, 780
_MIN_W,     _MIN_H     = 960, 640

_OS = platform.system()


class C:
    BG        = "#000910"      # Deep JARVIS blue-black
    PANEL     = "#001018"      # Dark holographic panel
    PANEL2    = "#00141f"      # Secondary holographic panel
    BORDER    = "#00a8cc"      # JARVIS blue border
    BORDER_B  = "#00d4ff"      # Bright holographic blue
    BORDER_A  = "#00c0e8"      # Medium holographic blue
    PRI       = "#00d8ff"      # Primary JARVIS blue
    PRI_DIM   = "#0088aa"      # Dimmed JARVIS blue
    PRI_GHO   = "#004455"      # Ghost JARVIS blue
    ACC       = "#ff6a00"      # Arc reactor orange
    ACC2      = "#00ffff"      # Cyan accent
    GREEN     = "#00ffaa"      # JARVIS green
    GREEN_D   = "#00aa66"      # Dark JARVIS green
    RED       = "#ff2a4a"      # Alert red
    MUTED_C   = "#ff3355"      # Muted alert red
    TEXT      = "#9adcff"      # Holographic text
    TEXT_DIM  = "#4d97b8"      # Dimmed holographic text
    TEXT_MED  = "#6fc4e8"      # Medium holographic text
    WHITE     = "#eaffff"      # Bright holographic white
    DARK      = "#000a10"      # Dark JARVIS background
    BAR_BG    = "#001018"      # Dark bar background
    NEON      = "#00d8ff"      # JARVIS neon blue
    PLASMA    = "#00a0cc"      # Plasma blue
    VOLTAGE   = "#00ffcc"      # Voltage teal
    HOLO      = "#00f0ff"      # Holographic cyan
    ARC       = "#ff6600"      # Arc reactor glow
    STARK     = "#00b8e6"      # Stark Industries blue


# Keys tied to the accent colour — status colours (ACC, GREEN, RED…) stay fixed
_HUE_LINKED = (
    "BG", "PANEL", "PANEL2", "BORDER", "BORDER_B", "BORDER_A",
    "PRI", "PRI_DIM", "PRI_GHO", "TEXT", "TEXT_DIM", "TEXT_MED",
    "WHITE", "DARK", "BAR_BG", "NEON", "PLASMA", "VOLTAGE", "HOLO", "STARK",
)
_PALETTE_DEFAULTS: dict[str, str] = {k: getattr(C, k) for k in _HUE_LINKED}

DEFAULT_UI_COLOR = _PALETTE_DEFAULTS["STARK"]


def apply_ui_accent(accent_hex: str) -> bool:
    """
    Re-derives the whole teal-family palette from the chosen accent colour
    (hue shift — brightness/saturation ratios are preserved, design stays intact).
     Painted elements (HUD, waveform, metrics) pick up the new colour on the next
    frame; stylesheet-based panels pick it up when they are rebuilt.
    """
    import colorsys

    accent_hex = (accent_hex or "").strip().lower()
    if not (accent_hex.startswith("#") and len(accent_hex) == 7):
        return False
    try:
        int(accent_hex[1:], 16)
    except ValueError:
        return False

    def _hsv(h: str) -> tuple[float, float, float]:
        r = int(h[1:3], 16) / 255
        g = int(h[3:5], 16) / 255
        b = int(h[5:7], 16) / 255
        return colorsys.rgb_to_hsv(r, g, b)

    base_h            = _hsv(_PALETTE_DEFAULTS["PRI"])[0]
    acc_h, acc_s, _av = _hsv(accent_hex)
    dh   = acc_h - base_h
    grey = acc_s < 0.08   # near-grey accent → the whole theme is desaturated

    for key, hex0 in _PALETTE_DEFAULTS.items():
        h, s, v = _hsv(hex0)
        if grey:
            s *= 0.15
        r, g, b = colorsys.hsv_to_rgb((h + dh) % 1.0, s, v)
        setattr(C, key, "#{:02x}{:02x}{:02x}".format(
            int(r * 255 + 0.5), int(g * 255 + 0.5), int(b * 255 + 0.5)))
    return True


def current_palette() -> dict[str, str]:
    """A snapshot of the accent-linked colours currently on class C."""
    return {k: getattr(C, k) for k in _HUE_LINKED}


def retheme_all_widgets(old: dict[str, str], new: dict[str, str]) -> None:
    """
    LIVE full theme change. Replaces the old palette colours with the new ones
    in EVERY widget's stylesheet across the app and repaints them. This way the
    colour change applies INSTANTLY across the whole interface — panels, borders
    included — not just the painted elements. No restart needed.
    """
    mapping = {old[k].lower(): new[k].lower()
               for k in old if old[k].lower() != new.get(k, old[k]).lower()}
    if not mapping:
        return
    app = QApplication.instance()
    if app is None or not isinstance(app, QApplication):
        return
    for w in app.allWidgets():
        try:
            ss = w.styleSheet()
            if ss:
                s2 = ss
                for o, n in mapping.items():
                    if o in s2:
                        s2 = s2.replace(o, n)
                if s2 != ss:
                    w.setStyleSheet(s2)
            w.update()
        except Exception:
            pass


def qcol(h: str, a: int = 255) -> QColor:
    c = QColor(h); c.setAlpha(a); return c


def _mono(size: float, weight: QFont.Weight = QFont.Weight.Normal,
          spacing: float = 0.0) -> QFont:
    f = QFont()
    f.setFamily("Consolas")
    f.setStyleHint(QFont.StyleHint.Monospace)
    f.setPixelSize(max(8, int(size)))
    f.setWeight(weight)
    if spacing:
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
    return f


# ── HUD widget set (config surface kept for compatibility) ───────────────────
_ALL_HUD_WIDGETS = {"log", "monitor", "radar", "ekg", "spectrum", "flux", "satlink"}
_DEFAULT_HUD_WIDGETS = {"log", "monitor", "radar", "ekg"}


def hud_widgets_enabled() -> set[str]:
    try:
        raw = _read_full_config().get("hud_widgets")
        if isinstance(raw, list):
            v = {str(x) for x in raw} & _ALL_HUD_WIDGETS
            if v:
                return v
    except Exception:
        pass
    return set(_DEFAULT_HUD_WIDGETS)


def save_hud_widgets(widgets: set[str]) -> None:
    try:
        data = _read_full_config()
        data["hud_widgets"] = sorted(w for w in widgets if w in _ALL_HUD_WIDGETS)
        API_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")
    except Exception:
        pass


# ── Windows GPU via NVML DLL (no subprocess, no console window) ──────────────
_nvml_lib: Any = None     # cached ctypes DLL
_nvml_ok: object = None   # None=untested, True=works, False=unavailable


def _nvml_gpu_windows() -> float:
    """Return NVIDIA GPU utilisation % using nvml.dll directly — zero subprocess."""
    global _nvml_lib, _nvml_ok
    if _nvml_ok is False:
        return -1.0
    try:
        import ctypes

        class _Util(ctypes.Structure):
            _fields_ = [("gpu", ctypes.c_uint), ("memory", ctypes.c_uint)]

        if _nvml_lib is None:
            for dll_name in ("nvml", r"C:\Windows\System32\nvml.dll"):
                try:
                    lib = ctypes.WinDLL(dll_name)
                    lib.nvmlInit()
                    _nvml_lib = lib
                    _nvml_ok = True
                    break
                except Exception:
                    pass
            if _nvml_lib is None:
                _nvml_ok = False
                return -1.0

        device = ctypes.c_void_p()
        # 0 index handles the primary tactical graphics acceleration unit
        if _nvml_lib.nvmlDeviceGetHandleByIndex(0, ctypes.byref(device)) == 0:
            utils = _Util()
            if _nvml_lib.nvmlDeviceGetUtilizationRates(device, ctypes.byref(utils)) == 0:
                return float(utils.gpu)
    except Exception:
        _nvml_ok = False
    return -1.0


def _nexus_link_count() -> int:
    """How many worlds are bound into the Brain (The Inside) right now."""
    try:
        data = json.loads(NEXUS_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return len(data.get("links", data))
        if isinstance(data, list):
            return len(data)
    except Exception:
        pass
    return 0


# ══════════════════════════════════════════════════════════════════════════════
#  PAINTED HUD PRIMITIVES
# ══════════════════════════════════════════════════════════════════════════════

def _draw_scanlines(p: QPainter, r: QRectF, step: int = 3, alpha: int = 10) -> None:
    """Fine CRT scanlines over a rect — the hologram texture."""
    p.setPen(QPen(qcol(C.PRI, alpha), 1))
    y = r.top()
    while y < r.bottom():
        p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y))
        y += step


def _draw_brackets(p: QPainter, r: QRectF, ln: float = 12,
                   col: str | None = None, w: float = 1.6) -> None:
    """Corner brackets — the Stark panel signature."""
    c = qcol(col or C.BORDER_B, 220)
    p.setPen(QPen(c, w))
    x0, y0, x1, y1 = r.left(), r.top(), r.right(), r.bottom()
    for (cx, cy, dx, dy) in ((x0, y0, 1, 1), (x1, y0, -1, 1),
                             (x0, y1, 1, -1), (x1, y1, -1, -1)):
        p.drawLine(QPointF(cx, cy), QPointF(cx + dx * ln, cy))
        p.drawLine(QPointF(cx, cy), QPointF(cx, cy + dy * ln))


class HoloPanel(QFrame):
    """A framed holographic panel: dark translucent fill, hairline border,
    corner brackets, and a letterspaced title strip."""

    def __init__(self, title: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self._title = title
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, False)

    def set_title(self, t: str) -> None:
        self._title = t
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)

        # translucent dark glass
        p.fillRect(r, qcol(C.PANEL, 165))
        p.setPen(QPen(qcol(C.PRI_GHO, 190), 1))
        p.drawRect(r)

        # title strip
        if self._title:
            p.setPen(QPen(qcol(C.PRI, 110), 1))
            ty = r.top() + 17
            p.drawLine(QPointF(r.left() + 6, ty), QPointF(r.right() - 6, ty))
            p.setFont(_mono(10, QFont.Weight.Bold, 2.2))
            p.setPen(qcol(C.TEXT_MED, 235))
            p.drawText(QRectF(r.left() + 8, r.top() + 3, r.width() - 16, 14),
                       Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                       self._title.upper())
            # strip ticks on the right
            p.setPen(QPen(qcol(C.PRI_DIM, 150), 1))
            x = r.right() - 8
            for i in range(4):
                p.drawLine(QPointF(x - i * 5, r.top() + 5),
                           QPointF(x - i * 5, r.top() + 12))

        _draw_brackets(p, r, 13)
        p.end()


# ── arc reactor dial ──────────────────────────────────────────────────────────
class _ReactorDial(QWidget):
    """The centrepiece: a Stark arc-reactor dial. Segmented outer ring and a
    counter-rotating tick ring orbit a white-hot core. The core breathes with
    the microphone level and flashes while JARVIS speaks."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setMinimumSize(210, 210)
        self._phase = 0.0
        self._level = 0.0            # smoothed mic level 0..1
        self._speak  = 0.0           # smoothed speech envelope 0..1
        self._state  = "SLEEPING"

    def set_level(self, v: float) -> None:
        self._level = max(self._level * 0.72, min(1.0, max(0.0, v)) )

    def set_speak(self, v: float) -> None:
        self._speak = max(self._speak * 0.80, min(1.0, max(0.0, v)))

    def set_state(self, s: str) -> None:
        self._state = s

    def tick(self, dt: float) -> None:
        self._phase = (self._phase + dt * 24) % 360
        self._level *= 0.985
        self._speak *= 0.96
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2
        R = min(w, h) / 2 - 8
        rect = lambda rad: QRectF(cx - rad, cy - rad, rad * 2, rad * 2)  # noqa: E731

        # ambient halo
        halo = QRadialGradient(cx, cy, R * 1.25)
        halo.setColorAt(0.00, qcol(C.PRI, 0))
        halo.setColorAt(0.62, qcol(C.PRI, 14 + int(26 * self._speak)))
        halo.setColorAt(1.00, qcol(C.PRI, 0))
        p.setBrush(QBrush(halo)); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(rect(R * 1.25))

        # outer segmented ring — 36 segments rotating forward
        seg_r, segs, gap = R, 36, 2.4
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(segs):
            a0 = i * (360 / segs) + self._phase
            p.setBrush(qcol(C.PRI if i % 6 else C.BORDER_B,
                            150 if i % 3 else 235))
            p.drawArc(rect(seg_r), int(a0 * 16), int((360 / segs - gap) * 16))
        p.setPen(QPen(qcol(C.PRI, 90), 3))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(rect(seg_r + 4))

        # counter-rotating tick ring
        ticks = 72
        p.setPen(QPen(qcol(C.PRI_DIM, 190), 1.4))
        for i in range(ticks):
            a = math.radians(i * (360 / ticks) - self._phase * 0.9)
            long = i % 6 == 0
            r0 = R * 0.80
            r1 = r0 - (9 if long else 4.5)
            p.drawLine(QPointF(cx + math.cos(a) * r0, cy + math.sin(a) * r0),
                       QPointF(cx + math.cos(a) * r1, cy + math.sin(a) * r1))

        # level arc — bright sweep proportional to audio level
        if self._level > 0.02 or self._speak > 0.02:
            lvl = min(1.0, self._level * 0.7 + self._speak * 0.5)
            for k, aa in ((5, 36), (3, 90), (1, 230)):
                pen = QPen(qcol(C.ACC2 if self._speak > self._level else C.BORDER_B, aa // 1), k)
                p.setPen(pen)
                p.drawArc(rect(R * 0.68), int(-90 * 16), int(-lvl * 340 * 16))
            p.setPen(QPen(qcol(C.WHITE, 240), 1.2))
            p.drawArc(rect(R * 0.68), int(-90 * 16), int(-lvl * 340 * 16))

        # inner rings
        p.setPen(QPen(qcol(C.PRI, 130), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(rect(R * 0.46))
        p.setPen(QPen(qcol(C.PRI_DIM, 90), 1))
        p.drawEllipse(rect(R * 0.40))

        # triangle coils
        p.setPen(QPen(qcol(C.PRI, 150), 1.2))
        for i in range(3):
            a = math.radians(90 + i * 120 + self._phase * 0.35)
            p.drawLine(QPointF(cx + math.cos(a) * R * 0.46, cy + math.sin(a) * R * 0.46),
                       QPointF(cx + math.cos(a) * R * 0.30, cy + math.sin(a) * R * 0.30))

        # the core — white hot, breathing
        breathe = 0.5 + 0.5 * math.sin(math.radians(self._phase * 3))
        core_r = R * (0.185 + 0.020 * breathe + 0.055 * max(self._speak, self._level * 0.6))
        g = QRadialGradient(cx, cy, core_r * 2.2)
        g.setColorAt(0.00, QColor(255, 255, 255, 245))
        g.setColorAt(0.22, qcol(C.ACC2, 210))
        g.setColorAt(0.55, qcol(C.PRI, 120))
        g.setColorAt(1.00, qcol(C.PRI, 0))
        p.setBrush(QBrush(g)); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(rect(core_r * 2.2))
        p.setBrush(qcol(C.WHITE, 255))
        p.drawEllipse(rect(core_r * 0.5))

        # designation
        p.setFont(_mono(11, QFont.Weight.Bold, 3.0))
        p.setPen(qcol(C.WHITE, 230))
        p.drawText(QRectF(0, cy + R * 0.52, w, 18),
                   Qt.AlignmentFlag.AlignHCenter, "J.A.R.V.I.S.")
        p.setFont(_mono(8, QFont.Weight.Normal, 1.5))
        p.setPen(qcol(C.PRI_DIM, 200))
        p.drawText(QRectF(0, cy + R * 0.52 + 17, w, 12),
                   Qt.AlignmentFlag.AlignHCenter, self._state)
        p.end()


# ── radar sweep ───────────────────────────────────────────────────────────────
class _Radar(QWidget):
    """Tactical sweep: rotating beam, range rings, fading contact blips."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setMinimumSize(150, 150)
        self._ang = 0.0
        rng = random.Random(7)
        self._blips = [(rng.uniform(0.25, 0.95), rng.uniform(0, 2 * math.pi))
                       for _ in range(7)]

    def tick(self, dt: float) -> None:
        self._ang = (self._ang + dt * 70) % 360
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2
        R = min(w, h) / 2 - 6

        p.setPen(QPen(qcol(C.PRI_GHO, 160), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        for f in (1.0, 0.72, 0.45, 0.2):
            p.drawEllipse(QPointF(cx, cy), R * f, R * f)
        p.drawLine(QPointF(cx - R, cy), QPointF(cx + R, cy))
        p.drawLine(QPointF(cx, cy - R), QPointF(cx, cy + R))

        # sweep — fading wedge
        sweep = QConicalGradient(cx, cy, -self._ang)
        sweep.setColorAt(0.00, qcol(C.GREEN, 120))
        sweep.setColorAt(0.12, qcol(C.GREEN, 0))
        sweep.setColorAt(1.00, qcol(C.GREEN, 0))
        p.setBrush(QBrush(sweep)); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(cx, cy), R, R)
        a = math.radians(self._ang)
        p.setPen(QPen(qcol(C.GREEN, 220), 1.4))
        p.drawLine(QPointF(cx, cy),
                   QPointF(cx + math.cos(a) * R, cy + math.sin(a) * R))

        # contacts light up as the beam passes
        for d, ba in self._blips:
            da = (math.degrees(ba) - self._ang) % 360
            glow = max(0.0, 1.0 - da / 90.0)
            al = int(40 + 200 * glow)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(qcol(C.GREEN, al))
            p.drawEllipse(QPointF(cx + math.cos(ba) * R * d,
                                  cy + math.sin(ba) * R * d), 2.4, 2.4)

        p.setFont(_mono(8, QFont.Weight.Normal, 1.2))
        p.setPen(qcol(C.GREEN_D, 220))
        p.drawText(QRectF(4, 4, w - 8, 12), Qt.AlignmentFlag.AlignLeft, "SWEEP")
        p.drawText(QRectF(4, h - 15, w - 8, 12), Qt.AlignmentFlag.AlignLeft,
                   f"{len(self._blips)} CONTACTS")
        p.end()


# ── audio oscilloscope ────────────────────────────────────────────────────────
class _WaveScope(QWidget):
    """Rolling oscilloscope of the live audio level — mic when you talk,
    JARVIS's own voice while he speaks."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setMinimumSize(120, 64)
        self._hist: deque[float] = deque(maxlen=140)
        self._hist.extend(0.0 for _ in range(140))
        self._t = 0.0
        self._speak = False

    def push(self, v: float, speaking: bool = False) -> None:
        self._hist.append(min(1.0, max(0.0, v)))
        self._speak = speaking

    def tick(self, dt: float) -> None:
        self._t += dt
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), qcol(C.PANEL, 140))
        p.setPen(QPen(qcol(C.PRI_GHO, 160), 1))
        p.drawRect(QRectF(0.5, 0.5, w - 1, h - 1))

        mid = h / 2
        p.setPen(QPen(qcol(C.PRI_GHO, 90), 1))
        p.drawLine(QPointF(0, mid), QPointF(w, mid))

        n = len(self._hist)
        pts: list[QPointF] = []
        for i, v in enumerate(self._hist):
            idle = 0.06 + 0.05 * math.sin(self._t * 2.2 + i * 0.22)
            a = max(v, idle if not self._speak else v * 0.4 + idle * 0.4)
            x = i / (n - 1) * w
            pts.append(QPointF(x, mid - a * (mid - 3) * math.sin(self._t * 6 + i * 0.5) * 0
                                 - a * (mid - 3)))
        col = C.ACC2 if self._speak else C.BORDER_B
        for pw, pa in ((4, 30), (2, 90), (1, 240)):
            p.setPen(QPen(qcol(col, pa), pw,
                          Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawPolyline(QPolygonF(pts))
        # baseline fill
        poly = QPolygonF(pts + [QPointF(w, mid), QPointF(0, mid)])
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qcol(col, 26))
        p.drawPolygon(poly)

        p.setFont(_mono(8, QFont.Weight.Normal, 1.2))
        p.setPen(qcol(C.PRI_DIM, 220))
        p.drawText(QRectF(4, 3, w - 8, 12), Qt.AlignmentFlag.AlignLeft,
                   "AUDIO OSCILLOSCOPE")
        p.end()


# ── spectrum analyser ─────────────────────────────────────────────────────────
class _Spectrum(QWidget):
    """Dancing spectrum bars driven by the live level."""

    BARS = 28

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setMinimumSize(120, 54)
        self._vals = [0.0] * self.BARS
        self._level = 0.0
        self._t = 0.0

    def set_level(self, v: float) -> None:
        self._level = min(1.0, max(0.0, v))

    def tick(self, dt: float) -> None:
        self._t += dt
        for i in range(self.BARS):
            f = 0.18 + 0.8 * self._level
            wave = (0.5 + 0.5 * math.sin(self._t * 5.1 + i * 0.9)) \
                 * (0.5 + 0.5 * math.sin(self._t * 2.3 + i * 0.37))
            target = f * wave * (1.0 - i / (self.BARS * 1.6))
            self._vals[i] += (target - self._vals[i]) * 0.25
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, False)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), qcol(C.PANEL, 140))
        p.setPen(QPen(qcol(C.PRI_GHO, 160), 1))
        p.drawRect(QRectF(0.5, 0.5, w - 1, h - 1))

        bw = w / self.BARS
        for i, v in enumerate(self._vals):
            bh = max(2.0, v * (h - 14))
            x = i * bw + 1.5
            g = QLinearGradient(x, h - bh, x, h - 4)
            g.setColorAt(0, qcol(C.ACC2, 220))
            g.setColorAt(1, qcol(C.PRI, 90))
            p.fillRect(QRectF(x, h - 4 - bh, bw - 3, bh), QBrush(g))
        p.setFont(_mono(8, QFont.Weight.Normal, 1.2))
        p.setPen(qcol(C.PRI_DIM, 220))
        p.drawText(QRectF(4, 2, w - 8, 12), Qt.AlignmentFlag.AlignLeft,
                   "SPECTRUM ANALYZER")
        p.end()


# ── telemetry ─────────────────────────────────────────────────────────────────
class _Telemetry(QWidget):
    """CPU / MEM / GPU / NET bars plus uptime — repainted every second."""

    ROWS = ("CPU", "MEM", "GPU", "NET")

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setMinimumSize(180, 150)
        self._vals = dict.fromkeys(self.ROWS, 0.0)
        self._t0 = time.time()
        self._last_net = psutil.net_io_counters()
        self._last_t = time.monotonic()

    def refresh(self) -> None:
        try:
            self._vals["CPU"] = psutil.cpu_percent(interval=None) / 100
            self._vals["MEM"] = psutil.virtual_memory().percent / 100
            gpu = _nvml_gpu_windows()
            self._vals["GPU"] = (gpu / 100) if gpu >= 0 else self._vals["GPU"] * 0.97
            now = psutil.net_io_counters()
            dt = max(0.001, time.monotonic() - self._last_t)
            rate = ((now.bytes_sent - self._last_net.bytes_sent)
                    + (now.bytes_recv - self._last_net.bytes_recv)) / dt
            self._last_net, self._last_t = now, time.monotonic()
            self._vals["NET"] = min(1.0, rate / (2.5 * 1024 * 1024))  # 2.5 MB/s full scale
        except Exception:
            pass
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), qcol(C.PANEL, 140))
        p.setPen(QPen(qcol(C.PRI_GHO, 160), 1))
        p.drawRect(QRectF(0.5, 0.5, w - 1, h - 1))

        top = 8
        row_h = (h - top - 26) / len(self.ROWS)
        p.setFont(_mono(9, QFont.Weight.Normal, 1.0))
        for i, key in enumerate(self.ROWS):
            v = min(1.0, self._vals[key])
            y = top + i * row_h
            p.setPen(qcol(C.TEXT_MED, 235))
            p.drawText(QRectF(8, y, 34, 14), Qt.AlignmentFlag.AlignVCenter, key)
            bx, bw2 = 46, w - 84
            p.setPen(Qt.PenStyle.NoPen)
            p.fillRect(QRectF(bx, y + 3, bw2, 8), qcol(C.BAR_BG, 220))
            col = C.GREEN if v < 0.6 else (C.ACC if v < 0.85 else C.RED)
            g = QLinearGradient(bx, 0, bx + bw2, 0)
            g.setColorAt(0, qcol(col, 90)); g.setColorAt(1, qcol(col, 235))
            p.setBrush(QBrush(g))
            p.drawRect(QRectF(bx, y + 3, max(2.0, bw2 * v), 8))
            p.setPen(qcol(C.TEXT_MED, 235))
            p.drawText(QRectF(w - 36, y, 30, 14), Qt.AlignmentFlag.AlignRight
                       | Qt.AlignmentFlag.AlignVCenter, f"{int(v * 100):3d}%")
            # segment ticks over the bar
            p.setPen(QPen(qcol(C.BG, 200), 1))
            for k in range(1, 10):
                x = bx + bw2 * k / 10
                p.drawLine(QPointF(x, y + 3), QPointF(x, y + 11))

        up = int(time.time() - self._t0)
        p.setFont(_mono(9, QFont.Weight.Normal, 1.0))
        p.setPen(qcol(C.PRI_DIM, 230))
        p.drawText(QRectF(8, h - 18, w - 16, 14), Qt.AlignmentFlag.AlignLeft,
                   f"UPTIME {up // 3600:02d}:{(up % 3600) // 60:02d}:{up % 60:02d}")
        p.end()


# ── world map ─────────────────────────────────────────────────────────────────
class _WorldMap(QWidget):
    """Dot-matrix hologram world with live NEXUS beacons — the photo's
    bottom-left global map."""

    # continents as normalised ellipses (cx, cy, rx, ry)
    LAND = (
        (0.205, 0.300, 0.125, 0.105), (0.135, 0.215, 0.062, 0.050),
        (0.300, 0.405, 0.050, 0.042), (0.375, 0.150, 0.036, 0.048),
        (0.300, 0.640, 0.052, 0.125), (0.500, 0.235, 0.048, 0.062),
        (0.520, 0.510, 0.072, 0.135), (0.598, 0.330, 0.058, 0.075),
        (0.725, 0.270, 0.130, 0.100), (0.668, 0.440, 0.030, 0.060),
        (0.762, 0.465, 0.042, 0.048), (0.848, 0.690, 0.052, 0.048),
        (0.858, 0.315, 0.014, 0.038),
    )
    BEACONS = ((0.22, 0.30, "HQ"), (0.52, 0.50, "NEXUS"), (0.74, 0.30, "RELAY"))

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setMinimumSize(180, 110)
        self._t = 0.0

    def tick(self, dt: float) -> None:
        self._t += dt
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), qcol(C.PANEL, 140))
        p.setPen(QPen(qcol(C.PRI_GHO, 160), 1))
        p.drawRect(QRectF(0.5, 0.5, w - 1, h - 1))

        step = 5
        p.setPen(Qt.PenStyle.NoPen)
        y = 6
        while y < h - 6:
            x = 6
            while x < w - 6:
                nx, ny = x / w, y / h
                if any(((nx - a) / b) ** 2 + ((ny - c) / d) ** 2 <= 1.0
                       for a, c, b, d in self.LAND):
                    seed = hashlib.md5(f"{int(x)},{int(y)}".encode()).digest()[0]
                    p.setBrush(qcol(C.PRI, 60 + seed % 90))
                    p.drawEllipse(QPointF(x, y), 1.1, 1.1)
                x += step
            y += step

        # beacons
        p.setFont(_mono(8, QFont.Weight.Bold, 1.0))
        for nx, ny, label in self.BEACONS:
            x, y = nx * w, ny * h
            blink = 0.5 + 0.5 * math.sin(self._t * 3 + x)
            p.setPen(QPen(qcol(C.ACC, int(120 + 120 * blink)), 1.2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QPointF(x, y), 5 + 2 * blink, 5 + 2 * blink)
            p.setBrush(qcol(C.ACC, 230))
            p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QPointF(x, y), 1.6, 1.6)
            p.setPen(qcol(C.ACC, 220))
            p.drawText(QPointF(x + 8, y + 3), label)
        p.end()


# ── big stat block (the photo's giant "24") ───────────────────────────────────
class _StatBig(QWidget):
    """Huge numeric readout with a ring behind it — session uptime hours and
    the count of worlds bound into the Brain."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setMinimumSize(150, 130)
        self._t0 = time.time()
        self._links = 0
        self._phase = 0.0

    def tick(self, dt: float) -> None:
        self._phase = (self._phase + dt * 30) % 360
        self.update()

    def refresh(self) -> None:
        self._links = _nexus_link_count()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), qcol(C.PANEL, 140))
        p.setPen(QPen(qcol(C.PRI_GHO, 160), 1))
        p.drawRect(QRectF(0.5, 0.5, w - 1, h - 1))

        # dashed rotating ring behind the number
        cx, cy, R = w / 2, h / 2 + 4, min(w, h) / 2 - 10
        p.setPen(QPen(qcol(C.PRI, 90), 1, Qt.PenStyle.DashLine))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(cx, cy), R, R)
        p.setPen(QPen(qcol(C.BORDER_B, 200), 2))
        p.drawEllipse(QPointF(cx, cy), R, R, )  # noqa: FURB123 - keep static ring
        a0 = int(self._phase * 16)
        p.drawArc(QRectF(cx - R, cy - R, R * 2, R * 2), a0, 100 * 16)
        p.drawArc(QRectF(cx - R, cy - R, R * 2, R * 2), a0 + 180 * 16, 100 * 16)

        hrs = (time.time() - self._t0) / 3600
        p.setFont(_mono(int(min(w, h) * 0.34), QFont.Weight.DemiBold, 1.0))
        p.setPen(qcol(C.WHITE, 245))
        p.drawText(QRectF(0, cy - R * 0.75, w, R * 1.2),
                   Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter,
                   f"{hrs:.1f}")

        p.setFont(_mono(9, QFont.Weight.Bold, 2.0))
        p.setPen(qcol(C.ACC, 235))
        p.drawText(QRectF(0, cy + R * 0.52, w, 14),
                   Qt.AlignmentFlag.AlignHCenter, "HRS ONLINE")
        p.setFont(_mono(8, QFont.Weight.Normal, 1.2))
        p.setPen(qcol(C.PRI_DIM, 230))
        p.drawText(QRectF(0, h - 16, w, 12),
                   Qt.AlignmentFlag.AlignHCenter, f"NEXUS LINKS  {self._links}")
        p.end()


# ── top bar ───────────────────────────────────────────────────────────────────
class _TopBar(QWidget):
    """Stark-industries header: logo, live clock, date, protocol badge."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setFixedHeight(46)
        self._state = "SLEEPING"
        self._muted = False

    def set_state(self, s: str) -> None:
        self._state = s
        self.update()

    def set_muted(self, m: bool) -> None:
        self._muted = m
        self.update()

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        g = QLinearGradient(0, 0, 0, h)
        g.setColorAt(0, qcol(C.PANEL2, 230)); g.setColorAt(1, qcol(C.BG, 200))
        p.fillRect(self.rect(), QBrush(g))

        # hex logo
        hx, hy, hr = 26, h / 2, 11
        path = QPainterPath()
        for i in range(6):
            a = math.radians(60 * i - 30)
            pt = QPointF(hx + math.cos(a) * hr, hy + math.sin(a) * hr)
            (path.moveTo if i == 0 else path.lineTo)(pt)
        path.closeSubpath()
        p.setPen(QPen(qcol(C.ACC, 235), 1.6))
        p.setBrush(qcol(C.ACC, 40))
        p.drawPath(path)
        p.setBrush(qcol(C.ACC, 235)); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(hx, hy), 3, 3)

        p.setFont(_mono(13, QFont.Weight.DemiBold, 4.0))
        p.setPen(qcol(C.WHITE, 240))
        p.drawText(QRectF(46, 0, 260, h), Qt.AlignmentFlag.AlignVCenter,
                   "STARK INDUSTRIES")
        p.setFont(_mono(8, QFont.Weight.Normal, 2.0))
        p.setPen(qcol(C.PRI_DIM, 230))
        p.drawText(QRectF(48, h - 15, 260, 12), Qt.AlignmentFlag.AlignVCenter,
                   "J.A.R.V.I.S.  KERNEL  //  MK.LIV")

        # centred clock — the photo's big 09:01:12
        now = time.localtime()
        clock = time.strftime("%H:%M:%S", now)
        p.setFont(_mono(21, QFont.Weight.DemiBold, 3.0))
        p.setPen(qcol(C.BORDER_B, 245))
        p.drawText(QRectF(w / 2 - 130, 0, 260, h - 6),
                   Qt.AlignmentFlag.AlignCenter, clock)
        p.setFont(_mono(8, QFont.Weight.Normal, 2.4))
        p.setPen(qcol(C.PRI_DIM, 220))
        p.drawText(QRectF(w / 2 - 130, h - 14, 260, 12),
                   Qt.AlignmentFlag.AlignCenter, time.strftime("%a %d %b %Y", now))

        # protocol badge right
        p.setFont(_mono(10, QFont.Weight.Bold, 2.4))
        p.setPen(qcol(C.ACC, 240))
        p.drawText(QRectF(w - 220, 0, 150, h), Qt.AlignmentFlag.AlignRight
                   | Qt.AlignmentFlag.AlignVCenter, APP_VERSION)

        # status dot + state
        col = C.MUTED_C if self._muted else {
            "LISTENING": C.GREEN, "SPEAKING": C.ACC2,
            "THINKING": C.ACC, "SLEEPING": C.PRI_DIM,
        }.get(self._state, C.PRI)
        p.setBrush(qcol(col, 240)); p.setPen(Qt.PenStyle.NoPen)
        p.drawEllipse(QPointF(w - 58, h / 2), 4, 4)
        p.setFont(_mono(9, QFont.Weight.Bold, 1.6))
        p.setPen(qcol(col, 245))
        p.drawText(QRectF(w - 170, 0, 106, h), Qt.AlignmentFlag.AlignRight
                   | Qt.AlignmentFlag.AlignVCenter,
                   "MUTED" if self._muted else self._state)

        # baseline + ticks
        p.setPen(QPen(qcol(C.PRI, 120), 1))
        p.drawLine(QPointF(0, h - 1), QPointF(w, h - 1))
        p.setPen(QPen(qcol(C.PRI_DIM, 130), 1))
        x = 6
        while x < w:
            p.drawLine(QPointF(x, h - 5), QPointF(x, h - 1))
            x += 26
        p.end()


# ══════════════════════════════════════════════════════════════════════════════
#  LOCK SYSTEM — HUD access code (minimum 3 characters, salted PBKDF2)
# ══════════════════════════════════════════════════════════════════════════════
LOCK_FILE = CONFIG_DIR / "lock.json"


def _lock_read() -> dict:
    try:
        return json.loads(LOCK_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _lock_write(data: dict) -> None:
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        LOCK_FILE.write_text(json.dumps(data, indent=4), encoding="utf-8")
    except Exception:
        pass


def _lock_hash(pw: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"),
                               bytes.fromhex(salt), 100_000).hex()


def lock_is_set() -> bool:
    d = _lock_read()
    return bool(d.get("salt") and d.get("hash"))


def lock_set_password(pw: str) -> None:
    import os as _os
    salt = _os.urandom(16).hex()
    _lock_write({"salt": salt, "hash": _lock_hash(pw, salt)})


def lock_verify(pw: str) -> bool:
    import hmac as _hmac
    d = _lock_read()
    if not (d.get("salt") and d.get("hash")):
        return False
    return _hmac.compare_digest(_lock_hash(pw, d["salt"]), d["hash"])


class _LockScreen(QWidget):
    """Full-window lock overlay. First run: create the access code (min 3).
    Afterwards the HUD boots locked and opens only on the right code."""

    def __init__(self, window):
        super().__init__(window)
        self._win = window
        self._mode = "set" if not lock_is_set() else "unlock"
        self._deny_until = 0.0

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 24, 24, 24)
        lay.addStretch(3)

        self.title = QLabel("STARK OS")
        self.title.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.title.setFont(_mono(26, QFont.Weight.DemiBold, 8.0))
        self.title.setStyleSheet(f"color: {C.WHITE};")
        lay.addWidget(self.title)

        self.sub = QLabel("")
        self.sub.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.sub.setFont(_mono(10, QFont.Weight.Normal, 2.0))
        self.sub.setStyleSheet(f"color: {C.TEXT_DIM};")
        lay.addWidget(self.sub)

        box = QWidget()
        box.setFixedWidth(340)
        bl = QVBoxLayout(box)
        bl.setContentsMargins(0, 10, 0, 0)
        bl.setSpacing(8)

        field_ss = (f"QLineEdit {{ background-color: {C.PANEL}; color: {C.WHITE};"
                    f" border: 1px solid {C.BORDER}; padding: 10px 12px;"
                    f" font-family: 'Consolas',monospace; font-size: 14px;"
                    f" letter-spacing: 3px; }}"
                    f"QLineEdit:focus {{ border-color: {C.BORDER_B}; }}")

        self.pw1 = QLineEdit()
        self.pw1.setEchoMode(QLineEdit.EchoMode.Password)
        self.pw1.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.pw1.setStyleSheet(field_ss)
        self.pw1.returnPressed.connect(self._action)
        bl.addWidget(self.pw1)

        self.pw2 = QLineEdit()
        self.pw2.setEchoMode(QLineEdit.EchoMode.Password)
        self.pw2.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.pw2.setStyleSheet(field_ss)
        self.pw2.returnPressed.connect(self._action)
        bl.addWidget(self.pw2)

        self.btn = QPushButton("CREATE ACCESS CODE")
        self.btn.setStyleSheet(
            f"QPushButton {{ background-color: {C.PANEL2}; color: {C.ACC};"
            f" border: 1px solid {C.ACC}; padding: 9px;"
            f" font-family: 'Consolas',monospace; font-size: 12px;"
            f" letter-spacing: 2px; }}"
            f"QPushButton:hover {{ color: {C.WHITE}; }}")
        self.btn.clicked.connect(self._action)
        bl.addWidget(self.btn)

        self.msg = QLabel("")
        self.msg.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.msg.setFont(_mono(10, QFont.Weight.Bold, 1.5))
        bl.addWidget(self.msg)

        lay.addWidget(box, 0, Qt.AlignmentFlag.AlignHCenter)
        lay.addStretch(4)

        self._apply_mode()

    # ── mode ───────────────────────────────────────────────────────────────
    def _apply_mode(self):
        if self._mode == "set":
            self.title.setText("CREATE ACCESS CODE")
            self.sub.setText("Choose a code to lock this HUD — minimum 3 characters.")
            self.pw1.setPlaceholderText("new access code")
            self.pw2.setPlaceholderText("repeat access code")
            self.pw2.show()
            self.btn.setText("CREATE ACCESS CODE")
        else:
            self.title.setText("RESTRICTED ACCESS")
            self.sub.setText("Enter the access code to engage J.A.R.V.I.S.")
            self.pw1.setPlaceholderText("access code")
            self.pw2.hide()
            self.btn.setText("UNLOCK")
        self.msg.setText("")
        self.pw1.clear()
        self.pw2.clear()
        self.pw1.setFocus()

    def engage(self):
        """Lock now (or create a code first if none exists)."""
        self._mode = "set" if not lock_is_set() else "unlock"
        self._apply_mode()
        pw = self.parentWidget()
        if pw is not None:
            self.setGeometry(0, 0, max(1, pw.width()), max(1, pw.height()))
        self.show()
        self.raise_()
        self._win._locked = True

    # ── actions ────────────────────────────────────────────────────────────
    def _action(self):
        if self._mode == "set":
            p1, p2 = self.pw1.text().strip(), self.pw2.text().strip()
            if len(p1) < 3:
                self._deny("MINIMUM 3 CHARACTERS")
                return
            if p1 != p2:
                self._deny("CODES DO NOT MATCH")
                return
            lock_set_password(p1)
            self._mode = "unlock"
            self._apply_mode()
            self.msg.setStyleSheet(f"color: {C.GREEN};")
            self.msg.setText("CODE CREATED — UNLOCK TO CONTINUE")
            return
        if lock_verify(self.pw1.text()):
            self.hide()
            self._win._locked = False
            self._win.write_log("SYS: Access granted — welcome back, sir.")
            try:
                self._win.input_box.setFocus()
            except Exception:
                pass
        else:
            self._deny("ACCESS DENIED — WRONG CODE")

    def _deny(self, text: str):
        self._deny_until = time.time() + 1.2
        self.msg.setStyleSheet(f"color: {C.RED};")
        self.msg.setText(text)
        self.pw1.clear()
        self.pw2.clear()
        self.pw1.setFocus()
        self.update()
        QTimer.singleShot(1300, self.update)   # clear the red-bracket flash

    # ── paint ──────────────────────────────────────────────────────────────
    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        p.fillRect(self.rect(), qcol(C.BG, 242))
        p.setPen(QPen(qcol(C.PRI, 10), 1))
        x = 0
        while x < w:
            p.drawLine(x, 0, x, h)
            x += 28
        y = 0
        while y < h:
            p.drawLine(0, y, w, y)
            y += 28
        _draw_scanlines(p, QRectF(0, 0, w, h), 3, 9)
        deny = time.time() < self._deny_until
        _draw_brackets(p, QRectF(8, 8, w - 16, h - 16), 26,
                       C.RED if deny else C.PRI, 2.0)
        p.end()


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN SYSTEM HUD WINDOW
# ══════════════════════════════════════════════════════════════════════════════
class _HUDRoot(QWidget):
    """Backdrop canvas: deep-space gradient, faint blueprint grid, scanlines."""

    def paintEvent(self, _e) -> None:                     # noqa: N802
        p = QPainter(self)
        w, h = self.width(), self.height()
        g = QLinearGradient(0, 0, 0, h)
        g.setColorAt(0.0, qcol(C.PANEL2, 255))
        g.setColorAt(0.5, qcol(C.BG, 255))
        g.setColorAt(1.0, QColor(0, 3, 7, 255))
        p.fillRect(self.rect(), QBrush(g))

        # faint blueprint grid
        p.setPen(QPen(qcol(C.PRI, 9), 1))
        x = 0
        while x < w:
            p.drawLine(x, 0, x, h); x += 28
        y = 0
        while y < h:
            p.drawLine(0, y, w, y); y += 28
        p.setPen(QPen(qcol(C.PRI, 16), 1))
        x = 0
        while x < w:
            p.drawLine(x, 0, x, h); x += 140
        y = 0
        while y < h:
            p.drawLine(0, y, w, y); y += 140

        _draw_scanlines(p, QRectF(0, 0, w, h), 3, 8)
        _draw_brackets(p, QRectF(4, 4, w - 8, h - 8), 18, C.PRI_GHO, 1.2)
        p.end()


class MarkLV_HUDWindow(QMainWindow):
    """The Stark HUD: arc-reactor dial, tactical radar, telemetry, world map,
    oscilloscope, spectrum, big stat block and the console — with type-to-talk,
    INTERRUPT / MUTE keybinds and every hook the assistant core drives.

    Keybinds (window-focused):
      Ctrl+I — interrupt: stop JARVIS mid-sentence, mic opens immediately
      Ctrl+M — mute / un-mute: he hears you, but stays silent
      Ctrl+L — clear the console feed
      Enter (in the input box) — send the typed line as a spoken command
    """

    # Thread-safe bridges: the asyncio core logs and states from its own
    # thread — signals marshal everything onto the Qt thread.
    _sigLog    = pyqtSignal(str)
    _sigState  = pyqtSignal(str)
    _sigLevel  = pyqtSignal(float)
    _sigViseme = pyqtSignal(list, float, float)
    _sigContent = pyqtSignal(str, str)
    _sigConfirm = pyqtSignal(str, str)
    _sigHideConfirm = pyqtSignal()
    _sigReconfig = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_VERSION}  //  J.A.R.V.I.S. HUD")
        self.setMinimumSize(_MIN_W, _MIN_H)
        self.resize(_DEFAULT_W, _DEFAULT_H)
        self.setAcceptDrops(True)

        # ── hook contracts the assistant core assigns at boot ─────────────
        self.on_text_command = None      # fn(text) — typed line from the box
        self.on_interrupt    = None      # fn()     — INTERRUPT button / Ctrl+I
        self.on_push_to_talk = None      # fn(bool) — PTP enable/disable
        self.ptt_hold        = None      # fn(bool) — chord press/release
        self.on_mode_changed = None      # fn(mode) — persona repaint hook
        self.on_voice_change = None      # fn()     — voice picker applied
        self.on_audio_device_change = None
        self.on_remote_clicked = None    # fn()     — phone-dashboard key
        self.on_wake_toggle = self.on_wake_manual = None
        self.on_wake_install = None
        self.wake_is_ready = self.wake_get_state = None
        self.get_plugins = self.get_plugin_settings = None
        self.request_say = None          # plugins' mid-task speech channel

        self.muted = False               # True → JARVIS hears, never speaks
        self.current_file = ""           # last file dropped on the window
        self._state = "SLEEPING"
        self._mode = ""
        self._speaking = False

        # The auth-retry loop waits on `ui._win._ready` — keep the contract.
        self._win = self
        self._ready = True

        # Wire the thread-safe bridges BEFORE anything can emit them.
        self._sigLog.connect(self._do_log)
        self._sigState.connect(self._do_state)
        self._sigLevel.connect(self._do_level)
        self._sigViseme.connect(self._do_visemes)
        self._sigContent.connect(self._do_content)
        self._sigConfirm.connect(self._do_confirm)
        self._sigHideConfirm.connect(self._do_hide_confirm)
        self._sigReconfig.connect(self._do_reconfig)

        # ── frame ──────────────────────────────────────────────────────────
        root = _HUDRoot()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(10, 8, 10, 10)
        outer.setSpacing(8)

        self.topbar = _TopBar()
        outer.addWidget(self.topbar)

        body = QHBoxLayout()
        body.setSpacing(8)
        outer.addLayout(body, stretch=1)

        # ── LEFT column: radar + telemetry ─────────────────────────────────
        left = QVBoxLayout(); left.setSpacing(8)
        pan_radar = HoloPanel("TACTICAL SWEEP")
        lr = QVBoxLayout(pan_radar); lr.setContentsMargins(6, 20, 6, 6)
        self.radar = _Radar()
        lr.addWidget(self.radar, stretch=3)
        pan_map = HoloPanel("GLOBAL NEXUS")
        lm = QVBoxLayout(pan_map); lm.setContentsMargins(6, 20, 6, 6)
        self.worldmap = _WorldMap()
        lm.addWidget(self.worldmap)
        pan_tel = HoloPanel("SYSTEM VITALS")
        lt = QVBoxLayout(pan_tel); lt.setContentsMargins(6, 20, 6, 6)
        self.telemetry = _Telemetry()
        lt.addWidget(self.telemetry)
        left.addWidget(pan_radar, stretch=5)
        left.addWidget(pan_map, stretch=4)
        left.addWidget(pan_tel, stretch=5)
        lw = QWidget(); lw.setLayout(left); lw.setFixedWidth(236)
        body.addWidget(lw)

        # ── CENTER: console + confirm + content + settings + input ────────
        self._center_col = QVBoxLayout(); self._center_col.setSpacing(8)
        pan_con = HoloPanel("J.A.R.V.I.S.  CONSOLE  //  LIVE FEED")
        lc = QVBoxLayout(pan_con); lc.setContentsMargins(6, 22, 6, 6)
        self.console_feed = QTextEdit()
        self.console_feed.setReadOnly(True)
        self.console_feed.setFrameShape(QFrame.Shape.NoFrame)
        self.console_feed.setStyleSheet(
            f"QTextEdit {{ background: transparent; color: {C.TEXT};"
            f" font-family: 'Consolas','Courier New',monospace; font-size: 12.5px;"
            f" selection-background-color: {C.PRI_GHO}; }}")
        lc.addWidget(self.console_feed)
        self._center_col.addWidget(pan_con, stretch=10)

        # confirm gate
        self.confirm_banner = QLabel("")
        self.confirm_banner.setStyleSheet(
            f"QLabel {{ background: {C.PANEL2}; color: {C.ACC};"
            f" border: 1px solid {C.ACC}; padding: 8px 12px;"
            f" font-family: 'Consolas',monospace; font-size: 12px; }}")
        self.confirm_banner.hide()
        self._center_col.addWidget(self.confirm_banner)
        confirm_row = QHBoxLayout()
        self.btn_confirm = QPushButton("✔ CONFIRM")
        self.btn_cancel  = QPushButton("✕ CANCEL")
        confirm_row.addWidget(self.btn_confirm)
        confirm_row.addWidget(self.btn_cancel)
        confirm_row.addStretch(1)
        self._center_col.addLayout(confirm_row)
        self._confirm_row = confirm_row
        self.btn_confirm.clicked.connect(self._resolve_confirm_true)
        self.btn_cancel.clicked.connect(self._resolve_confirm_false)
        self._hide_confirm_buttons()

        # content panel (news, search results, file text)
        self.content_feed = QTextEdit()
        self.content_feed.setReadOnly(True)
        self.content_feed.setVisible(False)
        self.content_feed.setPlaceholderText("content // news · search · files")
        self.content_feed.setStyleSheet(
            f"QTextEdit {{ background-color: {C.PANEL}; color: {C.WHITE};"
            f" border: 1px solid {C.BORDER_A}; font-family: 'Consolas',monospace;"
            f" font-size: 12px; }}")
        self._center_col.addWidget(self.content_feed, stretch=6)

        # settings drawer: keybinds + voice/typed commands
        self.settings_panel = QTextEdit()
        self.settings_panel.setReadOnly(True)
        self.settings_panel.setVisible(False)
        self.settings_panel.setFixedHeight(210)
        self.settings_panel.setStyleSheet(
            f"QTextEdit {{ background-color: {C.PANEL}; color: {C.TEXT};"
            f" border: 1px solid {C.BORDER}; font-family: 'Consolas',monospace;"
            f" font-size: 11.5px; }}")
        self._fill_settings()
        # settings drawer = keybind/command reference + credential controls
        settings_box = QWidget()
        sb = QVBoxLayout(settings_box)
        sb.setContentsMargins(0, 0, 0, 0)
        sb.setSpacing(6)
        sb.addWidget(self.settings_panel)
        cred_row = QHBoxLayout()
        cred_row.setSpacing(8)
        self.btn_api = QPushButton("🔑 API KEY")
        self.btn_code = QPushButton("🗝 CHANGE CODE")
        cred_row.addWidget(self.btn_api)
        cred_row.addWidget(self.btn_code)
        cred_row.addStretch(1)
        sb.addLayout(cred_row)
        self._settings_box = settings_box
        self._center_col.addWidget(self._settings_box)
        self.btn_api.clicked.connect(self._set_api_key)
        self.btn_code.clicked.connect(self._change_code)

        # typed input deck
        inrow = QHBoxLayout(); inrow.setSpacing(8)
        self.input_box = QLineEdit()
        self.input_box.setPlaceholderText(
            "Type to talk — Enter sends to J.A.R.V.I.S. (try: spread ur roots · mute · forge me a game)")
        self.input_box.setStyleSheet(
            f"QLineEdit {{ background-color: {C.PANEL}; color: {C.WHITE};"
            f" border: 1px solid {C.BORDER}; padding: 10px 12px;"
            f" font-family: 'Consolas',monospace; font-size: 13px;"
            f" selection-background-color: {C.PRI_GHO}; }}"
            f"QLineEdit:focus {{ border-color: {C.BORDER_B}; }}")
        self.input_box.returnPressed.connect(self._send_typed)
        inrow.addWidget(self.input_box, stretch=1)
        self.btn_send = QPushButton("SEND ⏎")
        self.btn_send.clicked.connect(self._send_typed)
        inrow.addWidget(self.btn_send)
        self._center_col.addLayout(inrow)

        cw = QWidget(); cw.setLayout(self._center_col)
        body.addWidget(cw, stretch=1)

        # ── RIGHT column: reactor + wave + spectrum + stat ─────────────────
        right = QVBoxLayout(); right.setSpacing(8)
        pan_react = HoloPanel("ARC REACTOR  //  CORE")
        lr2 = QVBoxLayout(pan_react); lr2.setContentsMargins(4, 20, 4, 4)
        self.reactor = _ReactorDial()
        lr2.addWidget(self.reactor)
        right.addWidget(pan_react, stretch=10)

        pan_wave = HoloPanel("AUDIO")
        lw2 = QVBoxLayout(pan_wave); lw2.setContentsMargins(4, 20, 4, 4)
        self.wave = _WaveScope()
        lw2.addWidget(self.wave)
        right.addWidget(pan_wave, stretch=3)

        pan_spec = HoloPanel("SPECTRUM")
        ls = QVBoxLayout(pan_spec); ls.setContentsMargins(4, 20, 4, 4)
        self.spectrum = _Spectrum()
        ls.addWidget(self.spectrum)
        right.addWidget(pan_spec, stretch=3)

        pan_stat = HoloPanel("SESSION")
        lst = QVBoxLayout(pan_stat); lst.setContentsMargins(4, 20, 4, 4)
        self.statbig = _StatBig()
        lst.addWidget(self.statbig)
        right.addWidget(pan_stat, stretch=5)
        rw = QWidget(); rw.setLayout(right); rw.setFixedWidth(252)
        body.addWidget(rw)

        # ── control deck ───────────────────────────────────────────────────
        deck = QHBoxLayout(); deck.setSpacing(8)
        self.btn_interrupt = QPushButton("■ INTERRUPT  (Ctrl+I)")
        self.btn_mute = QPushButton("◉ TALKING  (Ctrl+M)")
        self.btn_content = QPushButton("▤ CONTENT")
        self.btn_remote = QPushButton("⌁ REMOTE")
        self.btn_forge = QPushButton("⚒ FORGE")
        self.btn_settings = QPushButton("⚙ SETTINGS")
        self.btn_lock = QPushButton("🔒 LOCK")
        self.btn_mute.setObjectName("btn_mute")
        self.btn_forge.setObjectName("btn_forge")
        for b in (self.btn_interrupt, self.btn_mute, self.btn_content,
                  self.btn_remote, self.btn_forge, self.btn_settings, self.btn_lock):
            deck.addWidget(b)
        deck.addStretch(1)
        self.state_label = QLabel("SLEEPING")
        self.state_label.setFont(_mono(11, QFont.Weight.Bold, 2.0))
        deck.addWidget(self.state_label)
        outer.addLayout(deck)

        self._style_buttons()

        self.btn_interrupt.clicked.connect(self._fire_interrupt)
        self.btn_mute.clicked.connect(self._toggle_mute)
        self.btn_content.clicked.connect(self._toggle_content)
        self.btn_remote.clicked.connect(self._fire_remote)
        self.btn_forge.clicked.connect(self._open_forge)
        self.btn_settings.clicked.connect(self._toggle_settings)
        self.btn_lock.clicked.connect(self.lock_now)

        # ── keybinds (window-scope; the OS-wide PTT chord is polled globally)
        QShortcut(QKeySequence("Ctrl+I"), self).activated.connect(self._fire_interrupt)
        QShortcut(QKeySequence("Ctrl+M"), self).activated.connect(self._toggle_mute)
        QShortcut(QKeySequence("Ctrl+L"), self).activated.connect(self.console_feed.clear)

        # ── animation clocks ───────────────────────────────────────────────
        self._t_last = time.monotonic()
        self._clock = QTimer(self)
        self._clock.timeout.connect(self._on_tick)
        self._clock.start(40)                      # 25 fps hologram refresh

        self._slow = QTimer(self)
        self._slow.timeout.connect(self._on_slow_tick)
        self._slow.start(1000)                     # telemetry + clock repaint

        self._initial_log()

        # ── lock screen — boots locked; first run creates the access code ─
        self._locked = True
        self.locker = _LockScreen(self)
        self.locker.setGeometry(0, 0, self.width(), self.height())
        self.locker.show()
        self.locker.raise_()

    # ── styling ────────────────────────────────────────────────────────────
    def _style_buttons(self):
        base = (f"QPushButton {{ background-color: {C.PANEL2}; color: {C.TEXT};"
                f" border: 1px solid {C.BORDER}; padding: 8px 13px;"
                f" font-family: 'Consolas',monospace; font-size: 11px;"
                f" letter-spacing: 1px; }}"
                f"QPushButton:hover {{ border-color: {C.BORDER_B}; color: {C.WHITE};"
                f" background-color: {C.PRI_GHO}; }}"
                f"QPushButton:pressed {{ background-color: {C.PRI_GHO}; }}")
        for b in (self.btn_interrupt, self.btn_content, self.btn_remote,
                  self.btn_lock, self.btn_settings, self.btn_send,
                  self.btn_confirm, self.btn_cancel):
            b.setStyleSheet(base)
        self.btn_forge.setStyleSheet(
            f"QPushButton {{ background-color: {C.PANEL2}; color: {C.ACC};"
            f" border: 1px solid {C.ACC}; padding: 8px 13px;"
            f" font-family: 'Consolas',monospace; font-size: 11px;"
            f" letter-spacing: 1px; }}"
            f"QPushButton:hover {{ color: {C.WHITE}; border-color: {C.ACC}; }}")
        self._paint_mute_button()

    def _paint_mute_button(self):
        col = C.MUTED_C if self.muted else C.GREEN
        self.btn_mute.setStyleSheet(
            f"QPushButton {{ background-color: {C.PANEL2}; color: {col};"
            f" border: 1px solid {col}; padding: 8px 13px;"
            f" font-family: 'Consolas',monospace; font-size: 11px;"
            f" letter-spacing: 1px; }}"
            f"QPushButton:hover {{ color: {C.WHITE}; }}")
        self.btn_mute.setText("◉ MUTED  (Ctrl+M)" if self.muted
                              else "◉ TALKING  (Ctrl+M)")

    # ── boot banner ────────────────────────────────────────────────────────
    def _initial_log(self):
        self.write_log(f"SYS: {APP_VERSION} holographic HUD online — type to talk,"
                       " or hold Ctrl+Space for push-to-talk.")
        self.write_log("SYS: Ctrl+I interrupt · Ctrl+M mute · Ctrl+L clear console.")

    # ── animation ticks ────────────────────────────────────────────────────
    def _on_tick(self):
        now = time.monotonic()
        dt = min(0.1, now - self._t_last)
        self._t_last = now
        self.reactor.tick(dt)
        self.radar.tick(dt)
        self.worldmap.tick(dt)
        self.wave.tick(dt)
        self.spectrum.tick(dt)
        self.statbig.tick(dt)

    def _on_slow_tick(self):
        self.telemetry.refresh()
        self.statbig.refresh()
        self.topbar.update()

    # ── typed input ────────────────────────────────────────────────────────
    def _send_typed(self):
        text = self.input_box.text().strip()
        if not text:
            return
        self.input_box.clear()
        self.write_log(f"You: {text}")
        cb = self.on_text_command
        if cb:
            try:
                cb(text)
            except Exception as e:
                self.write_log(f"ERR: input dispatch — {e}")
        else:
            self.write_log("SYS: Assistant not connected yet.")

    # ── interrupt / mute ───────────────────────────────────────────────────
    def _fire_interrupt(self):
        cb = self.on_interrupt
        if cb:
            try:
                cb()
            except Exception as e:
                self.write_log(f"ERR: interrupt — {e}")
        else:
            self.write_log("SYS: Interrupt requested (no session yet).")

    def _toggle_mute(self):
        self.set_muted_ui(not self.muted)

    def set_muted_ui(self, value: bool):
        """UI-side mute: repaint the controls, remember the state. The audio
        gate reads `ui.muted` directly, so this alone is the whole mute."""
        self.muted = bool(value)
        self._paint_mute_button()
        self.topbar.set_muted(self.muted)

    # ── content / forge / settings / remote / wake ─────────────────────────
    def _toggle_content(self):
        self.content_feed.setVisible(not self.content_feed.isVisible())

    def _open_forge(self):
        """The Forge — describe it, JARVIS builds it with the free AIs and it
        lands in ~/Documents/JARVISForge + The Inside as a FORGED world."""
        text, ok = QInputDialog.getText(
            self, "⚒ THE FORGE",
            "Describe what to build — a website, a game, a tool…\n"
            "(built with free AIs: Groq / OpenRouter / Gemini)")
        if not (ok and text.strip()):
            return
        text = text.strip()
        kind = "game" if "game" in text.lower() else "website"
        self.write_log(f"You: forge me a {kind} about {text}")
        if self.on_text_command:
            try:
                self.on_text_command(f"forge me a {kind} about {text}")
            except Exception as e:
                self.write_log(f"ERR: forge dispatch — {e}")

    def _toggle_settings(self):
        self._settings_box.setVisible(not self._settings_box.isVisible())

    def _fill_settings(self):
        self.settings_panel.setHtml(f"""
        <div style="font-family:'Consolas','Courier New',monospace; font-size:11.5px; line-height:1.7">
        <div style="color:{C.ACC}; letter-spacing:2px;">KEYBINDS</div>
        <div style="color:{C.WHITE}">Ctrl+I</div> interrupt JARVIS mid-sentence &nbsp;·&nbsp;
        <div style="color:{C.WHITE}">Ctrl+M</div> mute / un-mute his voice &nbsp;·&nbsp;
        <div style="color:{C.WHITE}">Ctrl+L</div> clear this console &nbsp;·&nbsp;
        <div style="color:{C.WHITE}">Ctrl+Space (hold)</div> push-to-talk &nbsp;·&nbsp;
        <div style="color:{C.WHITE}">Enter</div> send the typed line
        <div style="color:{C.ACC}; letter-spacing:2px; margin-top:8px;">VOICE / TYPED COMMANDS</div>
        <div style="color:{C.GREEN}">"spread ur roots"</div> opens The Inside — he replies <i>Done, sir.</i><br>
        <div style="color:{C.GREEN}">"add this to roots"</div> binds the site on your clipboard into the Brain<br>
        <div style="color:{C.GREEN}">"add myshop.com to the nexus"</div> bind any site — unlimited links<br>
        <div style="color:{C.GREEN}">"mute yourself" / "unmute"</div> silence / restore his voice<br>
        <div style="color:{C.GREEN}">"forge me a website about …"</div> build a site with the free AIs<br>
        <div style="color:{C.GREEN}">"forge me a game …"</div> build a playable game<br>
        <div style="color:{C.GREEN}">"what's on my nexus"</div> list every link in the Brain<br>
        <div style="color:{C.GREEN}">"serious mode" / "standard mode"</div> switch his personality<br>
        <div style="color:{C.GREEN}">"stop"</div> halt the current task (and revert one step)
        <div style="color:{C.ACC}; letter-spacing:2px; margin-top:8px;">DECK / SECURITY</div>
        <div style="color:{C.WHITE}">🔑 API KEY</div> store your Gemini key in config/api_keys.json &nbsp;·&nbsp;
        <div style="color:{C.WHITE}">🗝 CHANGE CODE</div> set the HUD lock code (minimum 3 characters) &nbsp;·&nbsp;
        <div style="color:{C.WHITE}">🔒 LOCK</div> lock this HUD behind the access code
        </div>""")

    # ── credentials (settings drawer) ──────────────────────────────────────
    def _set_api_key(self):
        key, ok = QInputDialog.getText(
            self, "🔑 Gemini API key",
            "Stored in config/api_keys.json — used by the voice core:",
            QLineEdit.EchoMode.Password)
        if not (ok and key.strip()):
            return
        try:
            cfg = _read_full_config()
            cfg["gemini_api_key"] = key.strip()
            API_FILE.parent.mkdir(parents=True, exist_ok=True)
            API_FILE.write_text(json.dumps(cfg, indent=4), encoding="utf-8")
            self.write_log("SYS: Gemini API key saved — applies on the next session rebuild.")
        except Exception as e:
            self.write_log(f"ERR: saving API key — {e}")

    def _change_code(self):
        if lock_is_set():
            cur, ok = QInputDialog.getText(
                self, "🗝 Current access code",
                "Enter the current access code:", QLineEdit.EchoMode.Password)
            if not (ok and lock_verify(cur)):
                self.write_log("SYS: Access code unchanged — wrong code.")
                return
        new, ok = QInputDialog.getText(
            self, "🗝 New access code",
            "New access code (minimum 3 characters):", QLineEdit.EchoMode.Password)
        if not ok:
            return
        new = new.strip()
        if len(new) < 3:
            self.write_log("SYS: Access code must be at least 3 characters.")
            return
        lock_set_password(new)
        self.write_log("SYS: Access code updated — 🔒 LOCK seals this HUD with it.")

    # ── lock system ────────────────────────────────────────────────────────
    def lock_now(self):
        self.locker.engage()
        self.write_log("SYS: HUD locked.")

    def _fire_remote(self):
        cb = self.on_remote_clicked
        if cb:
            try:
                cb()
            except Exception as e:
                self.write_log(f"ERR: remote — {e}")

    def _fire_wake(self):
        cb = self.on_wake_manual
        if cb:
            try:
                cb()
            except Exception:
                pass

    # ── thread-safe bridges (called from the asyncio core) ─────────────────
    def write_log(self, msg: str):
        self._sigLog.emit(str(msg))

    def _do_log(self, msg: str):
        import html as _html
        esc = _html.escape(msg)
        if msg.startswith("You:"):
            col, bold = C.WHITE, True
        elif msg.startswith("ERR:"):
            col, bold = C.RED, True
        elif msg.startswith("CONFIRM"):
            col, bold = C.ACC, True
        elif msg.startswith("SYS:"):
            col, bold = C.PRI, False
        else:
            col, bold = C.TEXT_MED, False
        w = "font-weight:bold;" if bold else ""
        self.console_feed.append(
            f"<span style='color:{col};{w}'>{esc}</span>")

    def set_state(self, state: str):
        self._sigState.emit(str(state))

    def _do_state(self, state: str):
        self._state = state
        self.topbar.set_state(state)
        self.reactor.set_state(state)
        self.state_label.setText(state)
        col = {"LISTENING": C.GREEN, "SPEAKING": C.ACC2,
               "THINKING": C.ACC, "SLEEPING": C.PRI_DIM}.get(state, C.PRI)
        self.state_label.setStyleSheet(f"color: {col}; letter-spacing: 2px;")
        self._speaking = (state == "SPEAKING")

    def set_audio_level(self, level: float):
        self._sigLevel.emit(float(level))

    def _do_level(self, level: float):
        v = max(0.0, min(1.0, level))
        self.reactor.set_level(v)
        self.wave.push(v, speaking=self._speaking)
        self.spectrum.set_level(v * (1.0 if self._speaking else 0.7))

    def push_visemes(self, frames, hop: float, at: float):
        self._sigViseme.emit(list(frames), float(hop), float(at))

    def _do_visemes(self, frames, hop, at):
        try:
            env = max((f[0] for f in frames if f), default=0.0)
        except Exception:
            env = 0.0
        env = max(0.0, min(1.0, float(env)))
        self.reactor.set_speak(env)
        self.reactor.set_level(env * 0.55)
        self.wave.push(env, speaking=True)
        self.spectrum.set_level(env)

    def show_content(self, title: str, text: str):
        self._sigContent.emit(str(title), str(text))

    def _do_content(self, title: str, text: str):
        self.content_feed.setVisible(True)
        self.content_feed.setPlainText(f"── {title} ──\n\n{text}")

    # ── confirm gate (core.confirm.bind wires these) ──────────────────────
    def show_confirm(self, title: str, detail: str):
        self._sigConfirm.emit(str(title), str(detail))

    def hide_confirm(self):
        self._sigHideConfirm.emit()

    def _do_confirm(self, title: str, detail: str):
        self.confirm_banner.setText(f"⚠ {title} — {detail}")
        self.confirm_banner.show()
        self._show_confirm_buttons()

    def _do_hide_confirm(self):
        self.confirm_banner.hide()
        self._hide_confirm_buttons()

    def _show_confirm_buttons(self):
        self.btn_confirm.show(); self.btn_cancel.show()

    def _hide_confirm_buttons(self):
        self.btn_confirm.hide(); self.btn_cancel.hide()

    def _resolve_confirm_true(self):
        try:
            from core import confirm as confirm_gate
            confirm_gate.resolve(True)
        except Exception:
            pass
        self._do_hide_confirm()

    def _resolve_confirm_false(self):
        try:
            from core import confirm as confirm_gate
            confirm_gate.resolve(False)
        except Exception:
            pass
        self._do_hide_confirm()

    # ── auth re-config (the retry loop waits on _win._ready) ──────────────
    def prompt_reconfig(self):
        self._sigReconfig.emit()

    def _do_reconfig(self):
        self._ready = False
        key, ok = QInputDialog.getText(
            self, "API key needed",
            "The API key expired or is invalid.\nEnter a new Gemini API key:")
        if ok and key.strip():
            try:
                cfg = json.loads(API_FILE.read_text(encoding="utf-8"))
                cfg["gemini_api_key"] = key.strip()
                API_FILE.write_text(json.dumps(cfg, indent=4), encoding="utf-8")
            except Exception:
                API_FILE.parent.mkdir(parents=True, exist_ok=True)
                API_FILE.write_text(json.dumps({"gemini_api_key": key.strip()}, indent=4),
                                    encoding="utf-8")
        self._ready = True

    # ── persona / mode repaint hook (focus modes → theme) ────────────────
    def set_mode(self, mode: str):
        self._mode = str(mode)
        self.write_log(f"SYS: Mode → {mode}")

    # ── phone / camera hooks ──────────────────────────────────────────────
    def notify_phone_connected(self):
        self.write_log("SYS: Phone connected — remote dashboard linked.")

    def start_camera_stream(self):
        try:
            from ui_vision_panel import HandVisionPanel
            if not hasattr(self, "_vision_panel"):
                self._vision_panel = HandVisionPanel(self)
                self._center_col.insertWidget(0, self._vision_panel)
            self._vision_panel.show()
        except Exception:
            pass

    def stop_camera_stream(self):
        p = getattr(self, "_vision_panel", None)
        if p:
            p.hide()

    def resizeEvent(self, a0) -> None:
        super().resizeEvent(a0)
        locker = getattr(self, "locker", None)
        if locker is not None:
            locker.setGeometry(0, 0, max(1, self.width()), max(1, self.height()))
            locker.raise_()

    # ── drag & drop: a dropped file becomes the file_processor's input ────
    def dragEnterEvent(self, a0: QDragEnterEvent | None):
        if a0 is None:
            return
        mime_data = a0.mimeData()
        if mime_data and mime_data.hasUrls():
            a0.acceptProposedAction()

    def dropEvent(self, a0: QDropEvent | None):
        if a0 is None:
            return
        mime_data = a0.mimeData()
        if not mime_data:
            return
        for url in mime_data.urls():
            p = url.toLocalFile()
            if p:
                self.current_file = p
                self.write_log(f"SYS: File attached — {p}")
                break
        a0.acceptProposedAction()

    def closeEvent(self, a0: QCloseEvent | None):
        super().closeEvent(a0)


# ==============================================================================
# JarvisUI — the Tk entry-point used by main()'s legacy runner. Self-contained:
# a minimal window with a typed-input line and the same hook contract, so the
# assistant runs (voice + typed) even without PyQt. The PyQt HUD above is the
# full experience; this one keeps `python main.py` honest on any machine.
# ==============================================================================
class JarvisUI:
    def __init__(self, *args, **kwargs):
        self.muted = False
        self.current_file = ""
        self.on_text_command = self.on_interrupt = None
        self._root = None
        try:
            import tkinter as tk
            self._root = tk.Tk()
            self._root.title("J.A.R.V.I.S. — type to talk")
            self._root.geometry("560x120")
            tk.Label(self._root, text="Type to talk (Enter sends):",
                     font=("Courier New", 10)).pack(pady=(8, 2))
            entry = tk.Entry(self._root, font=("Courier New", 12))
            entry.pack(fill="x", padx=10)
            entry.bind("<Return>", self._tk_send)
            entry.focus_set()
            self._entry = entry
        except Exception:
            self._root = None      # headless: hooks still work

    # ── hook contract shared with the Qt HUD ──────────────────────────────
    def write_log(self, msg: str):
        print(msg, flush=True)

    def set_state(self, state: str):
        pass

    def set_audio_level(self, level: float):
        pass

    def push_visemes(self, frames, hop, at):
        pass

    def show_content(self, title: str, text: str):
        print(f"── {title} ──\n{text}", flush=True)

    def show_confirm(self, title: str, detail: str):
        self.write_log(f"CONFIRM NEEDED: {title} — type 'yes' or 'no': {detail}")

    def hide_confirm(self):
        pass

    def prompt_reconfig(self):
        try:
            key = input("API key expired — enter a new Gemini API key: ").strip()
            if key:
                cfg = {}
                try:
                    cfg = json.loads(API_FILE.read_text(encoding="utf-8"))
                except Exception:
                    pass
                cfg["gemini_api_key"] = key
                API_FILE.write_text(json.dumps(cfg, indent=4), encoding="utf-8")
        except Exception:
            pass
        self._win = self

    def notify_phone_connected(self):
        self.write_log("SYS: Phone connected.")

    def start_camera_stream(self):
        pass

    def stop_camera_stream(self):
        pass

    def set_mode(self, mode: str):
        pass

    def wait_for_api_key(self):
        # Typed-entry gate: ask once if the stored key is missing.
        try:
            if not json.loads(API_FILE.read_text(encoding="utf-8")).get("gemini_api_key"):
                key = input("Enter your Gemini API key: ").strip()
                if key:
                    API_FILE.parent.mkdir(parents=True, exist_ok=True)
                    cfg = json.loads(API_FILE.read_text(encoding="utf-8")) \
                        if API_FILE.exists() else {}
                    cfg["gemini_api_key"] = key
                    API_FILE.write_text(json.dumps(cfg, indent=4), encoding="utf-8")
        except Exception:
            pass

    def _tk_send(self, _evt=None):
        text = self._entry.get().strip()
        if not text:
            return
        self._entry.delete(0, "end")
        self.write_log(f"You: {text}")
        if self.on_text_command:
            try:
                self.on_text_command(text)
            except Exception as e:
                self.write_log(f"ERR: {e}")

    def mainloop(self):
        if self._root is not None:
            self._root.mainloop()
        else:
            while True:
                time.sleep(3600)
