"""Hand-vision panel for the HUD — shows the eye's annotated snapshot with
skeleton overlay and last identified object. Self-contained: paints a scaled
QPixmap decoded once per refresh (2 Hz), costs almost nothing.
"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QImage, QPainter, QPixmap
from PyQt6.QtWidgets import QLabel, QVBoxLayout, QWidget

try:
    from ui import C, qcol          # theme colours when loaded inside the app
except Exception:                   # pragma: no cover
    C = None


class HandVisionPanel(QWidget):
    """Live camera panel: annotated frame + status line. 2 Hz repaint."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(320, 260)
        self.setStyleSheet("background: rgba(0,8,14,220); border: 1px solid #00a8cc;")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(2)

        self._img = QLabel()
        self._img.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._img.setStyleSheet("border: none; background: transparent;")
        lay.addWidget(self._img, stretch=1)

        self._cap = QLabel("the eye is closed")
        self._cap.setFont(QFont("Orbitron", 7, QFont.Weight.Bold))
        cap_col = C.STARK if C else "#00b8e6"
        self._cap.setStyleSheet(f"color: {cap_col}; background: transparent;")
        lay.addWidget(self._cap)

        # SCANNING banner — a pulsing overlay across the video while the eye
        # is identifying. Raised by vision_eye.set_scanning(); painted here so
        # no cross-widget signalling is needed.
        self._scan_lbl = QLabel("◉ SCANNING", self._img)
        self._scan_lbl.setFont(QFont("Orbitron", 9, QFont.Weight.Bold))
        self._scan_lbl.setStyleSheet("""
            color: #00e8ff; background: rgba(0, 12, 20, 170);
            border: 1px solid #00d4ff; border-radius: 3px; padding: 2px 10px;
        """)
        self._scan_lbl.adjustSize()
        self._scan_lbl.hide()
        self._scan_phase = 0.0

        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._refresh)
        self._tmr.start(250)

    def _refresh(self):
        try:
            import math as _m
            from core import vision_eye
            st = vision_eye.status()
            if not st.get("running"):
                self._img.clear()
                self._cap.setText("the eye is closed")
                self._scan_lbl.hide()
                return
            jpeg = vision_eye.get_eye().annotated_jpeg()
            if jpeg:
                pm = QPixmap()
                pm.loadFromData(jpeg, "JPEG")
                self._img.setPixmap(pm.scaled(
                    self._img.size(), Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation))

            obj = st.get("object") or ""
            parts = [st.get("src_name", "camera"), f"{st.get('hands', 0)} hand(s)"]
            self._cap.setText(" · ".join(parts) + (f" — {obj[:40]}" if obj else ""))

            # the SCANNING overlay: visible while the eye identifies, pulsing
            scanning = bool(st.get("scanning"))
            if scanning:
                self._scan_phase += 0.25
                pulse = 0.72 + 0.28 * _m.sin(self._scan_phase)
                self._scan_lbl.setStyleSheet(f"""
                    color: rgba(0, 232, 255, {pulse:.2f});
                    background: rgba(0, 12, 20, 170);
                    border: 1px solid rgba(0, 212, 255, {pulse:.2f});
                    border-radius: 3px; padding: 2px 10px;
                """)
                if not self._scan_lbl.isVisible():
                    self._scan_lbl.show()
                    self._scan_lbl.raise_()
                    self._scan_lbl.move(
                        max(4, (self._img.width() - self._scan_lbl.width()) // 2),
                        max(4, (self._img.height() - self._scan_lbl.height()) // 2))
            elif self._scan_lbl.isVisible():
                self._scan_lbl.hide()
        except Exception:
            pass
